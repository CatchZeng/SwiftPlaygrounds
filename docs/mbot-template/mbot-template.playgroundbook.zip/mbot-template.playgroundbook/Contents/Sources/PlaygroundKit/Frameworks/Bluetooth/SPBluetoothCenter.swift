//
//  SPBluetoothCenter.swift
//  MBBlueToothCenter
//
//  Created by block Make on 2017/7/21.
//  Copyright © 2017-2018 Makeblock Co., Ltd. All rights reserved.
//

import Foundation
import PlaygroundBluetooth
import CoreBluetooth

public protocol CenterListener: class {
    func center(center: SPBLECenter, didDiscover devices: Result<[Peripheral]>)
    func center(center: SPBLECenter, didConnect device: Result<Peripheral>)
    func center(center: SPBLECenter, didPrepared device: Result<Peripheral>)
    func center(center: SPBLECenter, device: Peripheral, didReceive data: Data)
    func center(center: SPBLECenter, didDisconnect device: Result<Peripheral>)
    func center(center: SPBLECenter, didUpdateForDevice: Peripheral, allDevices: [Peripheral])
}

extension CenterListener {
    public func center(center: SPBLECenter, didDiscover devices: Result<[Peripheral]>){}
    public func center(center: SPBLECenter, didConnect device: Result<Peripheral>){}
    public func center(center: SPBLECenter, didPrepared device: Result<Peripheral>){}
    public func center(center: SPBLECenter, device: Peripheral, didReceive data: Data){}
    public func center(center: SPBLECenter, didDisconnect device: Result<Peripheral>){}
    public func center(center: SPBLECenter, didUpdateForDevice: Peripheral, allDevices: [Peripheral]){}
}

public class ListenerWeakWrapper {
    weak var value: CenterListener?
    
    init(value: CenterListener) {
        self.value = value
    }
}

public class SPBLECenter: NSObject, MakeblockSender {
    static public let shared = SPBLECenter()
    public var enableLog = false
    public var isNeuron = false
    public let centralManager = PlaygroundBluetoothCentralManager(services: nil, queue: .main)
    
    public var listeners: [CenterListener] {
        let validWrappers = listenerWrappers.filter {$0.value != nil}
        return validWrappers.map {$0.value!}
    }
    fileprivate var listenerWrappers: [ListenerWeakWrapper] = []

    public typealias Element = Peripheral

    var connectedDevice: Element?

    let configurator: PeripheralConfigurator = PeripheralConfigurator()

    private override init() {
        super.init()
        centralManager.delegate = self
        configurator.delegate = self
    }
    
    public func connectToLastConnectedPeripheral(timeout: TimeInterval = 7.0, callback: ((CBPeripheral?, Error?) -> Void)? = nil) {
        _ = centralManager.connectToLastConnectedPeripheral()
    }

    public func send(data: Data) {
        if let device = connectedDevice {
            send(res: data, to: device)
        }
    }
    
    public func addListener(listener: CenterListener) {
        if !listeners.contains { $0 === listener } {
            listenerWrappers.append(ListenerWeakWrapper(value: listener))
        }
        for (i, obj) in listenerWrappers.enumerated() {
            if obj.value == nil && i < listenerWrappers.count {
                listenerWrappers.remove(at: i)
            }
        }
    }
    
    public func removeListener(listener: CenterListener) {
        guard let index = listenerWrappers.firstIndex(where: {$0.value === listener}) else {return}
        listenerWrappers.remove(at: index)
    }
    
    private func send<R>(res: R, to device: Peripheral) where R: Request {
        guard let characteristic = device.writeChar,
            let data = res.interpreter.command(origin: res.command) as? Data else {
            return
        }
        
        device.send(data: data, to: characteristic, type: res.method.writeType)
    }
}

extension SPBLECenter: PlaygroundBluetoothCentralManagerDelegate, PeripheralConfiguratorDelegate {

    public func centralManagerStateDidChange(_ centralManager: PlaygroundBluetoothCentralManager) {
    }

    public func centralManager(_ centralManager: PlaygroundBluetoothCentralManager, didDiscover peripheral: CBPeripheral, withAdvertisementData advertisementData: [String: Any]?, rssi: Double) {
    }

    public func centralManager(_ centralManager: PlaygroundBluetoothCentralManager, willConnectTo peripheral: CBPeripheral) {
    }

    public func centralManager(_ centralManager: PlaygroundBluetoothCentralManager, didConnectTo peripheral: CBPeripheral) {
        let pr = Peripheral(peripheral: peripheral)
        configurator.prepare(peripheral: pr)
        listeners.forEach {$0.center(center: self, didConnect: .success(pr))}
    }

    public func centralManager(_ centralManager: PlaygroundBluetoothCentralManager, didFailToConnectTo peripheral: CBPeripheral, error: Error?) {
    }

    public func centralManager(_ centralManager: PlaygroundBluetoothCentralManager, didDisconnectFrom peripheral: CBPeripheral, error: Error?) {
        let pr = Peripheral.init(peripheral: peripheral)
        listeners.forEach {$0.center(center: self, didDisconnect: .success(pr))}
    }

    public func peripheralDidPrepared(_ peripheral: Result<Peripheral>) {
        if case let .success(value) = peripheral {
            connectedDevice = value
            connectedDevice?.dataDelegate = self
            listeners.forEach {$0.center(center: self, didPrepared: peripheral)}
        }
    }
}

extension SPBLECenter: PeripheralDataDelegate {
    public func peripheral(_ peripheral: Peripheral, didReceive data: Data) {
        listeners.forEach {$0.center(center: self, device: peripheral, didReceive: data)}
    }
}
