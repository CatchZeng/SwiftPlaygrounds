//
//  BlueToothProvider.swift
//  Neuron
//
//  Created by CatchZeng on 2017/4/18.
//  Copyright © 2017-2018 Makeblock Co., Ltd. All rights reserved.
//

import Foundation
import CoreBluetooth

public class BLELauncher: Launcher {
    public typealias Element = Peripheral
    public var delegate: DeviceDelegate

    init(delegate: DeviceDelegate) {
        self.delegate = delegate
    }

    public func send<R>(res: R, to device: Element) where R: Request {
        guard device.state == .prepared, let characteristic = device.writeChar else {
            delegate.device(device, didReceive: .failure(error: PeripheralError.notFoundCharacteristic))
            return
        }
        guard  let data = res.interpreter.command(origin: res.command) as? Data else {
            delegate.device(device, didReceive: .failure(error: CenterError.commandIncorrect))
            return
        }
        var method: CBCharacteristicWriteType!
        switch res.method {
        case .transition:
            method = .withResponse
        case .write:
            method = .withoutResponse
        default:
            break
        }
        device.send(data: data, to: characteristic, type: method, handler: { result in
            if case let .success(value) = result {
                self.delegate.device(device, didReceive: .success(R.Response.decode(data: value.1)))
            }
        })
    }
}

protocol PeripheralServiceAndCharacteristicDelegate: class {
    func peripheral(peripheral: Peripheral, didDiscover services: [CBService]?, error: Error?)
    func peripheral(_ peripheral: Peripheral, didDiscover characteristics: [CBCharacteristic]?, error: Error?)
}

/// 具体实现
public final class MBPeripheralConfigurator: PeripheralServiceAndCharacteristicDelegate {
    var delegate: DeviceDelegate
    private var device: Peripheral?

    init(delegate: DeviceDelegate) {
        self.delegate = delegate
    }

    public func prepare(device: Peripheral) {
        self.device = device
        device.peripheralDelegate = self
        device.peripheral.discoverServices(nil)
    }

    //Props
    private var isDual: Bool = false
    private var resetService: CBService?
    private var transService: CBService?
    private var resetCharateristic: CBCharacteristic?
    private var transCharateristic: CBCharacteristic?
    private var notifyCharateristic: CBCharacteristic?

    func peripheral(peripheral: Peripheral, didDiscover services: [CBService]?, error: Error?) {
        guard let services = services else { return }
        for service in services {
            switch service.uuid {
            case CBUUID.transDataService:
                peripheral.peripheral.discoverCharacteristics([.transDataCharateristic, .transDataDualCharateristic, .notifyDataCharateristic, .notifyDataDualCharateristic], for: service)
            case CBUUID.transDataDualService:
                isDual = true
                peripheral.peripheral.discoverCharacteristics([.transDataCharateristic, .transDataDualCharateristic, .notifyDataCharateristic, .notifyDataDualCharateristic], for: service)
            default:
                continue
            }
        }
    }

    func peripheral(_ peripheral: Peripheral, didDiscover characteristics: [CBCharacteristic]?, error: Error?) {
        guard let characteristics = characteristics, error == nil else {
            return
        }
        for characteristic in characteristics {
            switch characteristic.uuid {
            case CBUUID.transDataCharateristic, CBUUID.transDataDualCharateristic:
                transCharateristic = characteristic
            case CBUUID.notifyDataCharateristic, CBUUID.notifyDataDualCharateristic:
                notifyCharateristic = characteristic
                peripheral.peripheral.setNotifyValue(true, for: characteristic)
            default:
                continue
            }
            manageDeviceState()
        }
    }

    // MARK: Private
    
    private func manageDeviceState() {
        if let device = self.device, notifyCharateristic != nil && transCharateristic != nil {
            self.device!.writeChar = transCharateristic
            self.device!.state = .prepared
            self.delegate.deviceDidPrepared(.success(device))
        }
    }
}
