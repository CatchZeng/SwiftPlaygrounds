//
//  DataConverter.swift
//  Neuron
//
//  Created by CatchZeng on 2017/4/16.
//  Copyright © 2017-2018 Makeblock Co., Ltd. All rights reserved.
//

import UIKit

open class DataConverter: NSObject {
    
    open static func convert8to7bit(_ value: [UInt8]) -> [UInt8] {
        let inlen = value.count
        var out: [UInt8] = []
        
        var mask: [UInt8] = [0x80, 0xc0, 0xe0, 0xf0, 0xf8, 0xfc, 0xfe]
        var counter = 0
        var temp: UInt8 = 0x00
        var j = 0
        
        for i in 0..<inlen {
            let insert = ((value[i]) << UInt8(counter) | temp) & 0x7f
            out.insert(insert, at: j)
            j += 1
            
            temp = ((mask[counter] & value[i]) >> UInt8(7 - counter))
            
            counter += 1
            
            if 0 == (counter % 7) {
                out.insert(temp, at: j)
                j += 1
                
                temp = 0x00
                counter = 0
            }
        }
        
        if 0 != (counter % 7) {
            out.insert(temp, at: j)
            j += 1
        }
        
        return out
    }
    
    open static func convert7to8bit(_ value: [UInt8], offset: Int = 0) -> [UInt8] {
        let length = value.count
        return convert7to8bit(value, length: length)
    }
    
    open static func convert7to8bit(_ value: [UInt8], offset: Int = 0, length: Int) -> [UInt8] {
        let offsetValue = offset | 0
        let lengthValue = length | value.count
        
        var input: [UInt8] = []
        for i in offsetValue..<offsetValue+lengthValue {
            input.append(value[i])
        }
        
        var mask: [UInt8] = [0x01, 0x03, 0x07, 0x0f, 0x1f, 0x3f, 0x7f]
        
        var counter = 0
        var j = 0
        
        let outlen = input.count - Int(ceil(Double(input.count)/8.0))
        var out: [UInt8] = []
        
        for var i in 0 ..< input.count - 1 {
            let insert = (input[i] >> UInt8(counter)) | ((input[i + 1] & mask[counter]) << UInt8(7-counter))
            out.insert(insert, at: j)
            j += 1
            
            counter += 1
            
            if 0 == (counter % 7) {
                counter = 0
                i += 1
            }
        }
        
        let outValue = Array(out[0...outlen-1])
        return outValue
    }
}

