//
//  PageHelper.swift
//  spheroArcade
//
//  Created by Anthony Blackman on 2017-03-16.
//  Copyright © 2017 Sphero Inc. All rights reserved.
//
// Helper functions to abstract out differences between running in playgrounds app and as an iOS app.


import Foundation
import PlaygroundSupport
import UIKit

/// Waits for a number of seconds before running the next sequence of code.
///
/// - Parameter seconds: the number of seconds to wait
public func sleep(_ seconds: Double) {
    usleep(UInt32(seconds * 1e6))
}

public var currentProxy: PlaygroundRemoteLiveViewProxy? {
    return PlaygroundPage.current.liveView as? PlaygroundRemoteLiveViewProxy
}

public func log(_ text: String, _ index: Int = 0) {
    Loader.currentLiveViewController?.log(text)
}

public func setProxyDelegate(_ delegate: PlaygroundRemoteLiveViewProxyDelegate) {
    if let proxy = currentProxy {
        proxy.delegate = delegate
    }
}

public func sendToLiveView(_ value: PlaygroundValue) {
    if let proxy = currentProxy {
        proxy.send(value)
    }
}

public func sendToContents(_ value: PlaygroundValue) {
    if let proxy = PlaygroundPage.current.liveView as? PlaygroundLiveViewMessageHandler {
        proxy.send(value)
    }
}

public func sendToContentsWithEnum(_ enumValue: SPCallbackCommand) {
    sendToContents(enumValue.value)
}

public func instantiateLiveView() -> PlaygroundLiveViewable {
    //    let storyboard = UIStoryboard(name: "LiveView", bundle: nil)
    //
    //    guard let viewController = storyboard.instantiateInitialViewController() else {
    //        fatalError("LiveView.storyboard does not have an initial scene; please set one or update this function")
    //    }
    
    //    guard let liveViewController = viewController as? LiveViewController else {
    //        fatalError("LiveView.storyboard's initial scene is not a LiveViewController; please either update the storyboard or this function")
    //    }
    let liveViewController = TemplateViewController()
    return liveViewController
}
