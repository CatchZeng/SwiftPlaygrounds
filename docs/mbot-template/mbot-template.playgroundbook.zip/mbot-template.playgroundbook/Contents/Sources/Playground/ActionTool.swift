//
//  ActionTool
//  Neuron
//
//  Created by CatchZeng on 2018/4/18.
//  Copyright © 2017-2018 Makeblock Co., Ltd. All rights reserved.
//

import UIKit

public class ActionTool {
    public static let DefaultDuration: Float = 0.01
    
    static public func testText(_ text: String) {
        let command = MCommand.init(action: .testText(text), duration: 0.5, platform: .all)
        let task = SPTask<MCommand>.init(commands: [command], duration: 0.5)
        Loader.sharedTaskMgr.addTasks([task])
    }
    
    static public func wait(_ duration: Float) {
        sendAction(.execute, duration: duration)
    }
    
    static internal func sendAction(_ action: SPCommandAction, duration: Float = 0) {
        let command = MCommand.init(action: action, duration: duration, platform: .all)
        let task = SPTask<MCommand>.init(commands: [command], duration: duration)
        Loader.sharedTaskMgr.addTasks([task])
    }
    
    static internal func sendDefaultDurationAction(_ action: SPCommandAction) {
        sendAction(action, duration: ActionTool.DefaultDuration)
    }
}
