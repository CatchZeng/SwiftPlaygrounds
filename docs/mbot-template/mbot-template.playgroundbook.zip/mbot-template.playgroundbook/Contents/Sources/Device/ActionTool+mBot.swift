//
//  ActionTool+mBot.swift
//  Book_Sources
//
//  Created by CatchZeng on 2018/10/11.
//

import Foundation
import UIKit

extension ActionTool {
    
    static public func moveForward(speed: Int) {
        sendDefaultDurationAction(.move(left: speed, right: speed))
    }
    
    static public func moveBackward(speed: Int) {
        sendDefaultDurationAction(.move(left: -speed, right: -speed))
    }
    
    static public func moveLeft(speed: Int) {
        sendDefaultDurationAction(.move(left: -speed, right: speed))
    }
    
    static public func moveRight(speed: Int) {
        sendDefaultDurationAction(.move(left: speed, right: -speed))
    }
    
    static public func setDCMotor(leftSpeed: Int, rightSpeed: Int) {
        sendDefaultDurationAction(.move(left: leftSpeed, right: rightSpeed))
    }
    
    static public func stop() {
        sendDefaultDurationAction(.move(left: 0, right: 0))
    }
    
    static public func setFan(port: RJ25Port, speed: Int) {
        sendDefaultDurationAction(.setFan(port: port, speed: speed))
    }
    
    static public func setLEDStrip(port: RJ25Port,
                                slot: RJ25Slot,
                                color: UIColor) {
        if let rgba = color.rgba() {
            sendDefaultDurationAction(.setLEDStrip(port: port,
                                                slot: slot,
                                                r: rgba.r,
                                                g: rgba.g,
                                                b: rgba.b))
        }
    }
    
    static public func setRGBLED(port: RJ25Port,
                              slot: RJ25Slot,
                              position: RGBLEDPosition,
                              color: UIColor) {
        if let rgba = color.rgba() {
            sendDefaultDurationAction(.setRGBLED(port: port,
                                              slot: slot,
                                              position: position,
                                              r: rgba.r,
                                              g: rgba.g,
                                              b: rgba.b))
        }
    }
    
    static public func setOnboardRGBLED(position: RGBLEDPosition,
                                  color: UIColor) {
        if let rgba = color.rgba() {
            sendDefaultDurationAction(.setRGBLED(port: .board,
                                              slot: .slot2,
                                              position: position,
                                              r: rgba.r,
                                              g: rgba.g,
                                              b: rgba.b))
        }
    }
    
    static public func setShutter(port: RJ25Port, action: ShutterAction) {
        sendDefaultDurationAction(.setShutter(port: port, action: action))
    }
    
    static public func set7SegmentDisplay(port: RJ25Port, value: Float) {
        sendDefaultDurationAction(.set7SegmentDisplay(port: port, value: value))
    }
    
    static public func play(note: MusicNotePitch, beat: MusicNoteDuration) {
        sendDefaultDurationAction(.play(note: note, beat: beat))
    }
    
    static public func sendInfrared(message: String) {
        sendDefaultDurationAction(.sendInfrared(message: message))
    }
    
    static public func setServo(port: RJ25Port,slot: RJ25Slot, angle: Int) {
        sendDefaultDurationAction(.setServo(port: port, slot: slot, angle: angle))
    }
    
    static public func setLEDPanel(port: RJ25Port, text: String) {
        sendDefaultDurationAction(.setLEDPanel(port: port, text: text))
    }
    
    static public func readUltrasonicSensor(port: RJ25Port) {
        sendDefaultDurationAction(.readUltrasonicSensor(port: port))
    }
    
    static public func readLightSensor(port: RJ25Port) {
        sendDefaultDurationAction(.readLightSensor(port: port))
    }
    
    static public func readLineFollowerSensor(port: RJ25Port) {
        sendDefaultDurationAction(.readLineFollowerSensor(port: port))
    }
    
    static public func readJoystick(port: RJ25Port, axis: PhysicalJoystickAxis) {
        sendDefaultDurationAction(.readJoystick(port: port, axis: axis))
    }
    
    static public func readTemperatureSensor(port: RJ25Port, slot: RJ25Slot) {
        sendDefaultDurationAction(.readTemperatureSensor(port: port, slot: slot))
    }
    
    static public func readHumitureSensor(port: RJ25Port, mode: HumitureMode) {
        sendDefaultDurationAction(.readHumitureSensor(port: port, mode: mode))
    }
    
    static public func readSoundSensor(port: RJ25Port) {
        sendDefaultDurationAction(.readSoundSensor(port: port))
    }
    
    static public func readOnboardButton(state: ButtonState) {
        sendDefaultDurationAction(.readOnboardButton(state: state))
    }
    
    static public func readGyroSensor(port: RJ25Port, axis: GyroAxis) {
        sendDefaultDurationAction(.readGyroSensor(port: port, axis: axis))
    }
    
    static public func readFlameSensor(port: RJ25Port) {
        sendDefaultDurationAction(.readFlameSensor(port: port))
    }
    
    static public func readGasSensor(port: RJ25Port) {
        sendDefaultDurationAction(.readGasSensor(port: port))
    }
    
    static public func readButton(port: RJ25Port, key: ButtonKey) {
        sendDefaultDurationAction(.readButton(port: port, key: key))
    }
    
    static public func readTouchSensor(port: RJ25Port) {
        sendDefaultDurationAction(.readTouchSensor(port: port))
    }
    
    static public func readPotentiometer(port: RJ25Port) {
        sendDefaultDurationAction(.readPotentiometer(port: port))
    }
    
    static public func readLimitSwitch(port: RJ25Port, slot: RJ25Slot) {
        sendDefaultDurationAction(.readLimitSwitch(port: port, slot: slot))
    }
    
    static public func readCompass(port: RJ25Port) {
        sendDefaultDurationAction(.readCompass(port: port))
    }
}
