//
//  ActionMessage.swift
//  Book_Sources
//
//  Created by CatchZeng on 2018/10/11.
//

import PlaygroundSupport
import Foundation
import UIKit

public enum ActionEncodingKey: String {
    case typeKey
    case idKey
    case testText
    case execute
    case wait
    case duration
    
    // mBot
    case move
    case left
    case right
    case setLEDStrip
    case port
    case slot
    case r
    case g
    case b
    case setRGBLED
    case position
    case setShutter
    case action
    case setServo
    case angle
    case set7SegmentDisplay
    case value
    case play
    case note
    case beat
    case sendInfrared
    case message
    case setFan
    case speed
    case axis
    case readUltrasonicSensor
    case readLightSensor
    case readLineFollowerSensor
    case readJoystick
    case readTemperatureSensor
    case readHumitureSensor
    case mode
    case readSoundSensor
    case readOnboardButton
    case state
    case readGyroSensor
    case readFlameSensor
    case readGasSensor
    case readButton
    case key
    case readTouchSensor
    case readPotentiometer
    case readLimitSwitch
    case readCompass
    case setLEDPanel
    case text
}

public enum SPCommandAction {
    case none
    case testText(String)
    case execute
    case wait(duration: Float)
    
    // mBot
    case move(left: Int, right: Int)
    case setLEDStrip(port: RJ25Port, slot: RJ25Slot, r: Int, g: Int, b: Int)
    case setRGBLED(port: RJ25Port, slot: RJ25Slot, position: RGBLEDPosition, r: Int, g: Int, b: Int)
    case setShutter(port: RJ25Port, action: ShutterAction)
    case setServo(port: RJ25Port,slot: RJ25Slot, angle: Int)
    case set7SegmentDisplay(port: RJ25Port, value: Float)
    case play(note: MusicNotePitch, beat: MusicNoteDuration)
    case setFan(port: RJ25Port, speed: Int)
    case sendInfrared(message: String)
    case setLEDPanel(port: RJ25Port, text: String)
    case readUltrasonicSensor(port: RJ25Port)
    case readLightSensor(port: RJ25Port)
    case readLineFollowerSensor(port: RJ25Port)
    case readJoystick(port: RJ25Port, axis: PhysicalJoystickAxis)
    case readTemperatureSensor(port: RJ25Port, slot: RJ25Slot)
    case readHumitureSensor(port: RJ25Port, mode: HumitureMode)
    case readSoundSensor(port: RJ25Port)
    case readOnboardButton(state: ButtonState)
    case readGyroSensor(port: RJ25Port, axis: GyroAxis)
    case readFlameSensor(port: RJ25Port)
    case readGasSensor(port: RJ25Port)
    case readButton(port: RJ25Port, key: ButtonKey)
    case readTouchSensor(port: RJ25Port)
    case readPotentiometer(port: RJ25Port)
    case readLimitSwitch(port: RJ25Port, slot: RJ25Slot)
    case readCompass(port: RJ25Port)
}

extension SPCommandAction: SPMessageConstructible {
    public init?(_ value: PlaygroundValue) {
        guard case let .dictionary(dict) = value, let typeV = dict[ActionEncodingKey.typeKey.rawValue], case let .string(type) = typeV else {
            return nil
        }
        
        switch type {
        case ActionEncodingKey.testText.rawValue:
            if let text = value.stringValue(ActionEncodingKey.idKey.rawValue) {
                self = SPCommandAction.testText(text)
            } else {
                return nil
            }
            
        case ActionEncodingKey.execute.rawValue:
            self = SPCommandAction.execute
            
        case ActionEncodingKey.wait.rawValue:
            guard let duration = value.floatValue(ActionEncodingKey.duration.rawValue) else {
                return nil
            }
            self = SPCommandAction.wait(duration: duration)
        
        // mBot
        case ActionEncodingKey.move.rawValue:
            guard let left = value.intValue(ActionEncodingKey.left.rawValue),
            let right = value.intValue(ActionEncodingKey.right.rawValue) else {
                return nil
            }
            self = SPCommandAction.move(left: left, right: right)
            
        case ActionEncodingKey.setLEDStrip.rawValue:
            guard let port = RJ25Port.init(dict[ActionEncodingKey.port.rawValue]!),
                let slot = RJ25Slot.init(dict[ActionEncodingKey.slot.rawValue]!),
                let r = value.intValue(ActionEncodingKey.r.rawValue),
                let g = value.intValue(ActionEncodingKey.g.rawValue),
                let b = value.intValue(ActionEncodingKey.b.rawValue) else {
                    return nil
            }
            self = SPCommandAction.setLEDStrip(port: port, slot: slot, r: r, g: g, b: b)
            
        case ActionEncodingKey.setRGBLED.rawValue:
            guard let port = RJ25Port.init(dict[ActionEncodingKey.port.rawValue]!),
                let slot = RJ25Slot.init(dict[ActionEncodingKey.slot.rawValue]!),
                let position = RGBLEDPosition.init(dict[ActionEncodingKey.position.rawValue]!),
                let r = value.intValue(ActionEncodingKey.r.rawValue),
                let g = value.intValue(ActionEncodingKey.g.rawValue),
                let b = value.intValue(ActionEncodingKey.b.rawValue) else {
                    return nil
            }
            self = SPCommandAction.setRGBLED(port: port, slot: slot, position: position, r: r, g: g, b: b)
            
        case ActionEncodingKey.setShutter.rawValue:
            guard let port = RJ25Port.init(dict[ActionEncodingKey.port.rawValue]!),
                let action = ShutterAction.init(dict[ActionEncodingKey.action.rawValue]!) else {
                    return nil
            }
            self = SPCommandAction.setShutter(port: port, action: action)
            
        case ActionEncodingKey.setServo.rawValue:
            guard let port = RJ25Port.init(dict[ActionEncodingKey.port.rawValue]!),
                let slot = RJ25Slot.init(dict[ActionEncodingKey.slot.rawValue]!),
                let angle = value.intValue(ActionEncodingKey.angle.rawValue) else {
                    return nil
            }
            self = SPCommandAction.setServo(port: port, slot: slot, angle: angle)
            
        case ActionEncodingKey.set7SegmentDisplay.rawValue:
            guard let port = RJ25Port.init(dict[ActionEncodingKey.port.rawValue]!),
                let floatValue = value.floatValue(ActionEncodingKey.value.rawValue) else {
                    return nil
            }
            self = SPCommandAction.set7SegmentDisplay(port: port, value: floatValue)
            
        case ActionEncodingKey.play.rawValue:
            guard let note = MusicNotePitch.init(dict[ActionEncodingKey.note.rawValue]!),
                let beat = MusicNoteDuration.init(dict[ActionEncodingKey.beat.rawValue]!) else {
                    return nil
            }
            self = SPCommandAction.play(note: note, beat: beat)
            
        case ActionEncodingKey.sendInfrared.rawValue:
            guard let message = value.stringValue(ActionEncodingKey.message.rawValue) else {
                    return nil
            }
            self = SPCommandAction.sendInfrared(message: message)
            
        case ActionEncodingKey.readUltrasonicSensor.rawValue:
            guard let port = RJ25Port.init(dict[ActionEncodingKey.port.rawValue]!) else {
                return nil
            }
            self = SPCommandAction.readUltrasonicSensor(port: port)
            
        case ActionEncodingKey.readLightSensor.rawValue:
            guard let port = RJ25Port.init(dict[ActionEncodingKey.port.rawValue]!) else {
                return nil
            }
            self = SPCommandAction.readLightSensor(port: port)
            
        case ActionEncodingKey.readLineFollowerSensor.rawValue:
            guard let port = RJ25Port.init(dict[ActionEncodingKey.port.rawValue]!) else {
                return nil
            }
            self = SPCommandAction.readLineFollowerSensor(port: port)
        
        case ActionEncodingKey.setFan.rawValue:
            guard let port = RJ25Port.init(dict[ActionEncodingKey.port.rawValue]!),
                let speed = value.intValue(ActionEncodingKey.speed.rawValue)
                else {
                return nil
            }
            self = SPCommandAction.setFan(port: port, speed: speed)
            
        case ActionEncodingKey.readJoystick.rawValue:
            guard let port = RJ25Port.init(dict[ActionEncodingKey.port.rawValue]!),
                let axis = PhysicalJoystickAxis.init(dict[ActionEncodingKey.axis.rawValue]!)
                else {
                    return nil
            }
            self = SPCommandAction.readJoystick(port: port, axis: axis)
        
        case ActionEncodingKey.readTemperatureSensor.rawValue:
            guard let port = RJ25Port.init(dict[ActionEncodingKey.port.rawValue]!),
                let slot = RJ25Slot.init(dict[ActionEncodingKey.slot.rawValue]!)
                else {
                    return nil
            }
            self = SPCommandAction.readTemperatureSensor(port: port, slot: slot)
            
        case ActionEncodingKey.readHumitureSensor.rawValue:
            guard let port = RJ25Port.init(dict[ActionEncodingKey.port.rawValue]!),
                let mode = HumitureMode.init(dict[ActionEncodingKey.mode.rawValue]!)
                else {
                    return nil
            }
            self = SPCommandAction.readHumitureSensor(port: port, mode: mode)
            
        case ActionEncodingKey.readSoundSensor.rawValue:
            guard let port = RJ25Port.init(dict[ActionEncodingKey.port.rawValue]!)
                else {
                    return nil
            }
            self = SPCommandAction.readSoundSensor(port: port)
            
        case ActionEncodingKey.readOnboardButton.rawValue:
            guard let state = ButtonState.init(dict[ActionEncodingKey.state.rawValue]!)
                else {
                    return nil
            }
            self = SPCommandAction.readOnboardButton(state: state)
        
        case ActionEncodingKey.readGyroSensor.rawValue:
            guard let port = RJ25Port.init(dict[ActionEncodingKey.port.rawValue]!),
                let axis = GyroAxis.init(dict[ActionEncodingKey.axis.rawValue]!)
                else {
                    return nil
            }
            self = SPCommandAction.readGyroSensor(port: port, axis: axis)
            
        case ActionEncodingKey.readFlameSensor.rawValue:
            guard let port = RJ25Port.init(dict[ActionEncodingKey.port.rawValue]!)
                else {
                    return nil
            }
            self = SPCommandAction.readFlameSensor(port: port)
            
        case ActionEncodingKey.readGasSensor.rawValue:
            guard let port = RJ25Port.init(dict[ActionEncodingKey.port.rawValue]!)
                else {
                    return nil
            }
            self = SPCommandAction.readGasSensor(port: port)
            
        case ActionEncodingKey.readButton.rawValue:
            guard let port = RJ25Port.init(dict[ActionEncodingKey.port.rawValue]!),
                let key = ButtonKey.init(dict[ActionEncodingKey.key.rawValue]!)
                else {
                    return nil
            }
            self = SPCommandAction.readButton(port: port, key: key)
            
        case ActionEncodingKey.readTouchSensor.rawValue:
            guard let port = RJ25Port.init(dict[ActionEncodingKey.port.rawValue]!)
                else {
                    return nil
            }
            self = SPCommandAction.readTouchSensor(port: port)
            
        case ActionEncodingKey.readPotentiometer.rawValue:
            guard let port = RJ25Port.init(dict[ActionEncodingKey.port.rawValue]!)
                else {
                    return nil
            }
            self = SPCommandAction.readPotentiometer(port: port)
            
        case ActionEncodingKey.readLimitSwitch.rawValue:
            guard let port = RJ25Port.init(dict[ActionEncodingKey.port.rawValue]!),
                let slot = RJ25Slot.init(dict[ActionEncodingKey.slot.rawValue]!)
                else {
                    return nil
            }
            self = SPCommandAction.readLimitSwitch(port: port, slot: slot)
        
        case ActionEncodingKey.readCompass.rawValue:
            guard let port = RJ25Port.init(dict[ActionEncodingKey.port.rawValue]!)
                else {
                    return nil
            }
            self = SPCommandAction.readCompass(port: port)
            
        case ActionEncodingKey.setLEDPanel.rawValue:
            guard let port = RJ25Port.init(dict[ActionEncodingKey.port.rawValue]!),
                let text = value.stringValue(ActionEncodingKey.text.rawValue)
                else {
                    return nil
            }
            self = SPCommandAction.setLEDPanel(port: port, text: text)
            
        default:
            self = SPCommandAction.none
        }
    }
    
    public var value: PlaygroundValue {
        var dict: [String: PlaygroundValue] = [:]
        switch self {
        case .testText(let text):
            dict[ActionEncodingKey.typeKey.rawValue] = ActionEncodingKey.testText.rawValue.value
            dict[ActionEncodingKey.idKey.rawValue] = text.value
            
        case .execute:
            dict[ActionEncodingKey.typeKey.rawValue] = ActionEncodingKey.execute.rawValue.value
            
        case .wait(let duration):
            dict[ActionEncodingKey.typeKey.rawValue] = ActionEncodingKey.wait.rawValue.value
            dict[ActionEncodingKey.duration.rawValue] = duration.value
            
        // mBot
        case .move(let left, let right):
            dict[ActionEncodingKey.typeKey.rawValue] = ActionEncodingKey.move.rawValue.value
            dict[ActionEncodingKey.left.rawValue] = left.value
            dict[ActionEncodingKey.right.rawValue] = right.value
            
        case .setLEDStrip(let port, let slot, let r, let g, let b):
            dict[ActionEncodingKey.typeKey.rawValue] = ActionEncodingKey.setLEDStrip.rawValue.value
            dict[ActionEncodingKey.port.rawValue] = port.value
            dict[ActionEncodingKey.slot.rawValue] = slot.value
            dict[ActionEncodingKey.r.rawValue] = r.value
            dict[ActionEncodingKey.g.rawValue] = g.value
            dict[ActionEncodingKey.b.rawValue] = b.value
            
        case .setRGBLED(let port, let slot, let position, let r, let g, let b):
            dict[ActionEncodingKey.typeKey.rawValue] = ActionEncodingKey.setLEDStrip.rawValue.value
            dict[ActionEncodingKey.port.rawValue] = port.value
            dict[ActionEncodingKey.slot.rawValue] = slot.value
            dict[ActionEncodingKey.position.rawValue] = position.value
            dict[ActionEncodingKey.r.rawValue] = r.value
            dict[ActionEncodingKey.g.rawValue] = g.value
            dict[ActionEncodingKey.b.rawValue] = b.value
            
        case .setShutter(let port, let action):
            dict[ActionEncodingKey.typeKey.rawValue] = ActionEncodingKey.setShutter.rawValue.value
            dict[ActionEncodingKey.port.rawValue] = port.value
            dict[ActionEncodingKey.action.rawValue] = action.value
            
        case .setServo(let port, let slot, let angle):
            dict[ActionEncodingKey.typeKey.rawValue] = ActionEncodingKey.setServo.rawValue.value
            dict[ActionEncodingKey.port.rawValue] = port.value
            dict[ActionEncodingKey.slot.rawValue] = slot.value
            dict[ActionEncodingKey.angle.rawValue] = angle.value
            
        case .set7SegmentDisplay(let port, let value):
            dict[ActionEncodingKey.typeKey.rawValue] = ActionEncodingKey.set7SegmentDisplay.rawValue.value
            dict[ActionEncodingKey.port.rawValue] = port.value
            dict[ActionEncodingKey.value.rawValue] = value.value
            
        case .play(let note, let beat):
            dict[ActionEncodingKey.typeKey.rawValue] = ActionEncodingKey.play.rawValue.value
            dict[ActionEncodingKey.note.rawValue] = note.value
            dict[ActionEncodingKey.beat.rawValue] = beat.value
            
        case .sendInfrared(let message):
            dict[ActionEncodingKey.typeKey.rawValue] = ActionEncodingKey.sendInfrared.rawValue.value
            dict[ActionEncodingKey.message.rawValue] = message.value
            
        case .readUltrasonicSensor(let port):
            dict[ActionEncodingKey.typeKey.rawValue] = ActionEncodingKey.readUltrasonicSensor.rawValue.value
            dict[ActionEncodingKey.port.rawValue] = port.value
            
        case .readLightSensor(let port):
            dict[ActionEncodingKey.typeKey.rawValue] = ActionEncodingKey.readLightSensor.rawValue.value
            dict[ActionEncodingKey.port.rawValue] = port.value
        
        case .readLineFollowerSensor(let port):
            dict[ActionEncodingKey.typeKey.rawValue] = ActionEncodingKey.readLineFollowerSensor.rawValue.value
            dict[ActionEncodingKey.port.rawValue] = port.value
            
        case .setFan(let port, let speed):
            dict[ActionEncodingKey.typeKey.rawValue] = ActionEncodingKey.setFan.rawValue.value
            dict[ActionEncodingKey.port.rawValue] = port.value
            dict[ActionEncodingKey.speed.rawValue] = speed.value
        
        case .readJoystick(let port, let axis):
            dict[ActionEncodingKey.typeKey.rawValue] = ActionEncodingKey.readJoystick.rawValue.value
            dict[ActionEncodingKey.port.rawValue] = port.value
            dict[ActionEncodingKey.axis.rawValue] = axis.value
            
        case .readTemperatureSensor(let port, let slot):
            dict[ActionEncodingKey.typeKey.rawValue] = ActionEncodingKey.readTemperatureSensor.rawValue.value
            dict[ActionEncodingKey.port.rawValue] = port.value
            dict[ActionEncodingKey.slot.rawValue] = slot.value
            
        case .readHumitureSensor(let port, let mode):
            dict[ActionEncodingKey.typeKey.rawValue] = ActionEncodingKey.readHumitureSensor.rawValue.value
            dict[ActionEncodingKey.port.rawValue] = port.value
            dict[ActionEncodingKey.mode.rawValue] = mode.value
            
        case .readSoundSensor(let port):
            dict[ActionEncodingKey.typeKey.rawValue] = ActionEncodingKey.readSoundSensor.rawValue.value
            dict[ActionEncodingKey.port.rawValue] = port.value
            
        case .readOnboardButton(let state):
            dict[ActionEncodingKey.typeKey.rawValue] = ActionEncodingKey.readOnboardButton.rawValue.value
            dict[ActionEncodingKey.state.rawValue] = state.value
            
        case .readGyroSensor(let port, let axis):
            dict[ActionEncodingKey.typeKey.rawValue] = ActionEncodingKey.readGyroSensor.rawValue.value
            dict[ActionEncodingKey.port.rawValue] = port.value
            dict[ActionEncodingKey.axis.rawValue] = axis.value
            
        case .readFlameSensor(let port):
            dict[ActionEncodingKey.typeKey.rawValue] = ActionEncodingKey.readFlameSensor.rawValue.value
            dict[ActionEncodingKey.port.rawValue] = port.value
            
        case .readGasSensor(let port):
            dict[ActionEncodingKey.typeKey.rawValue] = ActionEncodingKey.readGasSensor.rawValue.value
            dict[ActionEncodingKey.port.rawValue] = port.value
            
        case .readButton(let port, let key):
            dict[ActionEncodingKey.typeKey.rawValue] = ActionEncodingKey.readButton.rawValue.value
            dict[ActionEncodingKey.port.rawValue] = port.value
            dict[ActionEncodingKey.key.rawValue] = key.value
            
        case .readTouchSensor(let port):
            dict[ActionEncodingKey.typeKey.rawValue] = ActionEncodingKey.readTouchSensor.rawValue.value
            dict[ActionEncodingKey.port.rawValue] = port.value
            
        case .readPotentiometer(let port):
            dict[ActionEncodingKey.typeKey.rawValue] = ActionEncodingKey.readPotentiometer.rawValue.value
            dict[ActionEncodingKey.port.rawValue] = port.value
            
        case .readLimitSwitch(let port, let slot):
            dict[ActionEncodingKey.typeKey.rawValue] = ActionEncodingKey.readLimitSwitch.rawValue.value
            dict[ActionEncodingKey.port.rawValue] = port.value
            dict[ActionEncodingKey.slot.rawValue] = slot.value
            
        case .readCompass(let port):
            dict[ActionEncodingKey.typeKey.rawValue] = ActionEncodingKey.readCompass.rawValue.value
            dict[ActionEncodingKey.port.rawValue] = port.value
            
        case .setLEDPanel(let port, let text):
            dict[ActionEncodingKey.typeKey.rawValue] = ActionEncodingKey.setLEDPanel.rawValue.value
            dict[ActionEncodingKey.port.rawValue] = port.value
            dict[ActionEncodingKey.text.rawValue] = text.value
            
        default: break
        }
        return .dictionary(dict)
    }
}

extension RJ25Port: SPMessageConstructible {
    public init?(_ value: PlaygroundValue) {
        guard let intValue = value.intValue(),
        let result = RJ25Port(rawValue: UInt8(intValue)) else {
            return nil
        }
        self = result
    }
    
    public var value: PlaygroundValue {
        return Int(rawValue).value
    }
}

extension RJ25Slot: SPMessageConstructible {
    public init?(_ value: PlaygroundValue) {
        guard let intValue = value.intValue(),
            let result = RJ25Slot(rawValue: UInt8(intValue)) else {
                return nil
        }
        self = result
    }
    
    public var value: PlaygroundValue {
        return Int(rawValue).value
    }
}

extension RGBLEDPosition: SPMessageConstructible {
    public init?(_ value: PlaygroundValue) {
        guard let intValue = value.intValue(),
            let result = RGBLEDPosition(rawValue: UInt8(intValue)) else {
                return nil
        }
        self = result
    }
    
    public var value: PlaygroundValue {
        return Int(rawValue).value
    }
}

extension ShutterAction: SPMessageConstructible {
    public init?(_ value: PlaygroundValue) {
        guard let intValue = value.intValue(),
            let result = ShutterAction(rawValue: UInt8(intValue)) else {
                return nil
        }
        self = result
    }
    
    public var value: PlaygroundValue {
        return Int(rawValue).value
    }
}

extension MusicNotePitch: SPMessageConstructible {
    public init?(_ value: PlaygroundValue) {
        guard let intValue = value.intValue(),
            let result = MusicNotePitch(rawValue: intValue) else {
                return nil
        }
        self = result
    }
    
    public var value: PlaygroundValue {
        return rawValue.value
    }
}

extension MusicNoteDuration: SPMessageConstructible {
    public init?(_ value: PlaygroundValue) {
        guard let intValue = value.intValue(),
            let result = MusicNoteDuration(rawValue: intValue) else {
                return nil
        }
        self = result
    }
    
    public var value: PlaygroundValue {
        return rawValue.value
    }
}

extension PhysicalJoystickAxis: SPMessageConstructible {
    public init?(_ value: PlaygroundValue) {
        guard let intValue = value.intValue(),
            let result = PhysicalJoystickAxis(rawValue: UInt8(intValue)) else {
                return nil
        }
        self = result
    }
    
    public var value: PlaygroundValue {
        return Int(rawValue).value
    }
}

extension HumitureMode: SPMessageConstructible {
    public init?(_ value: PlaygroundValue) {
        guard let intValue = value.intValue(),
            let result = HumitureMode(rawValue: UInt8(intValue)) else {
                return nil
        }
        self = result
    }
    
    public var value: PlaygroundValue {
        return Int(rawValue).value
    }
}

extension ButtonState: SPMessageConstructible {
    public init?(_ value: PlaygroundValue) {
        guard let intValue = value.intValue(),
            let result = ButtonState(rawValue: UInt8(intValue)) else {
                return nil
        }
        self = result
    }
    
    public var value: PlaygroundValue {
        return Int(rawValue).value
    }
}

extension GyroAxis: SPMessageConstructible {
    public init?(_ value: PlaygroundValue) {
        guard let intValue = value.intValue(),
            let result = GyroAxis(rawValue: UInt8(intValue)) else {
                return nil
        }
        self = result
    }
    
    public var value: PlaygroundValue {
        return Int(rawValue).value
    }
}

extension ButtonKey: SPMessageConstructible {
    public init?(_ value: PlaygroundValue) {
        guard let intValue = value.intValue(),
            let result = ButtonKey(rawValue: UInt8(intValue)) else {
                return nil
        }
        self = result
    }
    
    public var value: PlaygroundValue {
        return Int(rawValue).value
    }
}
