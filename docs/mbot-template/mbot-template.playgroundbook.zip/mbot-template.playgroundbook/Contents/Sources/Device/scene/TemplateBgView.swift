//
//  TemplateBgView.swift
//  Book_Sources
//
//  Created by CatchZeng on 2018/10/11.
//

import Foundation
import UIKit

class TemplateBgView: UIView {
    private var bgView: UIImageView!
    private var connectedBgView: UIImageView!
    private var connectShadeView = UIImageView(image: UIImage(named: "main-connect-shade"))
    private var neuronImageView: UIImageView!
    private var isConnected: Bool = false
    
    func config() {
        setupBgView()
        setupConnectedBgView()
    }
    
    public func refresh(screenMode: ScreenMode, frame: CGRect) {
        refreshShadeView(frame: frame)
        
        switch screenMode {
        case .hFull:
            bgView.contentMode = .topLeft
            connectedBgView.contentMode = .topLeft
            connectShadeView.contentMode = .scaleToFill
            
        case .hHalf:
            bgView.contentMode = .scaleAspectFit
            connectedBgView.contentMode = .scaleAspectFit
            connectShadeView.contentMode = .scaleAspectFit
            
        case .vHalf:
            bgView.contentMode = .topLeft
            connectedBgView.contentMode = .topLeft
            connectShadeView.contentMode = .scaleAspectFit
            
        case .vFull:
            bgView.contentMode = .topLeft
            connectedBgView.contentMode = .topLeft
            connectShadeView.contentMode = .scaleToFill
        }
    }
    
    public func changeToConnected() {
        isConnected = true
        bgView.isHidden = false
        connectedBgView.isHidden = false
        connectedBgView.alpha = 0.0
        
        let width = frame.width
        let height = width*1.287
        let y = connectedBgView.frame.height
        connectShadeView.frame = CGRect(x: 0, y: y, width: width, height: height)
        
        let finalY: CGFloat = 109.0
        UIView.animate(withDuration: 0.5, animations: {
            self.connectedBgView.alpha = 1.0
            self.bgView.alpha = 0.0
            self.connectShadeView.frame = CGRect(x: 0, y: finalY, width: width, height: height)
        }) { (_) in
            self.bgView.isHidden = true
        }
    }
    
    public func changeToDisConnected() {
        isConnected = false
        bgView.isHidden = false
        connectedBgView.isHidden = false
        bgView.alpha = 0.0
        
        let width = frame.width
        let height = width*1.287
        let y = connectedBgView.frame.height
        UIView.animate(withDuration: 0.5, animations: {
            self.bgView.alpha = 1.0
            self.connectedBgView.alpha = 0.0
            self.connectShadeView.frame = CGRect(x: 0, y: y, width: width, height: height)
        }) { (_) in
            self.connectedBgView.isHidden = true
        }
    }
    
    private func refreshShadeView(frame: CGRect) {
        let width = frame.width
        let height = width*1.287
        if isConnected {
            let y: CGFloat = 109.0
            connectShadeView.frame = CGRect(x: 0, y: y, width: width, height: height)
        } else {
            let y = connectedBgView.frame.height
            self.connectShadeView.frame = CGRect(x: 0, y: y, width: width, height: height)
        }
    }
    
    fileprivate func setupBgView() {
        bgView = UIImageView(image: UIImage(named: "main-bg"))
        bgView.contentMode = .scaleAspectFit
        addSubview(bgView)
        bgView.snp.makeConstraints { (make) in
            make.edges.equalTo(self)
        }
        bgView.isHidden = false
        
        neuronImageView = UIImageView(image: UIImage(named: "main-neuron"))
        neuronImageView.contentMode = .scaleAspectFit
        addSubview(neuronImageView)
        neuronImageView.snp.makeConstraints { (make) in
            make.center.equalTo(self)
        }
    }
    
    fileprivate func setupConnectedBgView() {
        connectedBgView = UIImageView(image: UIImage(named: "main-bg-connect"))
        connectedBgView.contentMode = .scaleAspectFit
        addSubview(connectedBgView)
        connectedBgView.snp.makeConstraints { (make) in
            make.edges.equalTo(self)
        }
        connectedBgView.isHidden = true
        
        connectedBgView.addSubview(connectShadeView)
        connectShadeView.frame = CGRect.zero
        connectShadeView.contentMode = .scaleAspectFit
    }
}
