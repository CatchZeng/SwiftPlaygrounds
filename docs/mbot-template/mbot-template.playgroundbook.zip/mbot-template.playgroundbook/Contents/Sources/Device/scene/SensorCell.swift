//
//  SensorCell.swift
//  Book_Sources
//
//  Created by CatchZeng on 2018/10/12.
//

import Foundation
import UIKit

class SensorCell: UITableViewCell {
    static let identifier = "SensorCell"
    private var containerView: UIView!
    private var iconView: UIImageView!
    private var nameLabel: UILabel!
    private var additionalLabel: UILabel!
    private var numberBg: RoundedCornerView!
    private var numLabel: UILabel!
    
    required init?(coder aDecoder: NSCoder) {
        super.init(coder: aDecoder)
        commonInit()
    }
    
    override init(style: UITableViewCellStyle, reuseIdentifier: String?) {
        super.init(style: style, reuseIdentifier: reuseIdentifier)
        commonInit()
    }
    
    public func config(sensor: SensorWithValue) {
        nameLabel.text = sensor.type.name
        iconView.image = sensor.type.icon
        if let value = sensor.value.first {
            numLabel.text = "\(value)"
        } else {
            numLabel.text = "0"
        }
        
        if let port = sensor.port {
            var portValue = Int(port.rawValue) == 0 ? "board" : "\(port)"
            if sensor.type == .light && Int(port.rawValue) == 6 {
                portValue = "board"
            }
            
            if let slot = sensor.slot {
                additionalLabel.text = "port: \(portValue) slot: \(slot)"
            } else {
                additionalLabel.text = "port: \(portValue)"
            }
        } else {
            additionalLabel.text = ""
        }
        
        configColor(sensor: sensor)
    }
    
    private func configColor(sensor: SensorWithValue) {
        numLabel.textColor = UIColor(red: 1.0, green: 75.0/255.0, blue: 38.0/255.0, alpha: 1.0)
        
        guard sensor.value.first == 1,
            sensor.type == .boardButton || sensor.type == .touch || sensor.type == .fourButtons || sensor.type == .limitSwitch
            else {
                return
        }
        numLabel.textColor = UIColor(red: 11.0/255.0, green: 200.0/255.0, blue: 136.0/255.0, alpha: 1.0)
    }
    
    private func commonInit() {
        backgroundColor = UIColor.clear
        selectionStyle = .none
        setupContainerView()
        setupIconView()
        setupNameLabel()
        setupAdditionalLabel()
        setupNumberBg()
        setupNumLabel()
    }
    
    private func setupContainerView() {
        containerView = UIView(frame: CGRect.zero)
        containerView.backgroundColor = UIColor.white
        containerView.cornerRadius = 5
        addSubview(containerView)
        
        containerView.snp.makeConstraints { (make) in
            make.width.top.centerX.equalTo(self)
            make.height.equalTo(self).multipliedBy(0.8)
        }
    }
    
    private func setupIconView() {
        iconView = UIImageView(image: UIImage(named: "sensor-light"))
        iconView.contentMode = .scaleAspectFit
        containerView.addSubview(iconView)
        
        iconView.snp.makeConstraints { (make) in
            make.height.equalTo(containerView).multipliedBy(0.565)
            make.width.equalTo(iconView.snp.height).multipliedBy(1.849)
            make.left.equalTo(containerView).offset(20)
            make.centerY.equalTo(containerView)
        }
    }
    
    private func setupNameLabel() {
        nameLabel = UILabel(frame: CGRect.zero)
        nameLabel.text = "Light Sensor"
        nameLabel.font = UIFont.systemFont(ofSize: 20)
        nameLabel.textColor = UIColor(red: 0.39, green: 0.39, blue: 0.39, alpha: 1.0)
        containerView.addSubview(nameLabel)
        
        nameLabel.snp.makeConstraints { (make) in
            make.centerY.equalTo(containerView).multipliedBy(0.7)
            make.leading.equalTo(iconView.snp.trailing).offset(20)
        }
    }
    
    private func setupAdditionalLabel() {
        additionalLabel = UILabel(frame: CGRect.zero)
        additionalLabel.text = "port: 1"
        additionalLabel.font = UIFont.systemFont(ofSize: 20)
        additionalLabel.textColor = UIColor(red: 0.39, green: 0.39, blue: 0.39, alpha: 1.0)
        containerView.addSubview(additionalLabel)
        
        additionalLabel.snp.makeConstraints { (make) in
            make.centerY.equalTo(containerView).multipliedBy(1.3)
            make.leading.equalTo(iconView.snp.trailing).offset(20)
        }
    }
    
    private func setupNumberBg() {
        numberBg = RoundedCornerView(frame: CGRect.zero)
        numberBg.backgroundColor = UIColor(red: 0.96, green: 0.96, blue: 0.96, alpha: 1.0)
        containerView.addSubview(numberBg)
        
        numberBg.snp.makeConstraints { (make) in
            make.centerY.equalTo(containerView)
            make.height.equalTo(containerView).multipliedBy(0.6)
            make.width.equalTo(numberBg.snp.height)
            make.trailing.equalTo(containerView.snp.trailing).offset(-20)
        }
    }
    
    private func setupNumLabel() {
        numLabel = UILabel(frame: CGRect.zero)
        numLabel.text = "57"
        numLabel.font = UIFont.boldSystemFont(ofSize: 25)
        numLabel.textColor = UIColor(red: 1.0, green: 75/255.0, blue: 38/255.0, alpha: 1.0)
        numberBg.addSubview(numLabel)
        
        numLabel.snp.makeConstraints { (make) in
            make.center.equalTo(numberBg)
        }
    }
}
