//
//  TemplateViewController.swift
//  Book_Sources
//
//  Created by CatchZeng on 2018/10/11.
//

import UIKit

public class TemplateViewController: LiveViewController {

    private var bgView: TemplateBgView!
    private var containerView: SensorContainerView!
    
    override public func viewDidLoad() {
        super.viewDidLoad()
        setupBackground()
        setupContainerView()
        setBackgroundAudio(visible: false)
    }
    
    override public func viewDidLayoutSubviews() {
        super.viewDidLayoutSubviews()
        let screenMode = getScreenMode(frame: view.frame)
        bgView.refresh(screenMode: screenMode, frame: view.frame)
    }
    
    override public func didDisconnect() {
        self.bgView.changeToDisConnected()
        self.containerView.isHidden = true
    }
    
    override public func didPrepared() {
        self.bgView.changeToConnected()
        self.containerView.isHidden = false
    }
    
    public override func onStopRunning() {
        currentBot.setDCMotor(leftSpeed: 0, rightSpeed: 0)
        currentBot.setRGBLED(port: .board, slot: .slot2, position: .all, red: 0, green: 0, blue: 0)
    }
    
    public func appendSensor(type: SensorType, port: RJ25Port?, slot: RJ25Slot?, value: Float) {
        let sensor = SensorWithValue(type: type, oneValue: Int(value), port: port, slot: slot)
        containerView.addOrUpdate(sensor: sensor)
    }
    
    // MARK: Private Methods
    
    private func setupBackground() {
        bgView = TemplateBgView(frame: CGRect.zero)
        view.addSubview(bgView)
        bgView.snp.makeConstraints { (make) in
            make.edges.equalTo(self.view)
        }
        bgView.config()
    }
    
    private func setupContainerView() {
        containerView = SensorContainerView(frame: CGRect.zero)
        view.addSubview(containerView)
        containerView.snp.makeConstraints { (make) in
            make.edges.equalTo(self.view)
        }
        containerView.isHidden = true
    }
}
