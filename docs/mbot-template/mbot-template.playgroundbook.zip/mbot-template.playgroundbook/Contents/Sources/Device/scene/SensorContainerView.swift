//
//  SensorContainerView.swift
//  Book_Sources
//
//  Created by CatchZeng on 2018/10/12.
//

import Foundation
import UIKit

public struct SensorWithValue {
    var type: SensorType
    var value: [Int]
    var port: RJ25Port? = nil
    var slot: RJ25Slot? = nil
    
    public init(type: SensorType, value: [Int], port: RJ25Port? = nil, slot: RJ25Slot? = nil) {
        self.type = type
        self.value = value
        self.port = port
        self.slot = slot
    }
    
    public init(type: SensorType, oneValue: Int, port: RJ25Port? = nil, slot: RJ25Slot? = nil) {
        self.type = type
        self.value = [oneValue]
        self.port = port
        self.slot = slot
    }
}

class SensorContainerView: UIView {
    private var tableView: UITableView!
    private var sensors = [SensorWithValue]()
    private var isAdding = false
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        commonInit()
    }
    
    required init?(coder aDecoder: NSCoder) {
        super.init(coder: aDecoder)
        commonInit()
    }
    
    public func reload(sensors: [SensorWithValue]) {
        self.sensors = sensors
        tableView.reloadData()
    }
    
    public func addOrUpdate(sensor: SensorWithValue) {
        let index = findIndex(sensor: sensor)
        if index == -1 {
            add(sensor: sensor)
        } else {
            update(sensor: sensor, index: index)
        }
    }
    
    private func findIndex(sensor: SensorWithValue) -> Int {
        var row = -1
        let count = sensors.count
        for i in 0..<count {
            let index = count-i-1
            let sensorOld = sensors[index]
            if sensorOld.type == sensor.type && sensorOld.port == sensor.port && sensorOld.slot == sensor.slot {
                row = index
                break
            }
        }
        
        return row
    }
    
    public func add(sensor: SensorWithValue) {
        var indexPaths = [IndexPath]()
        let indexPath = IndexPath(row: sensors.count, section: 0)
        indexPaths.append(indexPath)
        
        sensors.append(sensor)
        
        self.isAdding = true
        
        tableView.beginUpdates()
        tableView.insertRows(at: indexPaths, with: .automatic)
        tableView.endUpdates()
        
        GCDDelay.delay(0.5) { [weak self] in
            self?.isAdding = false
        }
    }
    
    public func remove(sensor: SensorType) {
        let count = sensors.count
        for i in 0..<count {
            let blockWithValue = sensors[count-i-1]
            if blockWithValue.type == sensor {
                sensors.remove(at: count-i-1)
                break
            }
        }
        
        tableView.reloadData()
    }
    
    public func update(sensor: SensorWithValue, index: Int) {
        if index == -1 {
            return
        }
        
        var sensorOld = sensors[index]
        if sensorOld.value == sensor.value {
            return
        }
        
        sensorOld.value = sensor.value
        sensors[index] = sensorOld
        
        var indexPaths = [IndexPath]()
        let indexPath = IndexPath(row: index, section: 0)
        indexPaths.append(indexPath)
        
        if isAdding {
            GCDDelay.delay(0.5) { [weak self] in
                self?.tableView.reloadRows(at: indexPaths, with: .none)
            }
        } else {
            tableView.reloadData()
        }
    }
    
    private func commonInit() {
        tableView = UITableView(frame: CGRect.zero)
        tableView.dataSource = self
        tableView.delegate = self
        tableView.backgroundColor = UIColor.clear
        tableView.separatorStyle = .none
        tableView.tableFooterView = UIView()
        self.addSubview(tableView)
        
        tableView.snp.makeConstraints { (make) in
            make.width.equalTo(460)
            make.bottom.equalToSuperview().offset(-75)
            make.top.equalTo(130)
            make.centerX.equalTo(self)
        }
    }
}

extension SensorContainerView: UITableViewDelegate, UITableViewDataSource {
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return sensors.count
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 120
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let sensor = sensors[indexPath.row]
        if let cell = tableView.dequeueReusableCell(withIdentifier: SensorCell.identifier) as? SensorCell {
            cell.config(sensor: sensor)
            return cell
        } else {
            let cell = SensorCell(style: .default, reuseIdentifier: SensorCell.identifier)
            cell.config(sensor: sensor)
            return cell
        }
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
    }
}
