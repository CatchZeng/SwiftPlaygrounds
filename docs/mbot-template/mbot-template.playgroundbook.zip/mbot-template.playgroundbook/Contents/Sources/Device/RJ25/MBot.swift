//
//  MBot.swift
//  mZero-iOS
//
//  Created by CatchZeng on 2017/3/20.
//  Copyright © 2017年 Shenzhen Maker Works Technology Co., Ltd. All rights reserved.
//

import Foundation

public class MBot: NSObject, CenterListener {
    private var index = 0
    fileprivate var valueCallbacks: [Int : ((Float) -> Void)] = [:]
    private let parser = RJ25DataParser()
    fileprivate let interpreter = RJ25DataInterpreter()
    
    private var manager: SPBLECenter {
        return SPBLECenter.shared
    }
    
    public override init() {
        super.init()
        parser.delegate = self
        manager.addListener(listener: self)
    }
    
    deinit {
        manager.removeListener(listener: self)
    }
    
    public func center<C>(center: C, device: Device, didReceive data: Result<Decodable>) where C : Center {
        if case let .success(d) = data, let model = d as? Data {
            onReceivedData(model)
        }
    }
    
    // MARK: Public Methods
    
    public func setDCMotor(leftSpeed: Int, rightSpeed: Int) {
        send(command: JoystickCommand(leftSpeed: leftSpeed, rightspeed: rightSpeed))
    }
    
    public func setFan(port: RJ25Port, speed: Int) {
        send(command: DCMotorCommand(port: port, speed: speed))
    }
    
    public func setRGBLED(port: RJ25Port,
                          slot: RJ25Slot,
                          position: RGBLEDPosition,
                          red: Int,
                          green: Int,
                          blue: Int) {
        let command = RGBLEDCommand(port: port,
                                    slot: slot,
                                    position: position,
                                    red: red,
                                    green: green,
                                    blue: blue,
                                    brightness: 1.0)
        send(command: command)
    }
    
    public func setShutter(port: RJ25Port, action: ShutterAction) {
        let command = ShutterCommand(port: port, action: action)
        send(command: command)
    }
    
    public func setServo(port: RJ25Port,
                         slot: RJ25Slot,
                         angle: Int) {
        let command = ServoCommand(port: port,
                                   slot: slot,
                                   angle: angle)
        send(command: command)
    }
    
    public func setSevenSegmentsLED(port: RJ25Port, value: Float) {
        let command = SevenSegmentsLEDCommand(port: port, value: value)
        send(command: command)
    }
    
    public func setBuzzer(pitch: MusicNotePitch, duration: MusicNoteDuration) {
        send(command: BuzzerCommand(pitch: pitch, duration: duration))
    }
    
    public func setLEDPanel(port: RJ25Port, text: String) {
        let command = FacePanelCharacterCommand(port: port, offsetX: 0, offsetY: 0, character: text)
        send(command: command)
    }
    
    public func sendInfrared(message: String) {
        let nextIndex = getNextIndex()
        send(command: InfraredSendCommand(index: UInt8(nextIndex), msg: message))
    }
    
    public func readUltrasonicSensor(_ port: RJ25Port = .port3, callback:@escaping ((Float) -> Void)) {
        let nextIndex = getNextIndex()
        valueCallbacks.updateValue(callback, forKey: nextIndex)
        send(command: UltraSonicCommand(index: UInt8(nextIndex), port: port))
    }
    
    public func readLightSensor(_ port: RJ25Port = .port6, callback:@escaping ((Float) -> Void)) {
        let nextIndex = getNextIndex()
        valueCallbacks.updateValue(callback, forKey: nextIndex)
        send(command: LightnessCommand(index: UInt8(nextIndex), port: port))
    }
    
    public func readLineFollowerSensor(_ port: RJ25Port = .port2, callback:@escaping ((Float) -> Void)) {
        let nextIndex = getNextIndex()
        valueCallbacks.updateValue(callback, forKey: nextIndex)
        send(command: LineFollowerCommand(index: UInt8(nextIndex), port: port))
    }
    
    public func readJoystick(port: RJ25Port, axis: PhysicalJoystickAxis, callback:@escaping ((Float) -> Void)) {
        let nextIndex = getNextIndex()
        valueCallbacks.updateValue(callback, forKey: nextIndex)
        let command = PhysicalJoystickCommand(index: UInt8(nextIndex), port: port, axis: axis)
        send(command: command)
    }
    
    public func readTemperatureSensor(port: RJ25Port, slot: RJ25Slot, callback:@escaping ((Float) -> Void)) {
        let nextIndex = getNextIndex()
        valueCallbacks.updateValue(callback, forKey: nextIndex)
        let command = TemperatureCommand(index: UInt8(nextIndex), port: port, slot: slot)
        send(command: command)
    }
    
    public func readHumitureSensor(port: RJ25Port, mode: HumitureMode, callback:@escaping ((Float) -> Void)) {
        let nextIndex = getNextIndex()
        valueCallbacks.updateValue(callback, forKey: nextIndex)
        let command = HumitureCommand(index: UInt8(nextIndex), port: port, mode: mode)
        send(command: command)
    }
    
    public func readSoundSensor(port: RJ25Port, callback:@escaping ((Float) -> Void)) {
        let nextIndex = getNextIndex()
        valueCallbacks.updateValue(callback, forKey: nextIndex)
        let command = VolumeCommand(index: UInt8(nextIndex), port: port)
        send(command: command)
    }
    
    public func readOnboardButton(state: ButtonState, callback:@escaping ((Float) -> Void)) {
        let nextIndex = getNextIndex()
        valueCallbacks.updateValue(callback, forKey: nextIndex)
        let command = BoardButtonCommand(index: UInt8(nextIndex), state: state)
        send(command: command)
    }
    
    public func readGyroSensor(port: RJ25Port, axis: GyroAxis, callback:@escaping ((Float) -> Void)) {
        let nextIndex = getNextIndex()
        valueCallbacks.updateValue(callback, forKey: nextIndex)
        let command = GyroCommand(index: UInt8(nextIndex), axis: axis)
        send(command: command)
    }
    
    public func readFlameSensor(port: RJ25Port, callback:@escaping ((Float) -> Void)) {
        let nextIndex = getNextIndex()
        valueCallbacks.updateValue(callback, forKey: nextIndex)
        let command = FlameCommand(index: UInt8(nextIndex), port: port)
        send(command: command)
    }
    
    public func readGasSensor(port: RJ25Port, callback:@escaping ((Float) -> Void)) {
        let nextIndex = getNextIndex()
        valueCallbacks.updateValue(callback, forKey: nextIndex)
        let command = GasCommand(index: UInt8(nextIndex), port: port)
        send(command: command)
    }
    
    public func readButton(port: RJ25Port, key: ButtonKey, callback:@escaping ((Float) -> Void)) {
        let nextIndex = getNextIndex()
        valueCallbacks.updateValue(callback, forKey: nextIndex)
        let command = FourButtonsCommand(index: UInt8(nextIndex), port: port, key: key)
        send(command: command)
    }
    
    public func readTouchSensor(port: RJ25Port, callback:@escaping ((Float) -> Void)) {
        let nextIndex = getNextIndex()
        valueCallbacks.updateValue(callback, forKey: nextIndex)
        let command = TouchCommand(index: UInt8(nextIndex), port: port)
        send(command: command)
    }
    
    public func readPotentiometer(port: RJ25Port, callback:@escaping ((Float) -> Void)) {
        let nextIndex = getNextIndex()
        valueCallbacks.updateValue(callback, forKey: nextIndex)
        let command = PotentiometerCommand(index: UInt8(nextIndex), port: port)
        send(command: command)
    }
    
    public func readLimitSwitch(port: RJ25Port, slot: RJ25Slot, callback:@escaping ((Float) -> Void)) {
        let nextIndex = getNextIndex()
        valueCallbacks.updateValue(callback, forKey: nextIndex)
        let command = LimitSwitchCommand(index: UInt8(nextIndex), port: port, slot: slot)
        send(command: command)
    }
    
    public func readCompass(port: RJ25Port, callback:@escaping ((Float) -> Void)) {
        let nextIndex = getNextIndex()
        valueCallbacks.updateValue(callback, forKey: nextIndex)
        let command = CompassCommand(index: UInt8(nextIndex), port: port)
        send(command: command)
    }
    
    @objc private func onReceivedData(_ data: Data) {
        parser.addReceived(data: data)
    }
    
    private func getNextIndex() -> Int {
        let index = self.index
        self.index += 1
        if self.index >= 255 {
            self.index = 128
        }
        return index
    }
    
    private func send(command: MakeblockCommand) {
        manager.send(data: command.data)
    }
}

extension MBot: DataParserDelegate {
    public func onParseData(_ data: Data) {
        interpreter.interpreter(data: data) { (index, value) in
            if let callback = valueCallbacks[index] {
                callback(value)
            }
        }
    }
    
    public func onParseErrorData(_ data: Data) { }
    
    public func onBufferOverflow(length: Int) { }
}
