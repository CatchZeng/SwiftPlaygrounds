//#-hidden-code
import PlaygroundSupport
import UIKit
//#-end-hidden-code
/*:#localized(key: "Chapter01Page01")
*/
//#-hidden-code
playgroundPrologue()
//#-end-hidden-code
//#-code-completion(everything, hide)
//#-code-completion(identifier, show, stop(), wait(duration:), setDCMotor(leftSpeed:rightSpeed:), moveForward(speed:), moveBackward(speed:), moveLeft(speed:), moveRight(speed:), setLEDStrip(port:slot:color:), setRGBLED(port:position:color:), setOnboardRGBLED(position:color:), setShutter(port:action:), set7SegmentDisplay(port:value:), play(note:beat:), sendInfrared(message:), startFan(port:), stopFan(port:), setServo(port:slot:angle:), setLEDPanel(port:text:))
//#-code-completion(identifier, show, readOnboardLightSensor(), readUltrasonicSensor(port:), readLightSensor(port:), readLineFollowerSensor(port:), readJoystick(port:axis:), readTemperatureSensor(port:slot:), readHumitureSensor(port:mode:), readSoundSensor(port:), readOnboardButton(), readGyroSensor(port:axis:), readFlameSensor(port:), readGasSensor(port:), readButton(port:key:), readTouchSensor(port:), readPotentiometer(port:), readLimitSwitch(port:slot:), readCompass(port:))
//#-code-completion(identifier, show, .)
//#-code-completion(identifier, show, RJ25Port, port1, port2, port3, port4)
//#-code-completion(identifier, show, RJ25Slot, slot1, slot2)
//#-code-completion(identifier, show, RGBLEDPosition, all, led1, led2, led3, led4)
//#-code-completion(identifier, show, MusicNotePitch, c4, d4, e4, f4, g4, a4, b4, c5)
//#-code-completion(identifier, show, MusicNoteDuration, whole, half, quarter, eighth, sixteenth)
//#-code-completion(identifier, show, ShutterAction, release, pressed, stopFocusing, startFocusing)
//#-code-completion(identifier, show, PhysicalJoystickAxis, x, y)
//#-code-completion(identifier, show, HumitureMode, humidity, temperature)
//#-code-completion(identifier, show, ButtonState, pressed, normal)
//#-code-completion(identifier, show, GyroAxis, x, y, z)
//#-code-completion(identifier, show, ButtonKey, key1, key2, key3, key4)
//#-code-completion(keyword, show, for, func, if, var, while)
//#-hidden-code
DispatchQueue.global().async {
//#-end-hidden-code
//#-editable-code Tap to enter code
//#-end-editable-code
//#-hidden-code
}
//Loader.sharedTaskMgr.sendTasks()
//#-end-hidden-code
