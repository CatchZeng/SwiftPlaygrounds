//
//  Commands.swift
//
//  Copyright © 2016,2017 Apple Inc. All rights reserved.
//

import PlaygroundSupport
import Foundation
import UIKit

// MARK: V1.0 API

public func setDCMotor(leftSpeed: Int, rightSpeed: Int) {
    ActionTool.setDCMotor(leftSpeed: leftSpeed, rightSpeed: rightSpeed)
}

public func play(note: MusicNotePitch, beat: MusicNoteDuration) {
    ActionTool.play(note: note, beat: beat)
}

public func setLEDStrip(port: RJ25Port,
                     slot: RJ25Slot,
                     color: UIColor) {
    ActionTool.setLEDStrip(port: port,
                        slot: slot,
                        color: color)
}

public func setRGBLED(port: RJ25Port,
                   position: RGBLEDPosition,
                   color: UIColor) {
    ActionTool.setRGBLED(port: port,
                      slot: .slot2,
                      position: position,
                      color: color)
}

public func setOnboardRGBLED(position: RGBLEDPosition, color: UIColor) {
    ActionTool.setOnboardRGBLED(position: position, color: color)
}

public func setShutter(port: RJ25Port, action: ShutterAction) {
    ActionTool.setShutter(port: port, action: action)
}

public func set7SegmentDisplay(port: RJ25Port, value: Float) {
    ActionTool.set7SegmentDisplay(port: port, value: value)
}

public func startFan(port: RJ25Port) {
    ActionTool.setFan(port: port, speed: 255)
}

public func stopFan(port: RJ25Port) {
    ActionTool.setFan(port: port, speed: -255)
}

public func setServo(port: RJ25Port, slot: RJ25Slot, angle: Int) {
    ActionTool.setServo(port: port, slot: slot, angle: angle)
}

public func setLEDPanel(port: RJ25Port, text: String) {
    ActionTool.setLEDPanel(port: port, text: text)
}

public func sendInfrared(message: String) {
    ActionTool.sendInfrared(message: message)
}

public func readUltrasonicSensor(port: RJ25Port = .port3) -> Float {
    wait(duration: 0.01)
    ActionTool.readUltrasonicSensor(port: port)
    
    let t1=CACurrentMediaTime()
    while contentListenr.ultrasonicValus[Int(port.rawValue)] == nil {
        let t2=CACurrentMediaTime()
        if (t2 - t1) > 0.5 {
            break
        }
    }
    
    if let value = contentListenr.ultrasonicValus[Int(port.rawValue)] {
        return value
    }
    return 400
}

public func readLightSensor(port: RJ25Port) -> Float {
    wait(duration: 0.01)
    ActionTool.readLightSensor(port: port)
    
    let t1=CACurrentMediaTime()
    while contentListenr.lightValus[Int(port.rawValue)] == nil {
        let t2=CACurrentMediaTime()
        if (t2 - t1) > 0.5 {
            break
        }
    }
    
    if let value = contentListenr.lightValus[Int(port.rawValue)] {
        return value
    }
    return 0
}

public func readOnboardLightSensor() -> Float {
    wait(duration: 0.01)
    ActionTool.readLightSensor(port: .port6)
    
    let t1=CACurrentMediaTime()
    while contentListenr.lightValus[6] == nil {
        let t2=CACurrentMediaTime()
        if (t2 - t1) > 0.5 {
            break
        }
    }
    
    if let value = contentListenr.lightValus[6] {
        return value
    }
    return 0
}

public func readLineFollowerSensor(port: RJ25Port = .port2) -> Int {
    wait(duration: 0.01)
    ActionTool.readLineFollowerSensor(port: port)
    
    let t1=CACurrentMediaTime()
    while contentListenr.lineFollowerValues[Int(port.rawValue)] == nil {
        let t2=CACurrentMediaTime()
        if (t2 - t1) > 0.5 {
            break
        }
    }
    
    if let value = contentListenr.lineFollowerValues[Int(port.rawValue)] {
        return value
    }
    return 0
}

public func readJoystick(port: RJ25Port, axis: PhysicalJoystickAxis) -> Int {
    wait(duration: 0.01)
    ActionTool.readJoystick(port: port, axis: axis)
    
    let t1=CACurrentMediaTime()
    while contentListenr.joystickValues[Int(port.rawValue)] == nil {
        let t2=CACurrentMediaTime()
        if (t2 - t1) > 0.5 {
            break
        }
    }
    
    if let value = contentListenr.joystickValues[Int(port.rawValue)] {
        return value
    }
    return 0
}

public func readTemperatureSensor(port: RJ25Port, slot: RJ25Slot) -> Float {
    wait(duration: 0.01)
    ActionTool.readTemperatureSensor(port: port, slot: slot)
    
    let t1=CACurrentMediaTime()
    let key = "\(Int(port.rawValue))-\(Int(slot.rawValue))"
    while contentListenr.temperatureValues[key] == nil {
        let t2=CACurrentMediaTime()
        if (t2 - t1) > 0.5 {
            break
        }
    }
    
    if let value = contentListenr.temperatureValues[key] {
        return value
    }
    return 0
}

public func readHumitureSensor(port: RJ25Port, mode: HumitureMode) -> Float {
    wait(duration: 0.01)
    ActionTool.readHumitureSensor(port: port, mode: mode)
    
    let t1=CACurrentMediaTime()
    while contentListenr.humitureValus[Int(port.rawValue)] == nil {
        let t2=CACurrentMediaTime()
        if (t2 - t1) > 0.5 {
            break
        }
    }
    
    if let value = contentListenr.humitureValus[Int(port.rawValue)] {
        return value
    }
    return 0
}

public func readSoundSensor(port: RJ25Port) -> Float {
    wait(duration: 0.01)
    ActionTool.readSoundSensor(port: port)
    
    let t1=CACurrentMediaTime()
    while contentListenr.volumeValus[Int(port.rawValue)] == nil {
        let t2=CACurrentMediaTime()
        if (t2 - t1) > 0.5 {
            break
        }
    }
    
    if let value = contentListenr.volumeValus[Int(port.rawValue)] {
        return value
    }
    return 0
}

public func readButton(port: RJ25Port, key: ButtonKey) -> Bool {
    wait(duration: 0.01)
    ActionTool.readButton(port: port, key: key)
    
    let t1=CACurrentMediaTime()
    while contentListenr.fourButtonsValus[Int(port.rawValue)] == nil {
        let t2=CACurrentMediaTime()
        if (t2 - t1) > 0.5 {
            break
        }
    }
    
    if let value = contentListenr.fourButtonsValus[Int(port.rawValue)] {
        return value
    }
    return false
}

public func readOnboardButton() -> Bool {
    wait(duration: 0.01)
    ActionTool.readOnboardButton(state: .pressed)
    
    let t1=CACurrentMediaTime()
    while contentListenr.boardButtonValus[7] == nil {
        let t2=CACurrentMediaTime()
        if (t2 - t1) > 0.5 {
            break
        }
    }
    
    if let value = contentListenr.boardButtonValus[7] {
        return value
    }
    return false
}

public func readGyroSensor(port: RJ25Port, axis: GyroAxis) -> Float {
    wait(duration: 0.01)
    ActionTool.readGyroSensor(port: port, axis: axis)
    
    let t1=CACurrentMediaTime()
    while contentListenr.gyroValus[Int(port.rawValue)] == nil {
        let t2=CACurrentMediaTime()
        if (t2 - t1) > 0.5 {
            break
        }
    }
    
    if let value = contentListenr.gyroValus[Int(port.rawValue)] {
        return value
    }
    return 0
}

public func readFlameSensor(port: RJ25Port) -> Float {
    wait(duration: 0.01)
    ActionTool.readFlameSensor(port: port)
    
    let t1=CACurrentMediaTime()
    while contentListenr.flameValus[Int(port.rawValue)] == nil {
        let t2=CACurrentMediaTime()
        if (t2 - t1) > 0.5 {
            break
        }
    }
    
    if let value = contentListenr.flameValus[Int(port.rawValue)] {
        return value
    }
    return 0
}

public func readGasSensor(port: RJ25Port) -> Float {
    wait(duration: 0.01)
    ActionTool.readGasSensor(port: port)
    
    let t1=CACurrentMediaTime()
    while contentListenr.gasValus[Int(port.rawValue)] == nil {
        let t2=CACurrentMediaTime()
        if (t2 - t1) > 0.5 {
            break
        }
    }
    
    if let value = contentListenr.gasValus[Int(port.rawValue)] {
        return value
    }
    return 0
}

public func readTouchSensor(port: RJ25Port) -> Bool {
    wait(duration: 0.01)
    ActionTool.readTouchSensor(port: port)
    
    let t1=CACurrentMediaTime()
    while contentListenr.touchValus[Int(port.rawValue)] == nil {
        let t2=CACurrentMediaTime()
        if (t2 - t1) > 0.5 {
            break
        }
    }
    
    if let value = contentListenr.touchValus[Int(port.rawValue)] {
        return value
    }
    return false
}

public func readPotentiometer(port: RJ25Port) -> Float {
    wait(duration: 0.01)
    ActionTool.readPotentiometer(port: port)
    
    let t1=CACurrentMediaTime()
    while contentListenr.potentiometerValus[Int(port.rawValue)] == nil {
        let t2=CACurrentMediaTime()
        if (t2 - t1) > 0.5 {
            break
        }
    }
    
    if let value = contentListenr.potentiometerValus[Int(port.rawValue)] {
        return value
    }
    return 0
}

public func readLimitSwitch(port: RJ25Port, slot: RJ25Slot) -> Bool {
    wait(duration: 0.01)
    ActionTool.readLimitSwitch(port: port, slot: slot)
    
    let t1=CACurrentMediaTime()
    let key = "\(Int(port.rawValue))-\(Int(slot.rawValue))"
    while contentListenr.limitSwitchValus[key] == nil {
        let t2=CACurrentMediaTime()
        if (t2 - t1) > 0.5 {
            break
        }
    }
    
    if let value = contentListenr.limitSwitchValus[key] {
        return value
    }
    return false
}

public func readCompass(port: RJ25Port) -> Float {
    wait(duration: 0.01)
    ActionTool.readCompass(port: port)
    
    let t1=CACurrentMediaTime()
    while contentListenr.compassValus[Int(port.rawValue)] == nil {
        let t2=CACurrentMediaTime()
        if (t2 - t1) > 0.5 {
            break
        }
    }
    
    if let value = contentListenr.compassValus[Int(port.rawValue)] {
        return value
    }
    return 0
}

// MARK: V0.1 API

public func wait(duration: Float) {
    ActionTool.wait(duration)
}

public func test(text: String) {
    ActionTool.testText("\(text)")
}

public func moveLeft(speed: Float) {
    ActionTool.moveLeft(speed: Int(speed))
}

public func moveRight(speed: Float) {
    ActionTool.moveRight(speed: Int(speed))
}

public func moveForward(speed: Float) {
    ActionTool.moveForward(speed: Int(speed))
}

public func moveBackward(speed: Float) {
    ActionTool.moveBackward(speed: Int(speed))
}

public func stop() {
    ActionTool.stop()
}

// MARK: deprecated API

@available(*, deprecated, message: "playSound(tone:meter:) will be removed in a future version. Pelase use play(note:beat) instead.")
public func playSound(tone: MusicNotePitch, meter: MusicNoteDuration) {
    ActionTool.play(note: tone, beat: meter)
}

@available(*, deprecated, message: "light will be removed in a future version. Pelase use readOnboardLightSensor() instead.")
public var light: Float {
    let value = readOnboardLightSensor()
    return Float(value)
}

@available(*, deprecated, message: "line will be removed in a future version. Pelase use readLineFollowerSensor(port:) instead.")
public var line: Int {
    return readLineFollowerSensor()
}

@available(*, deprecated, message: "ultrasonic will be removed in a future version. Pelase use readUltrasonicSensor(port:) instead.")
public var ultrasonic: Float {
    return readUltrasonicSensor()
}

@available(*, deprecated, message: "turnLED(item:color:) will be removed in a future version. Pelase use setOnboardRGBLED(position:color:) instead.")
public func turnLED(item: Int, color: UIColor) {
    if item == 0 {
        setOnboardRGBLED(position: .all, color: color)
    } else if item == 1 {
        setOnboardRGBLED(position: .led2, color: color)
    } else if item == 2 {
        setOnboardRGBLED(position: .led1, color: color)
    }
}

@available(*, deprecated, message: "sendInfraredMessage(message:) will be removed in a future version. Pelase use sendInfrared(message:) instead.")
public func sendInfraredMessage(message: String) {
    ActionTool.sendInfrared(message: message)
}

@available(*, deprecated, message: "startEngine(leftSpeed:rightSpeed:) will be removed in a future version. Pelase use setDCMotor(leftSpeed:rightSpeed:) instead.")
public func startEngine(leftSpeed: Float, rightSpeed: Float) {
    ActionTool.setDCMotor(leftSpeed: Int(leftSpeed), rightSpeed: Int(rightSpeed))
}
