//
//  QueueCommand.swift
//  Neuron
//
//  Created by CatchZeng on 2017/3/23.
//  Copyright © 2017-2018 Makeblock Co., Ltd. All rights reserved.
//

import UIKit

public enum QueueCommandState {
    case defalut
    case sending
    case error
    case cancel
    case success

    public var isFinished: Bool {
        switch self {
        case .error, .cancel, .success:
            return true
        default:
            return false
        }
    }
}

open class QueueCommand: NSObject {
    private var queue: [MakeblockCommand]
    private var sendQueue: [MakeblockCommand]?
    private var curCommand: MakeblockCommand?
    private var timeIntervals: [TimeInterval]
    private var state: QueueCommandState = .defalut {
        didSet {
            if sendQueue != nil {
                callback?(state, queue, curCommand, sendQueue!.count)
            }
        }
    }
    private let delayObject = "delayObject"
    private var sender: MakeblockSender

    public typealias QueueCommandCallback = ((_ state: QueueCommandState, _ queue: [MakeblockCommand], _ curCommand: MakeblockCommand?, _ left: Int) -> Void)
    public var callback: QueueCommandCallback?

    public init(queue: [MakeblockCommand], timeIntervals: [TimeInterval], sender: MakeblockSender) {
        self.queue = queue
        self.timeIntervals = timeIntervals
        self.sender = sender
    }

    open func execute(callback: QueueCommandCallback?) {
        self.callback = callback
        if queue.count < 1 || (queue.count != (timeIntervals.count+1)) {
            state = .error
            callback?(state, queue, nil, queue.count)
            return
        }
        curCommand = nil
        state = .defalut
        sendQueue = queue
        sendCommand()
    }

    open func cancel() {
        if sendQueue == nil {
            return
        }

        NSObject.cancelPreviousPerformRequests(withTarget: self,
                                               selector: #selector(self.sendCommand),
                                               object: delayObject)
        state = .cancel
        sendQueue!.removeAll()
        sendQueue = nil
    }

    private func send(command: MakeblockCommand) {
        sender.send(data: command.data)
    }

    @objc private func sendCommand() {
        if state == .cancel {//退出递归
            return
        }

        if let command = sendQueue!.first {
            curCommand = command
            send(command: command)
            sendQueue!.removeFirst()

            if sendQueue!.count < 1 {//已发送完毕
                state = .success

            } else {//更新进度
                state = .sending

                //发送下一条命令
                let didSend = queue.count - sendQueue!.count
                let delay = finalInterval(index: didSend - 1, timeIntervals: timeIntervals)
                self.perform(#selector(self.sendCommand), with: delayObject, afterDelay: delay)
            }

        } else {
            print("ERROR<QueueCommand>: command is nil")
            return
        }
    }

    /// 子类可重写该方法，针对特殊时间做处理
    open func finalInterval(index: Int, timeIntervals: [TimeInterval]) -> TimeInterval {
        return timeIntervals[index]
    }
}
