//
//  TaskResponder.swift
//  MBBlueToothCenter
//
//  Created by block Make on 2017/7/18.
//  Copyright © 2017年 block Make. All rights reserved.
//

import Foundation
import CoreBluetooth

public protocol TaskResponder {
    associatedtype Command: SPCommand
    var command: Command {get set}
    func respondTo(_ command: Command)
    func stop()
    init(command: Command)
}

extension TaskResponder {
    func execeute(finished: ((Bool)->Void)) {
        respondTo(command)
        finished(true)
    }
}

public class SPTaskResponder: TaskResponder {
    
    public typealias Command = MCommand
    public var command: Command
    var finishAction: ((AnyObject)->Void)?
    
    required public init(command: Command) {
        self.command = command
    }
    
    private var timers: [Timer] = []
    public func respondTo(_ command: MCommand) {
        switch command.action {
        case .wait(let duration):
            wait(duration)
        case .testText(let text):
            log(text)
        default:
            handle(command: command)
        }
    }
    
    // Override by subclass
    public func handle(command: MCommand) {
    }
    
    public func stop() {
        let delayTime: DispatchTime = DispatchTime.now() + DispatchTimeInterval.milliseconds(2)
        DispatchQueue.main.asyncAfter(deadline: delayTime) {
        }
    }
    
    public func stopAll() {
        timers.forEach { timer in
            timer.invalidate()
        }
        timers.removeAll()
        stop()
    }
    
    private func wait(_ duration: Float) {
    }
}
