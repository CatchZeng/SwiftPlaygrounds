 import PlaygroundSupport
import Foundation

public extension PlaygroundValue {

    public func arrayValue(_ key: String? = nil) -> [PlaygroundValue]? {
        if let pv = spValue(key), case let .array(arrayValue) = pv {
            return arrayValue
        } else {
            if case let .array(arrayValue) = self {
                return arrayValue
            }
        }
        return nil
    }

    public func dictValue(_ key: String? = nil) -> [String: PlaygroundValue]? {
        if let pv = spValue(key), case let .dictionary(dicValue) = pv {
            return dicValue
        } else {
            if case let .dictionary(dicValue) = self {
                return dicValue
            }
        }
        return nil
    }

    public func floatValue(_ key: String? = nil) -> Float? {
        if let pv = spValue(key), case let .floatingPoint(floatValue) = pv {
            return Float(floatValue)
        } else {
            if case let .floatingPoint(floatValue) = self {
                return Float(floatValue)
            }
        }
        return nil
    }

    public func intValue(_ key: String? = nil) -> Int? {
        if let pv = spValue(key), case let .integer(integerValue) = pv {
            return Int(integerValue)
        } else {
            if case let .integer(integerValue) = self {
                return Int(integerValue)
            }
        }
        return nil
    }

    public func boolValue(_ key: String? = nil) -> Bool? {
        if let pv = spValue(key), case let .boolean(booleanValue) = pv {
            return Bool(booleanValue)
        } else {
            if case let .boolean(booleanValue) = self {
                return Bool(booleanValue)
            }
        }
        return nil
    }

    public func stringValue(_ key: String? = nil) -> String? {
        if let pv = spValue(key), case let .string(stringValue) = pv {
            return stringValue
        } else {
            if case let .string(stringValue) = self {
                return stringValue
            }
        }
        return nil
    }

    public func spValue(_ key: String? = nil) -> PlaygroundValue? {
        if let key = key,
            case let .dictionary(dicValue) = self,
            let value = dicValue[key] {
            return value
        }
        return self
    }
}

public struct Color: SPMessageConstructible, Equatable {
    public static func == (lhs: Color, rhs: Color) -> Bool {
        return lhs.alpha == rhs.alpha && lhs.rgb == rhs.rgb
    }
    
    var rgb: (R: Float, G: Float, B: Float) = (0, 0, 0)
    var alpha: Float = 0
    public var value: PlaygroundValue {
        return .dictionary(["R": rgb.R.value, "G": rgb.G.value, "B": rgb.B.value, "alpha": alpha.value])
    }

    static public let red = Color.init(rgb: (255, 0, 0))
    static public let orange = Color.init(rgb: (230, 165, 25))
    static public let yellow = Color.init(rgb: (255, 255, 0))
    static public let green = Color.init(rgb: (0, 255, 0))
    static public let blue = Color.init(rgb: (0, 0, 255))
    static public let cyan = Color.init(rgb: (20, 166, 255))
    static public let purple = Color.init(rgb: (255, 0, 255))
    static public let off = Color.init(rgb: (0, 0, 0), alpha: 0)

    public init(rgb: (R: Float, G: Float, B: Float), alpha: Float = 1) {
        self.rgb = rgb
        self.alpha = alpha
    }

    public init?(_ value: PlaygroundValue) {
        guard case let .dictionary(dict) = value else {
            return nil
        }
        guard let r = dict["R"], let g = dict["G"], let b = dict["B"], let a = dict["alpha"] else {
            return nil
        }
        guard case let .floatingPoint(red) = r, case let .floatingPoint(green) = g, case let .floatingPoint(blue) = b, case let .floatingPoint(alpha) = a else {
            return nil
        }
        self.rgb = (Float(red), Float(green), Float(blue))
        self.alpha = Float(alpha)
    }
}

// MARK: SPMessageConstructor

public protocol SPMessageConstructor {
    var value: PlaygroundValue { get }
}

public protocol SPMessageConstructible: SPMessageConstructor {
    init?(_ value: PlaygroundValue)
}

// MARK: SPMessageConstructible Extensions

extension String: SPMessageConstructor {
    public var value: PlaygroundValue {
        return .string(self)
    }
}

extension Bool: SPMessageConstructible {
    public var value: PlaygroundValue {
        return .boolean(self)
    }

    public init?(_ value: PlaygroundValue) {
        guard case let .boolean(value) = value else { return nil }
        self = value
    }
}

extension Int: SPMessageConstructible {
    public var value: PlaygroundValue {
        return .integer(self)
    }

    public init?(_ value: PlaygroundValue) {
        guard case let .integer(value) = value else { return nil }

        self = value
    }
}

extension Float: SPMessageConstructible {
    public var value: PlaygroundValue {
        return .floatingPoint(Double(self))
    }

    public init?(_ value: PlaygroundValue) {
        guard case let .floatingPoint(floatValue) = value else { return nil }
        self = Float(floatValue)
    }
}
