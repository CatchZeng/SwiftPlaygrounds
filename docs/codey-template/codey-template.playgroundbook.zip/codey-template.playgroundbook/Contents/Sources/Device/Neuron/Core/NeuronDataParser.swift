//
//  NeuronDataParser.swift
//  Neuron
//
//  Created by CatchZeng on 2017/4/18.
//  Copyright © 2017-2018 Makeblock Co., Ltd. All rights reserved.
//

import Foundation

public protocol NeuronDataParserDelegate: class {
    func onParseData(_ data: Data)
    func onParseErrorData(_ data: Data)
    func onBufferOverflow(length: Int)
}

open class NeuronDataParser {
    private static let recvViewLength = 1024

    public weak var delegate: NeuronDataParserDelegate?

    private let prefix: UInt8 = 0xf0
    private let suffix: UInt8 = 0xf7

    var recvLength: Int = 0
    var beginRecv: Bool = false
    var recvView: [UInt8] = Array(repeating: 0x00, count: NeuronDataParser.recvViewLength)

    public init () {}

    public func addReceived(data: Data) {
        let bytes = data.bytes

        for i in 0..<data.count {
            if bytes[i] == prefix { // begin
                recvLength = 0
                beginRecv = true

            } else if bytes[i] == suffix { // end
                if !beginRecv { // never beigin
                    continue
                }

                if recvLength < 1 {
                    delegate?.onParseErrorData(Data(bytes: [prefix, suffix]))
                    continue
                }

                beginRecv = false

                //checksum
                var checksum: UInt8 = 0
                for j in 0..<recvLength - 1 {
                    checksum = checksum &+ recvView[j]
                }
                let sum = checksum & 0x7f
                let sum2 = recvView[recvLength - 1]

                //compose parse data
                var parse: [UInt8] = Array(repeating: 0x00, count: recvLength + 2)
                parse[0] = prefix

                for k in 0..<recvLength {
                    parse[k+1] = recvView[k]
                }
                parse[recvLength + 1] = suffix
                let parseData = Data(bytes: parse)

                if sum == sum2 {
                    delegate?.onParseData(parseData)
                } else {
                    delegate?.onParseErrorData(parseData)
                }

            } else { // middle
                if recvLength >= NeuronDataParser.recvViewLength {
                    delegate?.onBufferOverflow(length: recvLength)
                    recvLength = 0
                }

                recvView[recvLength] = bytes[i]
                recvLength += 1
            }
        }
    }
}
