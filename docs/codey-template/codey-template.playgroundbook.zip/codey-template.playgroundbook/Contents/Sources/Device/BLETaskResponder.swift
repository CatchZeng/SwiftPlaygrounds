//
//  BLETaskResponder.swift
//  Book_Sources
//
//  Created by CatchZeng on 2018/10/22.
//

import Foundation

public class BLETaskResponder: TaskResponder {
    public typealias Command = MCommand
    public var command: Command
    
    required public init(command: Command) {
        self.command = command
    }
    
    private var timers: [Timer] = []
    public func respondTo(_ command: MCommand) {
        switch command.action {
        case .wait(let duration):
            wait(duration)
        case .testText(let text):
            log(text)
        case .setDCMotor(let leftSpeed, let rightSpeed):
            setDCMotor(leftSpeed: leftSpeed, rightSpeed: rightSpeed)
        case .setLEDLight(let r, let g, let b):
            setLEDLight(r: r, g: g, b: b)
        case .playMusic(let type):
            playMusic(type: type)
        case .setFacePanel(let x, let y, let isOn):
            setFacePanel(x: x, y: y, isOn: isOn)
        case .setFacePanelType(let type):
            setFacePanel(type: type)
        case .clearFacePanel:
            clearFacePanel()
        case .playMusicNote(let note, let beat):
            playMusic(note: note, beat: beat)
        case .readLightSensor:
            readLightSensor()
        case .getButtonState:
            getButtonState()
        case .readPotentiometer:
            readPotentiometer()
        case .readSoundSensor:
            readSoundSensor()
        case .getGyro:
            getGryo()
        case .getShake:
            getShake()
        case .readColorSensor:
            readColorSensor()
        case .hasObstacle:
            hasObstacle()
        default:
            print("Default Action")
        }
    }
    
    private func wait(_ duration: Float) {
    }
    
    private func setDCMotor(leftSpeed: Int, rightSpeed: Int) {
        currentBot.setDCMotor(leftSpeed: leftSpeed, rightSpeed: rightSpeed)
    }
    
    private func setLEDLight(r: Int, g: Int, b: Int) {
        currentBot.setLEDLight(r: r, g: g, b: b)
    }
    
    private func playMusic(type: MusicType) {
        currentBot.playMusic(type: type)
    }
    
    private func setFacePanel(x: Int, y: Int, isOn: Bool) {
        currentBot.setFacePanel(x: x, y: y, isOn: isOn)
    }
    
    private func setFacePanel(type: FacePanelType) {
        currentBot.setFacePanel(type: type)
    }
    
    private func clearFacePanel() {
        currentBot.clearFacePanel()
    }
    
    private func playMusic(note: SoundNote, beat: SoundBeat) {
        currentBot.playMusic(note: note, beat: beat)
    }
    
    private func readLightSensor() {
        currentBot.readLightSensor { (value) in
            sendToContentsWithEnum(.readLightSensor(value))
        }
    }
    
    private func getButtonState() {
        currentBot.getButtonState { (buttonAPressed, buttonBPressed, buttonCPressed) in
            sendToContentsWithEnum(.buttonAPressed(buttonAPressed))
            sendToContentsWithEnum(.buttonBPressed(buttonBPressed))
            sendToContentsWithEnum(.buttonCPressed(buttonCPressed))
        }
    }
    
    private func readPotentiometer() {
        currentBot.readPotentiometer { (value) in
            sendToContentsWithEnum(.readPotentiometer(value))
        }
    }
    
    private func readSoundSensor() {
        currentBot.readSoundSensor { (value) in
            sendToContentsWithEnum(.readSoundSensor(value))
        }
    }
    
    private func hasObstacle() {
        currentBot.hasObstacle { (value) in
            sendToContentsWithEnum(.hasObstacle(value))
        }
    }
    
    private func getGryo() {
        currentBot.getGyro { (roll, pitch, yaw, accX, accY, accZ) in
            sendToContentsWithEnum(.roll(roll))
            sendToContentsWithEnum(.pitch(pitch))
            sendToContentsWithEnum(.yaw(yaw))
            sendToContentsWithEnum(.accX(accX))
            sendToContentsWithEnum(.accY(accY))
            sendToContentsWithEnum(.accZ(accZ))
        }
    }
    
    private func getShake() {
        currentBot.getShake { (value) in
            sendToContentsWithEnum(.shake(value))
        }
    }
    
    private func readColorSensor() {
        currentBot.readColorSensor { (value) in
            sendToContentsWithEnum(.color(value.rawValue))
        }
    }
    
    public func stop() {
        let delayTime: DispatchTime = DispatchTime.now() + DispatchTimeInterval.milliseconds(2)
        DispatchQueue.main.asyncAfter(deadline: delayTime) {
        }
    }
    
    public func stopAll() {
        timers.forEach { timer in
            timer.invalidate()
        }
        timers.removeAll()
        stop()
    }
}
