//
//  ActionTool+Codey.swift
//  Book_Sources
//
//  Created by CatchZeng on 2018/7/31.
//

import Foundation

extension ActionTool {
    
    static public func setDCMotor(leftSpeed: Int, rightSpeed: Int) {
        sendAction(.setDCMotor(leftSpeed: leftSpeed, rightSpeed: rightSpeed), duration: ActionTool.DefaultDuration)
    }
    
    static public func setLEDLight(r: Int, g: Int, b: Int) {
        sendAction(.setLEDLight(r: r, g: g, b: b), duration: ActionTool.DefaultDuration)
    }
    
    static public func playMusic(type: MusicType) {
        sendAction(.playMusic(type: type), duration: ActionTool.DefaultDuration)
    }
    
    static public func setFacePanel(x: Int, y: Int, isOn: Bool) {
        sendAction(.setFacePanel(x: x, y: y, isOn: isOn), duration: ActionTool.DefaultDuration)
    }
    
    static public func setFacePanel(type: FacePanelType) {
        sendAction(.setFacePanelType(type: type), duration: ActionTool.DefaultDuration)
    }
    
    static public func clearFacePanel() {
        sendAction(.clearFacePanel, duration: ActionTool.DefaultDuration)
    }
    
    static public func playMusic(note: SoundNote, beat: SoundBeat) {
        sendAction(.playMusicNote(note: note, beat: beat), duration: ActionTool.DefaultDuration)
    }
    
    static public func readLightSensor() {
        sendAction(.readLightSensor, duration: ActionTool.DefaultDuration)
    }
    
    static public func getButtonState() {
        sendAction(.getButtonState, duration: ActionTool.DefaultDuration)
    }
    
    static public func readPotentiometer() {
        sendAction(.readPotentiometer, duration: ActionTool.DefaultDuration)
    }
    
    static public func readSoundSensor() {
        sendAction(.readSoundSensor, duration: ActionTool.DefaultDuration)
    }
    
    static public func getGyro() {
        sendAction(.getGyro, duration: ActionTool.DefaultDuration)
    }
    
    static public func getShake() {
        sendAction(.getShake, duration: ActionTool.DefaultDuration)
    }
    
    static public func readColorSensor() {
        sendAction(.readColorSensor, duration: ActionTool.DefaultDuration)
    }
    
    static public func hasObstacle() {
        sendAction(.hasObstacle, duration: ActionTool.DefaultDuration)
    }
}
