import PlaygroundSupport

public enum ActionEncodingKey: String {
    case typeKey
    case idKey
    case testText
    case execute
    case wait
    case duration
    
    // Codey
    case setDCMotor
    case leftSpeed
    case rightSpeed
    
    case setLEDLight
    case r
    case g
    case b
    
    case playMusic
    case type
    
    case setFacePanel
    case x
    case y
    case isOn
    case setFacePanelType
    
    case clearFacePanel
    
    case playMusicNote
    case note
    case beat
    
    case readLightSensor
    case getButtonState
    case readPotentiometer
    case readSoundSensor
    case getGryo
    case getShake
    case readColorSensor
    case hasObstacle
}

public enum SPCommandAction {
    case none
    case testText(String)
    case execute
    case wait(duration: Float)
    
    // Codey
    case setDCMotor(leftSpeed: Int, rightSpeed: Int)
    case setLEDLight(r: Int, g: Int, b: Int)
    case playMusic(type: MusicType)
    case setFacePanel(x: Int, y: Int, isOn: Bool)
    case setFacePanelType(type: FacePanelType)
    case clearFacePanel
    case playMusicNote(note: SoundNote, beat: SoundBeat)
    case readLightSensor
    case getButtonState
    case readPotentiometer
    case readSoundSensor
    case getGyro
    case getShake
    case readColorSensor
    case hasObstacle
}

extension SPCommandAction: SPMessageConstructible {
    public init?(_ value: PlaygroundValue) {
        guard case let .dictionary(dict) = value, let typeV = dict[ActionEncodingKey.typeKey.rawValue], case let .string(type) = typeV else {
            return nil
        }
        
        switch type {
        case ActionEncodingKey.testText.rawValue:
            if let text = value.stringValue(ActionEncodingKey.idKey.rawValue) {
                self = SPCommandAction.testText(text)
            } else {
                return nil
            }
            
        case ActionEncodingKey.execute.rawValue:
            self = SPCommandAction.execute
            
        case ActionEncodingKey.wait.rawValue:
            guard let duration = value.floatValue(ActionEncodingKey.duration.rawValue) else {
                return nil
            }
            self = SPCommandAction.wait(duration: duration)
            
        case ActionEncodingKey.setDCMotor.rawValue:
            if let leftSpeed = value.intValue(ActionEncodingKey.leftSpeed.rawValue),
                let rightSpeed = value.intValue(ActionEncodingKey.rightSpeed.rawValue) {
                self = SPCommandAction.setDCMotor(leftSpeed: leftSpeed, rightSpeed: rightSpeed)
            } else {
                return nil
            }
        
        case ActionEncodingKey.setLEDLight.rawValue:
            if let r = value.intValue(ActionEncodingKey.r.rawValue),
                let g = value.intValue(ActionEncodingKey.g.rawValue),
                let b = value.intValue(ActionEncodingKey.b.rawValue) {
                self = SPCommandAction.setLEDLight(r: r, g: g, b: b)
            } else {
                return nil
            }
            
        case ActionEncodingKey.playMusic.rawValue:
            if let type = MusicType.init(dict[ActionEncodingKey.type.rawValue]!) {
                self = SPCommandAction.playMusic(type: type)
            } else {
                return nil
            }
            
        case ActionEncodingKey.setFacePanel.rawValue:
            if let x = value.intValue(ActionEncodingKey.x.rawValue),
                let y = value.intValue(ActionEncodingKey.y.rawValue),
                let isOn = value.boolValue(ActionEncodingKey.isOn.rawValue) {
                self = SPCommandAction.setFacePanel(x: x, y: y, isOn: isOn)
            } else {
                return nil
            }
            
        case ActionEncodingKey.setFacePanelType.rawValue:
            if let type = FacePanelType.init(dict[ActionEncodingKey.type.rawValue]!) {
                self = SPCommandAction.setFacePanelType(type: type)
            } else {
                return nil
            }
            
        case ActionEncodingKey.clearFacePanel.rawValue:
            self = SPCommandAction.clearFacePanel
            
        case ActionEncodingKey.playMusicNote.rawValue:
            if let note = SoundNote.init(dict[ActionEncodingKey.note.rawValue]!),
                let beat = SoundBeat.init(dict[ActionEncodingKey.beat.rawValue]!) {
                self = SPCommandAction.playMusicNote(note: note, beat: beat)
            } else {
                return nil
            }
        
        case ActionEncodingKey.readLightSensor.rawValue:
            self = SPCommandAction.readLightSensor
        
        case ActionEncodingKey.getButtonState.rawValue:
            self = SPCommandAction.getButtonState
        
        case ActionEncodingKey.readPotentiometer.rawValue:
            self = SPCommandAction.readPotentiometer
        
        case ActionEncodingKey.readSoundSensor.rawValue:
            self = SPCommandAction.readSoundSensor

        case ActionEncodingKey.getGryo.rawValue:
            self = SPCommandAction.getGyro
        
        case ActionEncodingKey.getShake.rawValue:
            self = SPCommandAction.getShake
        
        case ActionEncodingKey.readColorSensor.rawValue:
            self = SPCommandAction.readColorSensor
            
        case ActionEncodingKey.hasObstacle.rawValue:
            self = SPCommandAction.hasObstacle
        default:
            self = SPCommandAction.none
        }
    }

    public var value: PlaygroundValue {
        var dict: [String: PlaygroundValue] = [:]
        switch self {
        case .testText(let text):
            dict[ActionEncodingKey.typeKey.rawValue] = ActionEncodingKey.testText.rawValue.value
            dict[ActionEncodingKey.idKey.rawValue] = text.value
            
        case .execute:
            dict[ActionEncodingKey.typeKey.rawValue] = ActionEncodingKey.execute.rawValue.value
            
        case .wait(let duration):
            dict[ActionEncodingKey.typeKey.rawValue] = ActionEncodingKey.wait.rawValue.value
            dict[ActionEncodingKey.duration.rawValue] = duration.value
            
        case .setDCMotor(let leftSpeed, let rightSpeed):
            dict[ActionEncodingKey.typeKey.rawValue] = ActionEncodingKey.setDCMotor.rawValue.value
            dict[ActionEncodingKey.leftSpeed.rawValue] = leftSpeed.value
            dict[ActionEncodingKey.rightSpeed.rawValue] = rightSpeed.value
        
        case .setLEDLight(let r, let g, let b):
            dict[ActionEncodingKey.typeKey.rawValue] = ActionEncodingKey.setLEDLight.rawValue.value
            dict[ActionEncodingKey.r.rawValue] = r.value
            dict[ActionEncodingKey.g.rawValue] = g.value
            dict[ActionEncodingKey.b.rawValue] = b.value
        
        case .playMusic(let type):
            dict[ActionEncodingKey.typeKey.rawValue] = ActionEncodingKey.playMusic.rawValue.value
            dict[ActionEncodingKey.type.rawValue] = type.value
        
        case .setFacePanel(let x, let y, let isOn):
            dict[ActionEncodingKey.typeKey.rawValue] = ActionEncodingKey.setFacePanel.rawValue.value
            dict[ActionEncodingKey.x.rawValue] = x.value
            dict[ActionEncodingKey.y.rawValue] = y.value
            dict[ActionEncodingKey.isOn.rawValue] = isOn.value
            
        case .setFacePanelType(let type):
            dict[ActionEncodingKey.typeKey.rawValue] = ActionEncodingKey.setFacePanelType.rawValue.value
            dict[ActionEncodingKey.type.rawValue] = type.value
            
        case .clearFacePanel:
            dict[ActionEncodingKey.typeKey.rawValue] = ActionEncodingKey.clearFacePanel.rawValue.value
            
        case .playMusicNote(let note, let beat):
            dict[ActionEncodingKey.typeKey.rawValue] = ActionEncodingKey.playMusicNote.rawValue.value
            dict[ActionEncodingKey.note.rawValue] = note.value
            dict[ActionEncodingKey.beat.rawValue] = beat.value
        
        case .readLightSensor:
            dict[ActionEncodingKey.typeKey.rawValue] = ActionEncodingKey.readLightSensor.rawValue.value
            
        case .getButtonState:
            dict[ActionEncodingKey.typeKey.rawValue] = ActionEncodingKey.getButtonState.rawValue.value
        
        case .readPotentiometer:
            dict[ActionEncodingKey.typeKey.rawValue] = ActionEncodingKey.readPotentiometer.rawValue.value
            
        case .readSoundSensor:
            dict[ActionEncodingKey.typeKey.rawValue] = ActionEncodingKey.readSoundSensor.rawValue.value
            
        case .getGyro:
            dict[ActionEncodingKey.typeKey.rawValue] = ActionEncodingKey.getGryo.rawValue.value

        case .getShake:
            dict[ActionEncodingKey.typeKey.rawValue] = ActionEncodingKey.getShake.rawValue.value
        
        case .readColorSensor:
            dict[ActionEncodingKey.typeKey.rawValue] = ActionEncodingKey.readColorSensor.rawValue.value
            
        case .hasObstacle:
            dict[ActionEncodingKey.typeKey.rawValue] = ActionEncodingKey.hasObstacle.rawValue.value
            
        default: break
        }
        return .dictionary(dict)
    }
}

extension MusicType: SPMessageConstructible {
    public init?(_ value: PlaygroundValue) {
        guard let stringValue = value.stringValue(),
        let type = MusicType(rawValue: stringValue) else {
            return nil
        }
        self = type
    }
    
    public var value: PlaygroundValue {
        return rawValue.value
    }
}

extension FacePanelType: SPMessageConstructible {
    public init?(_ value: PlaygroundValue) {
        guard let stringValue = value.stringValue(),
            let type = FacePanelType(rawValue: stringValue) else {
                return nil
        }
        self = type
    }
    
    public var value: PlaygroundValue {
        return rawValue.value
    }
}

extension SoundNote: SPMessageConstructible {
    public init?(_ value: PlaygroundValue) {
        guard let intValue = value.intValue() else {
            return nil
        }
        self = SoundNote.init(intValue: intValue)
    }
    
    public var value: PlaygroundValue {
        return rawValue.value
    }
}

extension SoundBeat: SPMessageConstructible {
    public init?(_ value: PlaygroundValue) {
        guard let intValue = value.intValue() else {
            return nil
        }
        self = SoundBeat.init(intValue: intValue)
    }
    
    public var value: PlaygroundValue {
        return rawValue.value
    }
}
