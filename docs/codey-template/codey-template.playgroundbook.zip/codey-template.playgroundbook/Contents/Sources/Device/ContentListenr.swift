//
//  ContentListenr.swift
//  MBBlueToothCenter
//
//  Created by block Make on 2017/7/21.
//  Copyright © 2017-2018 Makeblock Co., Ltd. All rights reserved.
//

import Foundation
import PlaygroundSupport

public typealias FloatCallback = ((Float) -> Void)
public typealias BoolCallback = ((Bool) -> Void)
public typealias IntCallback = ((Int) -> Void)

public class ContentListenr: PlaygroundRemoteLiveViewProxyDelegate {
    public init() {}
    
    public var iPadTiltedForward: Bool = false
    public var iPadTiltedBackward: Bool = false
    public var iPadTiltedLeft: Bool = false
    public var iPadTiltedRight: Bool = false
    public var lightIntensity: Float = -99
    public var buttonAPressed: Bool = false
    public var buttonBPressed: Bool = false
    public var buttonCPressed: Bool = false
    public var potentiometer: Float = -99
    public var soundIntensity: Float = -99
    
    public var roll: Float = -99
    public var pitch: Float = -99
    public var yaw: Float = -99
    public var accX: Float = -99
    public var accY: Float = -99
    public var accZ: Float = -99
    
    public var shaked: Bool = false
    
    public var color: ColorType = .unknown
    
    public var hasObstacle: Bool = true
    
    public func remoteLiveViewProxy(_ remoteLiveViewProxy: PlaygroundRemoteLiveViewProxy, received message: PlaygroundValue) {
        guard let cmdValue = SPCallbackCommand.init(message) else {
            return
        }
        
        switch cmdValue {
        case .iPadTiltedForward(let value):
            self.iPadTiltedForward = value
        case .iPadTiltedBackward(let value):
            self.iPadTiltedBackward = value
        case .iPadTiltedLeft(let value):
            self.iPadTiltedLeft = value
        case .iPadTiltedRight(let value):
            self.iPadTiltedRight = value
        case .readLightSensor(let value):
            self.lightIntensity = value
        case .buttonAPressed(let value):
            self.buttonAPressed = value
        case .buttonBPressed(let value):
            self.buttonBPressed = value
        case .buttonCPressed(let value):
            self.buttonCPressed = value
        case .readPotentiometer(let value):
            self.potentiometer = value
        case .readSoundSensor(let value):
            self.soundIntensity = value
        case .roll(let value):
            self.roll = value
        case .pitch(let value):
            self.pitch = value
        case .yaw(let value):
            self.yaw = value
        case .accX(let value):
            self.accX = value
        case .accY(let value):
            self.accY = value
        case .accZ(let value):
            self.accZ = value
        case .shake(let value):
            self.shaked = value
        case .color(let value):
            if let color = ColorType.init(rawValue: value) {
                self.color = color
            }
        case .hasObstacle(let value):
            self.hasObstacle = value
        }
    }
    
    public func remoteLiveViewProxyConnectionClosed(_ remoteLiveViewProxy: PlaygroundRemoteLiveViewProxy) {
        PlaygroundPage.current.finishExecution()
    }
}
