import PlaygroundSupport

struct ActionEncodingKey {
    static let typeKey = "type"
    static let idKey = "id"

    static let sound = "sound"
    static let note = "note"
    static let beat = "beat"

    static let dcMotor = "dcMotor"
    static let power = "power"
    static let slot = "slot"

    static let getKnob = "getKnob"
    static let getLight = "getLight"
    static let getTemperature = "getTemperature"
    static let getDistance = "getDistance"
    static let getFunnyTouch = "getFunnyTouch"

    static let dcMotorMeanwhile = "dcMotorMeanwhile"
    static let power1 = "power1"
    static let power2 = "power2"

    static let ledBand = "ledBand"
    static let ledBandColors = "ledBandColors"
    static let colorE = "colorE"
    static let style = "style"
    static let ledPanel = "ledPanel"
    static let panelColor = "panelColor"
    static let expression = "expression"
    static let lightSensor = "lightSensor"
    static let lightIntensity = "lightIntensity"
    static let distanceSensor = "distanceSensor"
    static let distance = "distance"

    static let servo = "servo"
    static let port = "port"
    static let angle = "angle"

    static let led = "led"
    static let x = "x"
    static let y = "y"
    static let r = "r"
    static let g = "g"
    static let b = "b"

    static let execute = "execute"
    static let wait = "wait"
    static let testText = "testText"
    static let powerOn = "powerOn"
    static let powerOff = "powerOff"
    static let startHeartBeart = "startHeartBeart"
    static let duration = "duration"

    static let iPadmusic = "iPadmusic"
    static let thermometer = "thermometer"
    static let temperature = "temperature"
    static let hammer = "hammer"
    static let color = "color"
    static let colors = "colors"
    static let iPadSound = "iPadSound"
    static let stopiPadSound = "stopiPadSound"

    static let getBuzzerConnectState = "getBuzzerConnectState"
}

public enum SPCommandAction {
    case sound(note: SoundNote, beat: SoundBeat)
    case dcMotor(slot: DCMotorSlot, power: Int)
    case dcMotorMeanwhile(power1: Int, power2: Int)

    case servo(port: ServoPort, angle: Int)
    case led(x: Int, y: Int, r: Int, g: Int, b: Int)

    case lightSensor(lightIntensity: Float)
    case distanceSensor(distance: Int)

    case ledBand(color: LEDColor, style: LEDStyle)
    case ledBandColors(colors: [LEDColor], style: LEDStyle)
    case ledPanel(expression: Expression)
    case panelColor(r: Int, g: Int, b: Int)

    case getKnob
    case getLight
    case getTemperature
    case getDistance
    case getFunnyTouch

    case powerOn
    case powerOff
    case startHeartBeart

    case execute
    case wait(duration: Float)
    case testText(String)
    case none

    case iPadmusic(note: Int)
    case thermometer(temperature: Int)
    case hammer(color: Int)

    case iPadSound(note: PadSoundNote)
    case stopiPadSound

    case getBuzzerConnectState
}

extension SPCommandAction: SPMessageConstructible {
    public init?(_ value: PlaygroundValue) {
        guard case let .dictionary(dict) = value, let typeV = dict[ActionEncodingKey.typeKey], case let .string(type) = typeV else {
            return nil
        }
        
        switch type {
        case ActionEncodingKey.execute:
            self = SPCommandAction.execute
            
        case ActionEncodingKey.sound:
            if let note = SoundNote.init(dict[ActionEncodingKey.note]!), let beat = SoundBeat.init(dict[ActionEncodingKey.beat]!) {
                self = SPCommandAction.sound(note: note, beat: beat)
            } else {
                return nil
            }
            
        case ActionEncodingKey.dcMotor:
            if let slot = DCMotorSlot.init(dict[ActionEncodingKey.slot]!), let power = value.intValue(ActionEncodingKey.power) {
                self = SPCommandAction.dcMotor(slot: slot, power: power)
            } else {
                return nil
            }
            
        case ActionEncodingKey.dcMotorMeanwhile:
            if let power1 = value.intValue(ActionEncodingKey.power1), let power2 = value.intValue(ActionEncodingKey.power2) {
                self = SPCommandAction.dcMotorMeanwhile(power1: power1, power2: power2)
            } else {
                return nil
            }
            
        case ActionEncodingKey.ledPanel:
            if let expression = Expression.init(dict[ActionEncodingKey.expression]!) {
                self = SPCommandAction.ledPanel(expression: expression)
            } else {
                return nil
            }
            
        case ActionEncodingKey.panelColor:
            if let r = value.intValue(ActionEncodingKey.r), let g = value.intValue(ActionEncodingKey.g), let b = value.intValue(ActionEncodingKey.b) {
                self = SPCommandAction.panelColor(r: r, g: g, b: b)
            } else {
                return nil
            }
            
        case ActionEncodingKey.ledBand:
            if let color = LEDColor.init(dict[ActionEncodingKey.colorE]!),
                let style = LEDStyle.init(dict[ActionEncodingKey.style]!) {
                self = SPCommandAction.ledBand(color: color, style: style)
            } else {
                return nil
            }
            
        case ActionEncodingKey.ledBandColors:
            if let colorValues = dict[ActionEncodingKey.colors]?.arrayValue(),
                let style = LEDStyle.init(dict[ActionEncodingKey.style]!) {
                let colors = colorValues.map { return LEDColor.init($0)! }
                self = SPCommandAction.ledBandColors(colors: colors, style: style)
            } else {
                return nil
            }
        case ActionEncodingKey.lightSensor:
            guard let lightIntensity = value.floatValue(ActionEncodingKey.lightIntensity) else {
                return nil
            }
            self = SPCommandAction.lightSensor(lightIntensity: lightIntensity)

        case ActionEncodingKey.distanceSensor:
            guard let distance = value.intValue(ActionEncodingKey.distance) else {
                return nil
            }
            self = SPCommandAction.distanceSensor(distance: distance)

        case ActionEncodingKey.servo:
            if let port = ServoPort.init(dict[ActionEncodingKey.port]!), let angle = value.intValue(ActionEncodingKey.angle) {
                self = SPCommandAction.servo(port: port, angle: angle)
            } else {
                return nil
            }
            
        case ActionEncodingKey.led:
            if let x = value.intValue(ActionEncodingKey.x),
                let y = value.intValue(ActionEncodingKey.y),
                let r = value.intValue(ActionEncodingKey.r),
                let g = value.intValue(ActionEncodingKey.g),
                let b = value.intValue(ActionEncodingKey.b) {
                self = SPCommandAction.led(x: x, y: y, r: r, g: g, b: b)
            } else {
                return nil
            }
            
        case ActionEncodingKey.getKnob:
            self = SPCommandAction.getKnob
            
        case ActionEncodingKey.getLight:
            self = SPCommandAction.getLight
            
        case ActionEncodingKey.getTemperature:
            self = SPCommandAction.getTemperature
            
        case ActionEncodingKey.getDistance:
            self = SPCommandAction.getDistance
            
        case ActionEncodingKey.getFunnyTouch:
            self = SPCommandAction.getFunnyTouch
            
        case ActionEncodingKey.powerOn:
            self = SPCommandAction.powerOn
            
        case ActionEncodingKey.powerOff:
            self = SPCommandAction.powerOff
            
        case ActionEncodingKey.wait:
            guard let duration = value.floatValue(ActionEncodingKey.duration) else {
                return nil
            }
            self = SPCommandAction.wait(duration: duration)
            
        case ActionEncodingKey.testText:
            if let text = value.stringValue(ActionEncodingKey.idKey) {
                self = SPCommandAction.testText(text)
            } else {
                return nil
            }
            
        case ActionEncodingKey.iPadmusic:
            if let note = value.intValue(ActionEncodingKey.note) {
                self = SPCommandAction.iPadmusic(note: note)
            } else {
                return nil
            }
            
        case ActionEncodingKey.thermometer:
            if let temperature = value.intValue(ActionEncodingKey.temperature) {
                self = SPCommandAction.thermometer(temperature: temperature)
            } else {
                return nil
            }
            
        case ActionEncodingKey.hammer:
            if let color = value.intValue(ActionEncodingKey.color) {
                self = SPCommandAction.hammer(color: color)
            } else {
                return nil
            }
            
        case ActionEncodingKey.iPadSound:
            if let note = PadSoundNote.init(dict[ActionEncodingKey.note]!) {
                self = SPCommandAction.iPadSound(note: note)
            } else {
                return nil
            }
            
        case ActionEncodingKey.stopiPadSound:
            self = SPCommandAction.stopiPadSound
            
        case ActionEncodingKey.getBuzzerConnectState:
            self = SPCommandAction.getBuzzerConnectState
            
        default:
            self = SPCommandAction.none
        }
    }

    public var value: PlaygroundValue {
        var dict: [String: PlaygroundValue] = [:]
        switch self {
        case .sound(let note, let beat):
            dict[ActionEncodingKey.typeKey] = ActionEncodingKey.sound.value
            dict[ActionEncodingKey.note] = note.value
            dict[ActionEncodingKey.beat] = beat.value
        case .dcMotor(let slot, let power):
            dict[ActionEncodingKey.typeKey] = ActionEncodingKey.dcMotor.value
            dict[ActionEncodingKey.slot] = slot.value
            dict[ActionEncodingKey.power] = power.value
        case .dcMotorMeanwhile(let power1, let power2):
            dict[ActionEncodingKey.typeKey] = ActionEncodingKey.dcMotorMeanwhile.value
            dict[ActionEncodingKey.power1] = power1.value
            dict[ActionEncodingKey.power2] = power2.value
        case .servo(let port, let angle):
            dict[ActionEncodingKey.typeKey] = ActionEncodingKey.servo.value
            dict[ActionEncodingKey.port] = port.value
            dict[ActionEncodingKey.angle] = angle.value
        case .led(let x, let y, let r, let g, let b):
            dict[ActionEncodingKey.typeKey] = ActionEncodingKey.led.value
            dict[ActionEncodingKey.x] = x.value
            dict[ActionEncodingKey.y] = y.value
            dict[ActionEncodingKey.r] = r.value
            dict[ActionEncodingKey.g] = g.value
            dict[ActionEncodingKey.b] = b.value
        case .ledBand(let color, let style):
            dict[ActionEncodingKey.typeKey] = ActionEncodingKey.ledBand.value
            dict[ActionEncodingKey.colorE] = color.value
            dict[ActionEncodingKey.style] = style.value
        case .ledBandColors(let colors, let style):
            dict[ActionEncodingKey.typeKey] = ActionEncodingKey.ledBandColors.value
            dict[ActionEncodingKey.colors] = PlaygroundValue.array(colors.map{return $0.value})
            dict[ActionEncodingKey.style] = style.value
        case .ledPanel(let expression):
            dict[ActionEncodingKey.typeKey] = ActionEncodingKey.ledPanel.value
            dict[ActionEncodingKey.expression] = expression.value
        case .panelColor(let r, let g, let b):
            dict[ActionEncodingKey.typeKey] = ActionEncodingKey.panelColor.value
            dict[ActionEncodingKey.r] = r.value
            dict[ActionEncodingKey.g] = g.value
            dict[ActionEncodingKey.b] = b.value
        case .execute:
            dict[ActionEncodingKey.typeKey] = ActionEncodingKey.execute.value
        case .getKnob:
            dict[ActionEncodingKey.typeKey] = ActionEncodingKey.getKnob.value
        case .getLight:
            dict[ActionEncodingKey.typeKey] = ActionEncodingKey.getLight.value
        case .getTemperature:
            dict[ActionEncodingKey.typeKey] = ActionEncodingKey.getTemperature.value
        case .getDistance:
            dict[ActionEncodingKey.typeKey] = ActionEncodingKey.getDistance.value
        case .getFunnyTouch:
            dict[ActionEncodingKey.typeKey] = ActionEncodingKey.getFunnyTouch.value
        case .powerOn:
            dict[ActionEncodingKey.typeKey] = ActionEncodingKey.powerOn.value
        case .powerOff:
            dict[ActionEncodingKey.typeKey] = ActionEncodingKey.powerOff.value
        case .wait(let duration):
            dict[ActionEncodingKey.typeKey] = ActionEncodingKey.wait.value
            dict[ActionEncodingKey.duration] = duration.value
        case .lightSensor(let lightIntensity):
            dict[ActionEncodingKey.typeKey] = ActionEncodingKey.lightSensor.value
            dict[ActionEncodingKey.lightIntensity] = lightIntensity.value
        case .distanceSensor(let distance):
            dict[ActionEncodingKey.typeKey] = ActionEncodingKey.distanceSensor.value
            dict[ActionEncodingKey.distance] = distance.value
        case .testText(let text):
            dict[ActionEncodingKey.typeKey] = ActionEncodingKey.testText.value
            dict[ActionEncodingKey.idKey] = text.value
        case .iPadmusic(let note):
            dict[ActionEncodingKey.typeKey] = ActionEncodingKey.iPadmusic.value
            dict[ActionEncodingKey.note] = note.value
        case .thermometer(let temperature):
            dict[ActionEncodingKey.typeKey] = ActionEncodingKey.thermometer.value
            dict[ActionEncodingKey.temperature] = temperature.value
        case .hammer(let color):
            dict[ActionEncodingKey.typeKey] = ActionEncodingKey.hammer.value
            dict[ActionEncodingKey.color] = color.value
        case .iPadSound(let note):
            dict[ActionEncodingKey.typeKey] = ActionEncodingKey.iPadSound.value
            dict[ActionEncodingKey.note] = note.value
        case .stopiPadSound:
            dict[ActionEncodingKey.typeKey] = ActionEncodingKey.stopiPadSound.value
        case .getBuzzerConnectState:
            dict[ActionEncodingKey.typeKey] = ActionEncodingKey.getBuzzerConnectState.value
        default: break
        }
        return .dictionary(dict)
    }
}

extension DCMotorSlot: SPMessageConstructible {
    public init?(_ value: PlaygroundValue) {
        guard let intValue = value.intValue() else {
            return nil
        }
        let uIntValue = UInt8(intValue)
        switch uIntValue {
        case 0x02:
            self = DCMotorSlot.slot1
        case 0x03:
            self = DCMotorSlot.slot2
        default:
            self = DCMotorSlot.slot1
        }
    }

    public var value: PlaygroundValue {
        return Int(rawValue).value
    }
}

extension ServoPort: SPMessageConstructible {
    public init?(_ value: PlaygroundValue) {
        guard let intValue = value.intValue() else {
            return nil
        }
        let uIntValue = UInt8(intValue)
        switch uIntValue {
        case 0x01:
            self = ServoPort.port1
        case 0x02:
            self = ServoPort.port2
        default:
            self = ServoPort.port1
        }
    }

    public var value: PlaygroundValue {
        return Int(rawValue).value
    }
}

extension SoundNote: SPMessageConstructible {
    public init?(_ value: PlaygroundValue) {
        guard let intValue = value.intValue() else {
            return nil
        }
        self = SoundNote.init(intValue: intValue)
    }

    public var value: PlaygroundValue {
        return rawValue.value
    }
}

extension SoundBeat: SPMessageConstructible {
    public init?(_ value: PlaygroundValue) {
        guard let intValue = value.intValue() else {
            return nil
        }
        self = SoundBeat.init(intValue: intValue)
    }

    public var value: PlaygroundValue {
        return rawValue.value
    }
}

extension LEDColor: SPMessageConstructible {
    public init?(_ value: PlaygroundValue) {
        guard let intValue = value.intValue() else {
            return nil
        }
        self = LEDColor.init(intValue: intValue)
    }

    public var value: PlaygroundValue {
        return rawValue.value
    }
}

extension LEDStyle: SPMessageConstructible {
    public init?(_ value: PlaygroundValue) {
        guard let intValue = value.intValue() else {
            return nil
        }
        let uIntValue = UInt8(intValue)
        switch uIntValue {
        case 0x00:
            self = LEDStyle.light
        case 0x01:
            self = LEDStyle.marquee
        case 0x04:
            self = LEDStyle.breathing
        default:
            self = LEDStyle.light
        }
    }

    public var value: PlaygroundValue {
        return Int(rawValue).value
    }
}

public enum PadSoundNote: Int {
    case unknown = -1
    case c4
    case d4
    case e4
    case f4
    case g4
    case a4
    case b4
    case c5

    public var fileName: String {
        switch self {
        case .c4:
            return "note/c4"
        case .d4:
            return "note/d4"
        case .e4:
            return "note/e4"
        case .f4:
            return "note/f4"
        case .g4:
            return "note/g4"
        case .a4:
            return "note/a4"
        case .b4:
            return "note/b4"
        case .c5:
            return "note/c5"
        case .unknown:
            return "-1"
        }
    }
}

extension PadSoundNote: SPMessageConstructible {
    public init?(_ value: PlaygroundValue) {
        guard let intValue = value.intValue() else {
            return nil
        }
        self = PadSoundNote.init(rawValue: intValue)!
    }

    public var value: PlaygroundValue {
        return rawValue.value
    }
}

public enum Expression: Int {
    case angry = 0
    case smile
    case smiley
    case happy
    case shock
    case sun
    case moon
    case fire
    case blank
    case forward
    case backward
    case left
    case right

    public var imgName: String {
        switch self {
        case .angry:
            return "expression_angry"
        case .smile, .smiley:
            return "expression_smile"
        case .happy:
            return "expression_happy"
        case .shock:
            return "expression_shock"
        case .sun:
            return "expression_sun"
        case .moon:
            return "expression_moon"
        case .fire:
            return "expression_fire"
        case .blank:
            return "expression_blank"
        case .forward:
            return "expression_forward"
        case .backward:
            return "expression_backward"
        case .left:
            return "expression_left"
        case .right:
            return "expression_right"
        }
    }

    public var explorerImgName: String {
        switch self {
        case .angry:
            return "explorer/explorer_angry"
        case .smile, .smiley:
            return "explorer/explorer_smile"
        case .happy:
            return "explorer/explorer_happy"
        case .shock:
            return "explorer/explorer_shock"
        case .sun:
            return "explorer/explorer_sun"
        case .moon:
            return "explorer/explorer_moon"
        case .fire:
            return "explorer/explorer_fire"
        case .blank:
            return "explorer/explorer_blank"
        case .forward:
            return "explorer/explorer_forward"
        case .backward:
            return "explorer/explorer_backward"
        case .left:
            return "explorer/explorer_left"
        case .right:
            return "explorer/explorer_right"
        }
    }
}

extension Expression: SPMessageConstructible {
    public init?(_ value: PlaygroundValue) {
        guard let intValue = value.intValue() else {
            return nil
        }
        self = Expression.init(rawValue: intValue)!
    }

    public var value: PlaygroundValue {
        return rawValue.value
    }
}

extension Expression {
    public var colors: [[Int]] {
        switch self {
        case .angry:
            return [[0, 0, 0, 1, 1, 1, 0, 0],
                    [0, 0, 0, 1, 1, 0, 0, 0],
                    [0, 1, 0, 0, 0, 0, 0, 0],
                    [0, 0, 1, 0, 0, 0, 0, 0],
                    [0, 0, 1, 0, 0, 0, 0, 0],
                    [0, 1, 0, 0, 0, 0, 0, 0],
                    [0, 0, 0, 1, 1, 0, 0, 0],
                    [0, 0, 0, 1, 1, 1, 0, 0]]
        case .smile:
            return [[0, 0, 0, 0, 5, 0, 0, 0],
                    [0, 0, 0, 0, 0, 5, 0, 0],
                    [0, 0, 5, 0, 5, 0, 0, 0],
                    [0, 5, 0, 0, 0, 0, 0, 0],
                    [0, 5, 0, 0, 0, 0, 0, 0],
                    [0, 0, 5, 0, 5, 0, 0, 0],
                    [0, 0, 0, 0, 0, 5, 0, 0],
                    [0, 0, 0, 0, 5, 0, 0, 0]]
        case .smiley:
            return [[0, 0, 0, 0, 0, 0, 0, 0],
                    [0, 0, 0, 0, 0, 0, 0, 0],
                    [0, 5, 0, 0, 0, 0, 5, 0],
                    [5, 0, 5, 0, 0, 5, 0, 5],
                    [0, 0, 0, 0, 0, 0, 0, 0],
                    [0, 0, 5, 0, 0, 5, 0, 0],
                    [0, 0, 0, 5, 5, 0, 0, 0],
                    [0, 0, 0, 0, 0, 0, 0, 0]]
        case .happy:
            return [[0, 0, 0, 0, 0, 5, 0, 0],
                    [0, 0, 0, 0, 0, 0, 5, 0],
                    [0, 0, 5, 5, 0, 5, 0, 0],
                    [0, 5, 5, 5, 0, 0, 0, 0],
                    [0, 5, 5, 5, 0, 0, 0, 0],
                    [0, 0, 5, 5, 0, 5, 0, 0],
                    [0, 0, 0, 0, 0, 0, 5, 0],
                    [0, 0, 0, 0, 0, 5, 0, 0]]
        case .shock:
            return [[0, 0, 0, 0, 0, 0, 0, 0],
                    [0, 0, 0, 0, 0, 0, 5, 0],
                    [5, 5, 5, 5, 5, 0, 0, 0],
                    [5, 0, 0, 0, 0, 5, 0, 0],
                    [5, 0, 0, 0, 0, 5, 0, 0],
                    [5, 5, 5, 5, 5, 0, 0, 0],
                    [0, 0, 0, 0, 0, 0, 5, 0],
                    [0, 0, 0, 0, 0, 0, 0, 0]]
        case .sun:
            return [[0, 0, 3, 3, 3, 3, 0, 0],
                    [0, 3, 3, 3, 3, 3, 3, 0],
                    [3, 3, 3, 3, 3, 3, 3, 3],
                    [3, 3, 3, 3, 3, 3, 3, 3],
                    [3, 3, 3, 3, 3, 3, 3, 3],
                    [3, 3, 3, 3, 3, 3, 3, 3],
                    [0, 3, 3, 3, 3, 3, 3, 0],
                    [0, 0, 3, 3, 3, 3, 0, 0]]
        case .moon:
            return [[0, 0, 3, 3, 3, 3, 0, 0],
                    [0, 0, 0, 3, 3, 3, 3, 0],
                    [0, 0, 0, 0, 3, 3, 3, 3],
                    [0, 0, 0, 0, 3, 3, 3, 3],
                    [0, 0, 0, 0, 3, 3, 3, 3],
                    [0, 0, 0, 3, 3, 3, 3, 3],
                    [0, 3, 3, 3, 3, 3, 3, 0],
                    [0, 0, 3, 3, 3, 3, 0, 0]]
        case .fire:
            return [[0, 0, 0, 0, 0, 1, 0, 0],
                    [0, 0, 0, 0, 1, 0, 0, 0],
                    [0, 0, 0, 1, 1, 0, 0, 0],
                    [0, 0, 1, 1, 1, 0, 1, 0],
                    [0, 0, 1, 1, 1, 1, 0, 0],
                    [0, 1, 1, 1, 1, 1, 0, 0],
                    [0, 1, 1, 1, 1, 1, 0, 0],
                    [0, 0, 1, 1, 1, 0, 0, 0]]
        case .blank:
            return [[0, 0, 0, 0, 0, 0, 0, 0],
                    [0, 0, 0, 0, 0, 0, 0, 0],
                    [0, 0, 0, 0, 0, 0, 0, 0],
                    [0, 0, 0, 0, 0, 0, 0, 0],
                    [0, 0, 0, 0, 0, 0, 0, 0],
                    [0, 0, 0, 0, 0, 0, 0, 0],
                    [0, 0, 0, 0, 0, 0, 0, 0],
                    [0, 0, 0, 0, 0, 0, 0, 0]]
        case .forward:
            return [[0, 0, 0, 0, 0, 0, 0, 0],
                    [0, 0, 0, 5, 5, 0, 0, 0],
                    [0, 0, 5, 5, 5, 5, 0, 0],
                    [0, 5, 5, 5, 5, 5, 5, 0],
                    [0, 5, 5, 5, 5, 5, 5, 0],
                    [0, 0, 0, 5, 5, 0, 0, 0],
                    [0, 0, 0, 5, 5, 0, 0, 0],
                    [0, 0, 0, 0, 0, 0, 0, 0]]
        case .backward:
            return [[0, 0, 0, 0, 0, 0, 0, 0],
                    [0, 0, 0, 5, 5, 0, 0, 0],
                    [0, 0, 0, 5, 5, 0, 0, 0],
                    [0, 5, 5, 5, 5, 5, 5, 0],
                    [0, 5, 5, 5, 5, 5, 5, 0],
                    [0, 0, 5, 5, 5, 5, 0, 0],
                    [0, 0, 0, 5, 5, 0, 0, 0],
                    [0, 0, 0, 0, 0, 0, 0, 0]]
        case .left:
            return [[0, 0, 0, 0, 0, 0, 0, 0],
                    [0, 0, 0, 5, 5, 0, 0, 0],
                    [0, 0, 5, 5, 5, 0, 0, 0],
                    [0, 5, 5, 5, 5, 5, 5, 0],
                    [0, 5, 5, 5, 5, 5, 5, 0],
                    [0, 0, 5, 5, 5, 0, 0, 0],
                    [0, 0, 0, 5, 5, 0, 0, 0],
                    [0, 0, 0, 0, 0, 0, 0, 0]]
        case .right:
            return [[0, 0, 0, 0, 0, 0, 0, 0],
                    [0, 0, 0, 5, 5, 0, 0, 0],
                    [0, 0, 0, 5, 5, 5, 0, 0],
                    [0, 5, 5, 5, 5, 5, 5, 0],
                    [0, 5, 5, 5, 5, 5, 5, 0],
                    [0, 0, 0, 5, 5, 5, 0, 0],
                    [0, 0, 0, 5, 5, 0, 0, 0],
                    [0, 0, 0, 0, 0, 0, 0, 0]]

        }
    }
}
