//
//  Loader.swift
//  MBBlueToothCenter
//
//  Created by block Make on 2017/7/21.
//  Copyright © 2017年 Shenzhen Maker Works Technology Co., Ltd. All rights reserved.
//

import PlaygroundSupport

public struct Loader {
    public static var currentProxy: PlaygroundRemoteLiveViewProxy? {
        return PlaygroundPage.current.liveView as? PlaygroundRemoteLiveViewProxy
    }

    public static let sharedTaskMgr: TaskManager<MessageCommand> = TaskManager<MessageCommand>()

    public static let currentBot = Neuron(sender: SPBLECenter.shared)

    public static var currentKnowNeuronViewController: KnowNeuronViewController? {
        if let vc = PlaygroundPage.current.liveView as? KnowNeuronViewController {
            return vc
        }
        return nil
    }

    public static var currentKnobViewController: KnobViewController? {
        if let vc = PlaygroundPage.current.liveView as? KnobViewController {
            return vc
        }
        return nil
    }

    public static var currentTemperatureViewController: TemperatureViewController? {
        if let vc = PlaygroundPage.current.liveView as? TemperatureViewController {
            return vc
        }
        return nil
    }

    public static var currentFunnyTouchViewController: FunnyTouchViewController? {
        if let vc = PlaygroundPage.current.liveView as? FunnyTouchViewController {
            return vc
        }
        return nil
    }

    public static var currentDCMotorViewController: DCMotorViewController? {
        if let vc = PlaygroundPage.current.liveView as? DCMotorViewController {
            return vc
        }
        return nil
    }

    public static var currentExplorerViewController: ExplorerViewController? {
        if let vc = PlaygroundPage.current.liveView as? ExplorerViewController {
            return vc
        }
        return nil
    }

    public static var currentSwordViewController: SwordViewController? {
        if let vc = PlaygroundPage.current.liveView as? SwordViewController {
            return vc
        }
        return nil
    }
    
    public static var currentPianoViewController: PianoViewController? {
        if let vc = PlaygroundPage.current.liveView as? PianoViewController {
            return vc
        }
        return nil
    }

    public static var currentLiveViewController: LiveViewController? {
        if let vc = PlaygroundPage.current.liveView as? LiveViewController {
            return vc
        }
        return nil
    }
}
