//
//  KnobViewController.swift
//  Neuron
//
//  Created by CatchZeng on 2017/4/18.
//  Copyright © 2017年 Shenzhen Maker Works Technology Co., Ltd. All rights reserved.
//

import UIKit

public class TemperatureViewController: LiveViewController {

    public let stageView = TemperatureStageView(frame: .zero)

    override public func viewDidLoad() {
        super.viewDidLoad()

        view.addSubview(stageView)
        stageView.snp.makeConstraints { (make) in
            make.edges.equalTo(self.view)
        }
    }

    override public func viewDidLayoutSubviews() {
        super.viewDidLayoutSubviews()
        stageView.updateLayout(frame: view.frame)
    }

    public override func didConnect() {
        stageView.moveCurtain(position: .out)
    }
    
    public override func didDisconnect() {
        stageView.moveCurtain(position: .down)
    }

    public func thermometer(temperature: Int) {
        stageView.update(temperature)
    }
}
