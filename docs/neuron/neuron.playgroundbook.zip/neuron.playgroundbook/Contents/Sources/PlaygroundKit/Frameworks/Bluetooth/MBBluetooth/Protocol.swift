//
//  DeviceKit.swift
//  Neuron
//
//  Created by CatchZeng on 2017/4/18.
//  Copyright © 2017-2018 Makeblock Co., Ltd. All rights reserved.
//

import Foundation
import CoreBluetooth

public enum Result<T> {
    case success(T)
    case failure(error: Error)
}

public protocol CommandOrigin {}
public protocol CommandTarget {}

extension Data: CommandOrigin {}
extension String: CommandOrigin {}
extension Data: CommandTarget {}
extension String: CommandTarget {}

public protocol CommandInterpreter {
    func command(origin: CommandOrigin) -> CommandTarget
}

struct DefaultInterpreter: CommandInterpreter {
    func command(origin: CommandOrigin) -> CommandTarget {
        if let origin = origin as? Data {
            return origin
        }
        if let origin = origin as? String {
            return origin.data(using: .utf8) ?? Data()
        }
        return Data()
    }
}

public protocol Request {
    associatedtype Response: Decodable
    var interpreter: CommandInterpreter {get}
    var command: CommandOrigin {get}
    var method: Method {get}
}

public enum Method {
    case write
    case transition
    case reset
}

extension Method {
    public var writeType: CBCharacteristicWriteType {
        switch self {
        case .write:
            return .withoutResponse
        case .transition:
            return .withResponse
        case .reset:
            return .withoutResponse
        }
    }
}

extension Data: Decodable {
    public static func decode(data: Data) -> Data {
        return data
    }
}

extension Data: Request {
    public typealias Response = Data
    public var interpreter: CommandInterpreter {
        return DefaultInterpreter()
    }
    public var command: CommandOrigin {
        return self
    }
    public var method: Method {
        return .write
    }
}

public protocol Decodable {
    static func decode(data: Data) -> Self
}
