//
//  ActionTool
//  Neuron
//
//  Created by CatchZeng on 2017/4/18.
//  Copyright © 2017年 Shenzhen Maker Works Technology Co., Ltd. All rights reserved.
//

import UIKit

public struct ActionTool {
    public static let DefaultDuration: Float = 0.01

    static public func testText(_ text: String) {
        let command = MessageCommand.init(action: .testText(text), duration: 0.5, platform: .all)
        let task = SPTask<MessageCommand>.init(commands: [command], duration: 0.5)
        Loader.sharedTaskMgr.addTasks([task])
    }

    static public func wait(_ duration: Float) {
        sendAction(.execute, duration: duration)
    }

    static public func sendAction(_ action: SPCommandAction, duration: Float = 0) {
        let command = MessageCommand.init(action: action, duration: duration, platform: .all)
        let task = SPTask<MessageCommand>.init(commands: [command], duration: duration)
        Loader.sharedTaskMgr.addTasks([task])
    }
}
