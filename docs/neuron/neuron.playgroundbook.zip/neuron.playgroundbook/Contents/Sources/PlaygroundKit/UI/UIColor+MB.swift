//
//  UIColor+MB.swift
//  Neuron
//
//  Created by CatchZeng on 2018/5/11.
//

import Foundation
import UIKit

extension UIColor {
    public func rgba() -> (r: Int, g: Int, b: Int, a: Int)? {
        var fRed: CGFloat = 0
        var fGreen: CGFloat = 0
        var fBlue: CGFloat = 0
        var fAlpha: CGFloat = 0
        if self.getRed(&fRed, green: &fGreen, blue: &fBlue, alpha: &fAlpha) {
            let iRed = Int(fRed * 255.0)
            let iGreen = Int(fGreen * 255.0)
            let iBlue = Int(fBlue * 255.0)
            let iAlpha = Int(fAlpha * 255.0)
            return (iRed, iGreen, iBlue, iAlpha)
        } else {
            return nil
        }
    }
}
