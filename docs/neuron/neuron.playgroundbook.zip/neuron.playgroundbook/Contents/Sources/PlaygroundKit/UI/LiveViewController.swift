//
//  LiveViewController.swift
//  Neuron
//
//  Created by CatchZeng on 2017/4/18.
//  Copyright © 2017-2018 Makeblock Co., Ltd. All rights reserved.
//

import UIKit
import PlaygroundSupport
import PlaygroundBluetooth
import AVFoundation

struct ControlLayout {
    static let verticalOffset: CGFloat = 18
    static let height: CGFloat = 44
    static let width: CGFloat = 44
    static let edgeOffset: CGFloat = 20
}

public class LiveViewController: UIViewController, PlaygroundLiveViewSafeAreaContainer {
    public static func `default`() -> LiveViewController {
        return LiveViewController.init(nibName: nil, bundle: nil)
    }

    public var chapter: Int = 0
    public var page: Int = 0

    public let neuronListener = NeuronListener()

    public lazy var proxy: TaskDispatcher = {
        return TaskDispatcher()
    }()

    fileprivate var logView: UIButton!
    fileprivate var logTmp = ""

    let audioContainer = OverlayView()
    fileprivate var audioButton: UIButton?
    private var player: AVAudioPlayer?
    fileprivate var backgroundAudioEnabled: Bool = Persisted.isBackgroundAudioEnabled
    fileprivate var backgroundAudioVisiable: Bool = true

    fileprivate var spConnector: SPConnector?
    fileprivate var connectionView: PlaygroundBluetoothConnectionView?
    public override init(nibName nibNameOrNil: String?, bundle nibBundleOrNil: Bundle?) {
        super.init(nibName: nibNameOrNil, bundle: nibBundleOrNil)
    }
    
    fileprivate var lastNote: PadSoundNote = .unknown

    required public init(coder aDecoder: NSCoder) {
        fatalError("This method has not been implemented.")
    }

    // MARK: LifeCycle

    override public func viewDidLoad() {
        super.viewDidLoad()
        registerForTapGesture()
        Loader.currentBot.interpreterDelegate = neuronListener
        Loader.currentBot.blockContainerDelegate = neuronListener
        SPBLECenter.shared.addListener(listener: self)
        PlaygroundPage.current.needsIndefiniteExecution = true
    }

    override public func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)
        loadConnectionView()
        loadAudioButton()
        SPBLECenter.shared.connectToLastConnectedPeripheral()
    }

    public func setBackgroundAudio(visible: Bool) {
        backgroundAudioVisiable = visible
    }

    func loadAudioButton() {
        if !backgroundAudioVisiable {
            return
        }

        if audioButton == nil {
            view.addSubview(audioContainer)
            audioContainer.translatesAutoresizingMaskIntoConstraints = false
            NSLayoutConstraint.activate([
                audioContainer.topAnchor.constraint(equalTo: liveViewSafeAreaGuide.topAnchor, constant: ControlLayout.verticalOffset),
                audioContainer.trailingAnchor.constraint(equalTo: view.trailingAnchor, constant: -ControlLayout.edgeOffset),
                audioContainer.heightAnchor.constraint(equalToConstant: ControlLayout.height),
                audioContainer.widthAnchor.constraint(equalToConstant: ControlLayout.width)
                ])

            audioButton = UIButton()
            guard let audioButton = audioButton else { return }
            updateAudioButtonImage(on: backgroundAudioEnabled)
            audioButton.imageView?.contentMode = .scaleAspectFit
            audioButton.translatesAutoresizingMaskIntoConstraints = true
            audioButton.autoresizingMask = [.flexibleWidth, .flexibleHeight]
            audioButton.addTarget(self, action: #selector(toggleBackgroundAudio(_:)), for: .touchUpInside)
            audioContainer.addSubview(audioButton)

            if backgroundAudioEnabled {
                playBgMusic()
            }
        }
    }

    func loadConnectionView() {
        if connectionView == nil {
            spConnector = SPConnector()

            connectionView = PlaygroundBluetoothConnectionView(centralManager: SPBLECenter.shared.centralManager, delegate: spConnector, dataSource: spConnector)
            view.addSubview(connectionView!)

            let trailingConstant = backgroundAudioVisiable ? -(2*ControlLayout.edgeOffset+ControlLayout.width) : -ControlLayout.edgeOffset
            NSLayoutConstraint.activate([
                connectionView!.topAnchor.constraint(equalTo: liveViewSafeAreaGuide.topAnchor, constant: ControlLayout.verticalOffset),
                connectionView!.trailingAnchor.constraint(equalTo: liveViewSafeAreaGuide.trailingAnchor, constant: trailingConstant)
                ])
        }
    }

    fileprivate func startNeuron() {
        Loader.currentBot.startHeartbeat()
    }

    public func log(_ title: String = "title") {
        logTmp += title
        var button: UIButton!
        if logView == nil {
            button = UIButton.init(type: .custom)
            button.titleLabel?.numberOfLines = 0
            button.titleLabel?.lineBreakMode = .byWordWrapping
            view.addSubview(button)
            button.backgroundColor = UIColor.init(white: 0, alpha: 0.8)
            button.layer.cornerRadius = 25
            button.frame = CGRect.init(x: 0, y: 450, width: 400, height: 100)
            button.titleLabel?.font = UIFont.systemFont(ofSize: 13)
            logView = button
        } else {
            button = logView
        }
        button.addTarget(self, action: #selector(testTap), for: .touchUpInside)
        logView.setTitle(logTmp, for: .normal)
    }

    @objc func testTap() {
        logTmp = ""
        logView.setTitle(logTmp, for: .normal)
    }

    @objc func toggleBackgroundAudio(_ button: UIButton) {
        if let vc = presentedViewController as? AudioMenuController {
            vc.dismiss(animated: true, completion: nil)
            return
        }

        let menu = AudioMenuController()
        menu.modalPresentationStyle = .popover
        menu.popoverPresentationController?.passthroughViews = [view]
        menu.popoverPresentationController?.permittedArrowDirections = .up
        menu.popoverPresentationController?.sourceView = button
        menu.popoverPresentationController?.sourceRect = CGRect(x: 0, y: 5, width: 44, height: 44)
        menu.popoverPresentationController?.delegate = self
        menu.delegate = self
        menu.backgroundAudioEnabled = backgroundAudioEnabled
        present(menu, animated: true, completion: nil)
    }

    public func playMusic(url: URL, numberOfLoops: Int = -1, volume: Float = 0.5) {
        do {
            try player = AVAudioPlayer.init(contentsOf: url)
            player?.prepareToPlay()
            player?.numberOfLoops = numberOfLoops
            player?.volume = volume
            player?.play()
        } catch let error {
            print("error: \(error)")
        }
    }

    public func stopMusic() {
        player?.stop()
    }

    public func playBgMusic() {
        let path = Bundle.main.path(forResource: "bgMusic", ofType: "wav")
        let url = URL(fileURLWithPath: path!)
        playMusic(url: url)
    }
    
    public func iPadSound(note: PadSoundNote) {
        if note == lastNote, let player = player, player.isPlaying {
            return
        }
        
        stopMusic()
        lastNote = note
        let path = Bundle.main.path(forResource: note.fileName, ofType: "wav")
        let url = URL(fileURLWithPath: path!)
        playMusic(url: url, numberOfLoops: 0, volume: 1.0)
    }

    // MARK: Override

    public func didConnect() {
    }
    public func didDisconnect() {
    }
    public func didPrepared() {
    }
    public func onStartRunning() {
    }
    public func onStopRunning() {
    }
}

extension LiveViewController: CenterListener {
    public func center<C>(center: C, didDiscover devices: Result<[Device]>) where C: Center {
    }

    public func center<C>(center: C, didDisconnect device: Result<Device>) where C: Center {
        didDisconnect()
    }

    public func center<C>(center: C, didConnect device: Result<Device>) where C: Center {
        didConnect()
    }

    public func center<C>(center: C, didPrepared device: Result<Device>) where C: Center {
        startNeuron()
        didPrepared()
    }

    public func center<C: Center>(center: C, device: Device, didReceive data: Result<Decodable>) {
        if case let .success(data) = data, let dataT = data as? Data {
            Loader.currentBot.receivedData(dataT)
        }
    }
}

extension LiveViewController: PlaygroundLiveViewMessageHandler {

    public func liveViewMessageConnectionOpened() {
        proxy.start()
        onStartRunning()
    }

    public func liveViewMessageConnectionClosed() {
        proxy.stop()
        dismissAudioMenu()
        onStopRunning()
    }

    public func receive(_ message: PlaygroundValue) {
        proxy.receive(message)
    }
}

extension LiveViewController: UIPopoverPresentationControllerDelegate, AudioMenuDelegate {
    public func adaptivePresentationStyle(for controller: UIPresentationController) -> UIModalPresentationStyle {
        return .none
    }

    public func enableBackgroundAudio(_ isEnabled: Bool) {
        backgroundAudioEnabled = isEnabled
        updateAudioButtonImage(on: isEnabled)
        if isEnabled {
            playBgMusic()
        } else {
            stopMusic()
        }
        
        Persisted.isBackgroundAudioEnabled = isEnabled
    }

    public func dismissAudioMenu() {
        if let vc = presentedViewController as? AudioMenuController {
            vc.dismiss(animated: true, completion: nil)
        }
    }

    func updateAudioButtonImage(on: Bool) {
        let image: UIImage?
        if on {
            image = UIImage(named: "Sound")
        } else {
            image = UIImage(named: "SoundOff")
        }
        audioButton?.setImage(image, for: .normal)
    }
}

extension LiveViewController {
    func registerForTapGesture() {
        let tapGesture = UITapGestureRecognizer(target: self, action: #selector(tapAction(_:)))
        view.addGestureRecognizer(tapGesture)
    }

    @objc func tapAction(_ recognizer: UITapGestureRecognizer) {
        dismissAudioMenu()
    }
}
