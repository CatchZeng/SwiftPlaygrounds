//
//  TiltDetector.swift
//  Neuron
//
//  Created by CatchZeng on 2018/5/11.
//  Copyright © 2017-2018 Makeblock Co., Ltd. All rights reserved.
//

import Foundation
import CoreMotion

@objc public protocol TiltDetectorDelegate: class {
    @objc optional func onTiltUpdate(pitch: Int, roll: Int)
    @objc optional func onTiltUpdate(left: Bool, right: Bool, forword: Bool, backword: Bool)
}

public class TiltDetector {
    public weak var delegate: TiltDetectorDelegate?
    let motionManager = CMMotionManager()
    public var roll: Int = 0
    public var pitch: Int = 0

    public func start() {
        if !motionManager.isGyroAvailable {
            print("the gryo is no available.")
            return
        }
        motionManager.deviceMotionUpdateInterval = 0.3
        motionManager.startDeviceMotionUpdates(to: OperationQueue.main) {[weak self] (deviceMotion, _) in
            guard let strongSlef = self,
                let deviceMotion = deviceMotion
                else {
                    return
            }

            let pitch = -deviceMotion.attitude.pitch
            let roll = -deviceMotion.attitude.roll
            let boundary = 0.3
            let pitchOver = pitch > boundary ? 1 : (pitch < -boundary ? -1 : 0)
            let rollOver = roll > boundary ? 1 : (roll < -boundary ? -1 : 0)

            strongSlef.pitch = pitchOver
            strongSlef.roll = rollOver

            strongSlef.delegate?.onTiltUpdate?(pitch: pitchOver, roll: rollOver)
            strongSlef.delegate?.onTiltUpdate?(left: pitchOver == 1, right: pitchOver == -1, forword: rollOver == -1, backword: rollOver == 1)
        }
    }

    public func stop() {
        motionManager.stopDeviceMotionUpdates()
    }
}
