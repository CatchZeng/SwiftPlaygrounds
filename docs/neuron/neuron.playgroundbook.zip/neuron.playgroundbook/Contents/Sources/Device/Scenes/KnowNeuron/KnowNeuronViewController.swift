//
//  KnowNeuronViewController.swift
//  Neuron
//
//  Created by CatchZeng on 2017/4/18.
//  Copyright © 2017年 Shenzhen Maker Works Technology Co., Ltd. All rights reserved.
//

import UIKit
import PlaygroundSupport
import PlaygroundBluetooth
import WebKit

public class KnowNeuronViewController: NeuronViewController {
    public let stageView = KnowNeuronStageView(frame: .zero)

    override public func viewDidLoad() {
        super.viewDidLoad()
        loadStage()
    }

    override public func viewDidLayoutSubviews() {
        super.viewDidLayoutSubviews()
        stageView.updateLayout(frame: view.frame)
    }
    
    public override func didConnect() {
        if page == 6 || page == 8 {
            stageView.moveCurtain(position: .out)
        } else {
            stageView.moveCurtain(position: .top)
        }
    }
    
    public override func didDisconnect() {
        stageView.moveCurtain(position: .down)
    }

    @objc public func showChar() {
        stageView.stopGIF()
    }

    private func loadStage() {
        view.addSubview(stageView)
        stageView.hideCharacter()
        stageView.turnSpot(isOpen: false)
        stageView.moveLight(down: false, animated: false)
        stageView.hidePlane(false)
    }
}
