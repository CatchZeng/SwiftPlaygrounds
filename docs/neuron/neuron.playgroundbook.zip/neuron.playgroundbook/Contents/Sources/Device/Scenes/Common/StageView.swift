import UIKit

public class StageView: UIView {
    fileprivate let bgView = UIImageView(frame: CGRect.zero)

    fileprivate let curtainImageView = UIImageView(image: UIImage(named: "curtain"))
    fileprivate var curtainPosition: CurtainPosition = .down
    public var aspect: CGFloat = 512 / 768

    override public init(frame: CGRect) {
        super.init(frame: frame)
        aspect = getAspect(frame: frame)
        clipsToBounds = true

        setupBg()
        setupGameView()
        setupCurtain()
    }

    required public init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }

    // MARK: Public

    public func setBgImage(_ image: UIImage?) {
        bgView.image = image
    }

    public func updateLayout(frame: CGRect) {
        self.frame = frame
        curtainImageView.frame = getCurtainFrame()
        bgView.frame = frame
    }

    // Overrided by subclass
    public func setupGameView() {
    }

    public func hideCurtain() {
        curtainImageView.isHidden = true
    }

    public func showCurtain() {
        curtainImageView.isHidden = false
    }

    public func moveCurtain(position: CurtainPosition, animated: Bool = true) {
        self.curtainPosition = position
        let rect = getCurtainFrame()
        if animated {
            UIView.animate(withDuration: 0.7, delay: 0, usingSpringWithDamping: 0.8, initialSpringVelocity: 0, options: .curveEaseInOut, animations: {
                self.curtainImageView.frame = rect
            }, completion: nil)
        } else {
            curtainImageView.frame = rect
        }
    }

    // MARK: Private

    private func setupBg() {
        bgView.contentMode = .scaleAspectFill
        bgView.clipsToBounds = true
        addSubview(bgView)
        bgView.snp.makeConstraints { (make) in
            make.edges.equalTo(self)
        }
    }

    private func setupCurtain() {
        curtainImageView.contentMode = .scaleAspectFill
        curtainImageView.clipsToBounds = true
        addSubview(curtainImageView)
    }

    fileprivate func getCurtainFrame() -> CGRect {
        let curtainToTop: CGFloat = 135 * aspect
        let curtainToBot: CGFloat = 100 * aspect
        let heightCurtain = max(bounds.height, bounds.width)
        let widthCurtain = heightCurtain
        var yCurtain = bounds.height - heightCurtain - curtainToBot
        switch curtainPosition {
        case .top:
            yCurtain = curtainToTop - heightCurtain
        case .down:
            break
        case .out:
            yCurtain = -heightCurtain
        }
        return CGRect.init(x: 0, y: yCurtain, width: widthCurtain, height: heightCurtain)
    }
}
