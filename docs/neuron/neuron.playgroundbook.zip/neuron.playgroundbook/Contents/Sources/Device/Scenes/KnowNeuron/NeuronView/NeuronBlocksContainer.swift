//
//  NeuronBlocksContainer.swift
//  NeuronView
//
//  Created by littleStrong on 2017/11/17.
//  Copyright © 2017年 Company. All rights reserved.
//

import UIKit

struct BlockCellModel {
    var type: Int
    var index: Int
    var name: String
    var height: CGFloat
    var imageName: String
    var isConnected = true
    var isActive = true
    init(_ index: Int, _ type: Int, _ name: String, _ height: CGFloat, _ img: String, _ isConnected: Bool, _ isActive: Bool) {
        self.name = name
        self.height = height
        self.imageName = img
        self.isConnected = isConnected
        self.isActive = isActive
        self.index = index
        self.type = type
    }
    init() {
        type = 0
        index = 0
        name = ""
        height = 80
        imageName = ""
        isConnected = false
        isActive = true
    }
}

class NeuronBlocksContainer: UIView, UITableViewDelegate, UITableViewDataSource {
    let blockCellID = "BlockCell"
    private let tableView = UITableView()
    private lazy var datasource: [BlockCellModel] = []

    private var orderedDatasource: [BlockCellModel] {
        return self.datasource.filter {$0.isConnected && $0.isActive}.sorted(by: { (model1, model2) -> Bool in
            return model1.index < model2.index
        })
    }

    override init(frame: CGRect) {
        super.init(frame: frame)
        addSubview(tableView)
        backgroundColor = UIColor.clear
        tableView.isScrollEnabled = false
        tableView.separatorStyle = .none
        tableView.backgroundColor = UIColor.clear
        tableView.register(BlockCell.self, forCellReuseIdentifier: blockCellID)
        tableView.delegate = self
        tableView.dataSource = self
        datasource = fetchDatasource()
    }

    override func layoutSubviews() {
        super.layoutSubviews()
        ajustUI()
    }

    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }

    private func ajustUI() {
        let wholeHeight = orderedDatasource.reduce(0) { (r, next) -> CGFloat in
            return r + next.height
            } * heightAspect()
        tableView.frame = CGRect.init(x: 0, y: (bounds.height - wholeHeight)/2 - 3, width: bounds.width, height: bounds.height)
    }

    private func heightAspect() -> CGFloat {
        var aspect: CGFloat = 1
        switch orderedDatasource.count {
        case (8...12):
            aspect = 0.8
        case (6...7):
            aspect = 1
        case (4...5):
            aspect = 1.2
        case (1...3):
            aspect = 1.44
        default:
            aspect = 1
        }
        return aspect
    }

    private func fetchDatasource() -> [BlockCellModel] {
        return cellModels(with: [.bluetooth, .power])
    }

    private func cellModels(with types: [BlockType]) -> [BlockCellModel] {
        return types.enumerated().map {
            self.cellModel(with: $0.element, index: $0.offset)
        }
    }

    private func cellModel(with type: BlockType, index: Int) -> BlockCellModel {
        return BlockCellModel.init(index, type.rawValue, "", type.height, type.imageName, true, true)
    }

    public func changeBlockState(type: BlockType, isConnected: Bool, animated: Bool = false) {
        let indexT = datasource.index { (model) -> Bool in
            return model.type == type.rawValue
        }
        if let index = indexT {
            if !isConnected {
                datasource.remove(at: index)
            }
        } else {
            let model = cellModel(with: type, index: datasource.count)
            datasource.append(model)
        }
        tableView.reloadData()
        setNeedsLayout()
    }

    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return orderedDatasource.count
    }

    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        if let cell = tableView.dequeueReusableCell(withIdentifier: blockCellID) as? BlockCell {
            cell.model = orderedDatasource[indexPath.row]
            return cell
        }
        return UITableViewCell.init(style: .default, reuseIdentifier: nil)
    }

    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {

    }

    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        let aspect = heightAspect()
        return orderedDatasource[indexPath.row].height * aspect
    }
}
