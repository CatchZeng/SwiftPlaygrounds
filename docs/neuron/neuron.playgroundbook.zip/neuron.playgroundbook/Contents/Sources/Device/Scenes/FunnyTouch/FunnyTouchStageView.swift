//
//  FunnyTouchStageView.swift
//  Neuron
//
//  Created by CatchZeng on 2018/5/26.
//  Copyright © 2018年 makeblock. All rights reserved.
//

import UIKit

public class FunnyTouchStageView: StageView {
    fileprivate let gameView = UIView(frame: CGRect.zero)
    fileprivate let diglett = UIImageView(image: UIImage(named: "funnytouch_diglett"))
    fileprivate let redHole = UIImageView(image: UIImage(named: "funnytouch_red"))
    fileprivate let blueHole = UIImageView(image: UIImage(named: "funnytouch_blue"))
    fileprivate let yellowHole = UIImageView(image: UIImage(named: "funnytouch_yellow"))
    fileprivate let greenHole = UIImageView(image: UIImage(named: "funnytouch_green"))
    fileprivate let gifManager = SwiftyGifManager(memoryLimit: 60)
    fileprivate let hammerView = UIImageView(frame: .zero)
    fileprivate let startView = UIImageView(frame: .zero)

    fileprivate var curPosition: DiglettPosition = .red

    fileprivate var timer: Timer?
    fileprivate var isHammering = false

    override public init(frame: CGRect) {
        super.init(frame: frame)
        setBgImage(UIImage(named: "funnytouch_bg"))
    }

    required public init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }

    override public func setupGameView() {
        addSubview(gameView)

        gameView.snp.makeConstraints { (make) in
            make.center.equalTo(self)
            make.width.equalTo(453)
            make.height.equalTo(768)
        }

        addDiglett()
        addHoles()
        addHammerView()
        addStartView()
    }

    // MARK: Public

    public func hammer(position: DiglettPosition) {
        stopRandom()
        
        if isHammering {
            return
        }
        
        isHammering = true
        
        switch position {
        case .red:
            hammerView.frame.origin = CGPoint(x: 53, y: -172)
            startView.frame.origin = CGPoint(x: -20, y: 40)
        case .blue:
            hammerView.frame.origin = CGPoint(x: 262, y: -151)
            startView.frame.origin = CGPoint(x: 185, y: 60)
        case .yellow:
            hammerView.frame.origin = CGPoint(x: 53, y: 109)
            startView.frame.origin = CGPoint(x: -20, y: 330)
        case .green:
            hammerView.frame.origin = CGPoint(x: 263, y: 130)
            startView.frame.origin = CGPoint(x: 190, y: 340)
        }

        if position == curPosition {
            self.perform(#selector(diglettHited), with: nil, afterDelay: 2.3)
            self.perform(#selector(startStarAnimation), with: nil, afterDelay: 2.2)
        } else {
            self.perform(#selector(diglettDismiss), with: nil, afterDelay: 2.7)
        }

        hammerView.setGifImage(UIImage(gifName: "hammer"),
                               manager: gifManager,
                               loopCount: 1)
        hammerView.startAnimatingGif()

        self.perform(#selector(resetIsHammering), with: nil, afterDelay: 5.0)
    }

    @objc private func resetIsHammering() {
        isHammering = false
        genRandomHole()
        startRandom()
    }

    @objc private func startStarAnimation() {
        startView.setGifImage(UIImage(gifName: "star"),
                               manager: gifManager,
                               loopCount: 1)
        startView.startAnimatingGif()
    }

    @objc private func diglettHited() {
        UIView.animate(withDuration: 0.5) {
            self.diglett.frame.origin = self.curPosition.point
        }
    }

    @objc private func diglettDismiss() {
        let y = diglett.frame.origin.y - 20
        UIView.animate(withDuration: 0.8, animations: {
            self.diglett.frame.origin.y = y
        }) { (_) in
            UIView.animate(withDuration: 0.2) {
                self.diglett.frame.origin = self.curPosition.point
            }
        }
    }

    public func emitFromHole(position: DiglettPosition) {
        switch position {
        case .red:
            gameView.insertSubview(diglett, belowSubview: redHole)
        case .blue:
            gameView.insertSubview(diglett, belowSubview: blueHole)
        case .yellow:
            gameView.insertSubview(diglett, belowSubview: yellowHole)
        case .green:
            gameView.insertSubview(diglett, belowSubview: greenHole)
        }

        let point = position.point
        diglett.frame.origin = point

        let finalPoint = CGPoint(x: point.x, y: point.y - 120)

        UIView.animate(withDuration: 1.0,
                       delay: 0.0,
                       usingSpringWithDamping: 0.8,
                       initialSpringVelocity: 10,
                       options: .curveEaseOut,
                       animations: {
                        self.diglett.frame.origin = finalPoint
        }, completion: nil)
    }

    public func startRandom() {
        timer = Timer.scheduledTimer(withTimeInterval: 5.0, repeats: true, block: {[weak self] (_) in
            guard let strongSelf = self else { return }

            if strongSelf.isHammering {
                return
            }

            strongSelf.genRandomHole()
        })
        GCDDelay.delay(0.1) { [weak self] in
            guard let timer = self?.timer,
                timer.isValid else {
                    return
            }
            timer.fire()
        }
    }

    public func stopRandom() {
        timer?.invalidate()
    }

    // MARK: Private

    private func genRandomHole() {
        while true {
            let newPosition = Int(arc4random_uniform(4))
            if newPosition != self.curPosition.rawValue {
                if let position = DiglettPosition(rawValue: newPosition) {
                    self.curPosition = position
                    self.emitFromHole(position: position)
                }
                break
            }
        }
    }

    private func addDiglett() {
        gameView.addSubview(diglett)
        diglett.frame.size = CGSize(width: 126.5, height: 164.5)
        diglett.frame.origin = DiglettPosition.red.point
    }

    private func addHoles() {
        gameView.addSubview(redHole)
        redHole.frame.size = CGSize(width: 189.5, height: 180)
        redHole.frame.origin = CGPoint(x: 14.5, y: 180.5)

        gameView.addSubview(blueHole)
        blueHole.frame.size = CGSize(width: 203, height: 182)
        blueHole.frame.origin = CGPoint(x: 246.5, y: 202)

        gameView.addSubview(yellowHole)
        yellowHole.frame.size = CGSize(width: 201, height: 164.5)
        yellowHole.frame.origin = CGPoint(x: 0, y: 462)

        gameView.addSubview(greenHole)
        greenHole.frame.size = CGSize(width: 206.5, height: 180.5)
        greenHole.frame.origin = CGPoint(x: 246.5, y: 482.5)
    }

    private func addHammerView() {
        gameView.addSubview(hammerView)
        hammerView.contentMode = .scaleAspectFill
        hammerView.frame.size = CGSize(width: 417.5, height: 350)
    }

    private func addStartView() {
        gameView.addSubview(startView)
        startView.contentMode = .scaleAspectFill
        startView.frame.size = CGSize(width: 320, height: 165)
    }
}

public enum DiglettPosition: Int {
    case red = 0
    case blue = 1
    case yellow = 2
    case green = 3
}

extension DiglettPosition {
    var point: CGPoint {
        var x: CGFloat = 0
        var y: CGFloat = 0
        switch self {
        case .red:
            x = 56
            y = 182
        case .blue:
            x = 264
            y = 202
        case .yellow:
            x = 56
            y = 462
        case .green:
            x = 267
            y = 482
        }
        return CGPoint(x: x, y: y)
    }
}
