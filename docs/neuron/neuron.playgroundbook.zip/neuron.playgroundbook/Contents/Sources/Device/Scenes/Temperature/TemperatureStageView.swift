//
//  StageView.swift
//  Neuron
//
//  Created by littleStrong on 2018/3/16.
//  Copyright © 2018年 Company. All rights reserved.
//

import UIKit

public class TemperatureStageView: StageView {
    let indicatorView = UIImageView(image: UIImage(named: "temperature_indicator"))
    let roundView = UIImageView(image: UIImage(named: "temperature_round"))
    fileprivate let robotGifView = UIImageView(image: UIImage(named: "soft"))
    fileprivate let robotTmpGifView = UIImageView(frame: .zero)
    let valueView = UIView(frame: .zero)

    private var lastSection: TemperatureSection = .none
    fileprivate let gifManager = SwiftyGifManager(memoryLimit: 60)

    override public init(frame: CGRect) {
        super.init(frame: frame)
        setBgImage(UIImage(named: "stage"))
    }

    required public init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }

    override public func setupGameView() {
        robotGifView.contentMode = .scaleAspectFill
        addSubview(robotGifView)
        robotGifView.snp.makeConstraints { (make) in
            make.edges.equalTo(self)
        }
        hideTemperature()

        robotTmpGifView.contentMode = .scaleAspectFit
        addSubview(robotTmpGifView)
        robotTmpGifView.snp.makeConstraints { (make) in
            make.edges.equalTo(self)
        }
        robotTmpGifView.isHidden = true

        addSubview(indicatorView)

        roundView.contentMode = .scaleAspectFit
        roundView.frame = CGRect(x: 44.5, y: 10, width: 54, height: 24.5)
        indicatorView.addSubview(roundView)

        valueView.backgroundColor = UIColor(red: 0.788, green: 0.788, blue: 0.788, alpha: 1.0)
        indicatorView.addSubview(valueView)
    }

    override public func updateLayout(frame: CGRect) {
        super.updateLayout(frame: frame)

        let y = 0.5*(frame.height - 498)
        let x = 0.5*(frame.width - 183) - 60
        indicatorView.frame = CGRect(x: x, y: y, width: 180, height: 498)
    }

    // MARK: Public
    
    public func showTemperature() {
        robotGifView.isHidden = false
        indicatorView.isHidden = false
        roundView.isHidden = false
    }
    
    public func hideTemperature() {
        robotGifView.isHidden = true
        indicatorView.isHidden = true
        roundView.isHidden = true
    }

    public func update(_ temperature: Int) {
        updateValueView(temperature)

        if TemperatureSection.cold.isMatched(temperature) {
            doRobotAnimation(section: .cold)
            lastSection = .cold

        } else if TemperatureSection.soft.isMatched(temperature) {
            doRobotAnimation(section: .soft)
            lastSection = .soft

        } else {
            doRobotAnimation(section: .hot)
            lastSection = .hot
        }
    }

    // MARK: Private

    private func doRobotAnimation(section: TemperatureSection) {
        if lastSection != section {
            robotTmpGifView.alpha = 0.0
            robotTmpGifView.isHidden = false
            self.robotTmpGifView.gifImage = UIImage(gifName: section.gifName)
            self.robotTmpGifView.showFrameAtIndex(0)

            UIView.animate(withDuration: 0.5, animations: {
                self.robotTmpGifView.alpha = 1.0
            }) { (_) in
                self.robotGifView.setGifImage(UIImage(gifName: section.gifName),
                                              manager: self.gifManager,
                                              loopCount: 1)
                self.robotGifView.startAnimatingGif()

                UIView.animate(withDuration: 0.5, animations: {
                    self.robotTmpGifView.alpha = 0.0
                }) { (_) in
                    self.robotTmpGifView.isHidden = true
                }
            }
        }
    }

    private func updateValueView(_ temperature: Int) {
        let precent = CGFloat(temperature+10)*1.11/100.0
        var height = (1-precent)*285
        if height < 0 {
            height = 0
        } else if height > 285 {
            height = 285
        }

        if self.valueView.frame.height == 0 {
            self.valueView.frame = CGRect(x: 44.5, y: 34.5, width: 54, height: height)
        } else {
            UIView.animate(withDuration: 0.2) {
                self.valueView.frame = CGRect(x: 44.5, y: 34.5, width: 54, height: height)
            }
        }
    }
}

public enum TemperatureSection {
    case none
    case cold
    case soft
    case hot
}

extension TemperatureSection {
    var start: Int {
        switch self {
        case .cold:
            return -10
        case .soft:
            return 10
        case .hot:
            return 25
        case .none:
            return -100
        }
    }

    var end: Int {
        switch self {
        case .cold:
            return 9
        case .soft:
            return 24
        case .hot:
            return 80
        case .none:
            return -100
        }
    }

    var gifName: String {
        switch self {
        case .cold:
            return "cold"
        case .soft:
            return "soft"
        case .hot:
            return "hot"
        case .none:
            return "none"
        }
    }

    func isMatched(_ temperature: Int) -> Bool {
        if temperature < 10 {
            return self == .cold
        } else if temperature > 24 {
            return self == .hot
        } else {
            return (temperature >= self.start && temperature  <= self.end)
        }
    }
}
