//
//  KnobStageView.swift
//  Neuron
//
//  Created by CatchZeng on 2017/4/18.
//  Copyright © 2017年 Shenzhen Maker Works Technology Co., Ltd. All rights reserved.
//

import UIKit

public class KnobStageView: StageView {
    fileprivate let gifManager = SwiftyGifManager(memoryLimit: 60)
    fileprivate let robotGifImageView = UIImageView(frame: .zero)
    private let knobImage = UIImage(gifName: "knob")

    override public init(frame: CGRect) {
        super.init(frame: frame)
        setBgImage(UIImage(named: "knob_bg"))
    }

    required public init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }

    override public func setupGameView() {
        robotGifImageView.contentMode = .scaleAspectFill
        addSubview(robotGifImageView)
        robotGifImageView.gifImage = knobImage
        let image = robotGifImageView.frameAtIndex(index: 0)
        robotGifImageView.image = image
    }

    override public func updateLayout(frame: CGRect) {
        super.updateLayout(frame: frame)
        robotGifImageView.frame = bounds
    }

    // MARK: Public
    
    public func showKnob() {
        robotGifImageView.isHidden = false
    }
    
    public func hideKnob() {
        robotGifImageView.isHidden = true
    }

    public func playGIF(loopCount: Int = -1) {
        if robotGifImageView.isAnimatingGif() {
            return
        }

        robotGifImageView.setGifImage(knobImage, manager: gifManager, loopCount: loopCount)
        robotGifImageView.startAnimatingGif()
    }

    public func stopGIF() {
        robotGifImageView.stopAnimatingGif()
        robotGifImageView.gifImage = knobImage
        let image = robotGifImageView.frameAtIndex(index: 0)
        robotGifImageView.image = image
    }

    public func clearGIF() {
        robotGifImageView.clear()
    }
}
