//
//  BlockType.swift
//  Neuron
//
//  Created by CatchZeng on 2017/4/10.
//  Copyright © 2017-2018 Makeblock Co., Ltd. All rights reserved.
//

import Foundation

public enum NeuronTypeCode: UInt8 {
    case unknown = 0x00
    case dispatch = 0x10
    case move = 0x62
    case sensor = 0x63
    case control = 0x64
    case display = 0x65
    case sound = 0x66
}

public let blockTypes: [UInt8: [UInt8: BlockType]] = [
    NeuronTypeCode.move.rawValue: [
        BlockType.dcmotor.subTypeCode!: .dcmotor,
        BlockType.servo.subTypeCode!: .servo
    ],
    NeuronTypeCode.sensor.rawValue: [
        BlockType.temperature.subTypeCode!: .temperature,
        BlockType.light.subTypeCode!: .light,
        BlockType.distance.subTypeCode!: .distance,
        BlockType.gyro.subTypeCode!: .gyro,
        BlockType.soilMoisture.subTypeCode!: .soilMoisture,
        BlockType.voice.subTypeCode!: .voice
    ],
    NeuronTypeCode.control.rawValue: [
        BlockType.funnyTouch.subTypeCode!: .funnyTouch,
        BlockType.knob.subTypeCode!: .knob
    ],
    NeuronTypeCode.display.rawValue: [
        BlockType.led.subTypeCode!: .led,
        BlockType.ledBand.subTypeCode!: .ledBand
    ],
    NeuronTypeCode.sound.rawValue: [
        BlockType.buzzer.subTypeCode!: .buzzer
    ]
]

public enum BlockType: Int {
    case dcmotor
    case servo
    case light
    case distance
    case gyro
    case soilMoisture
    case voice
    case temperature
    case funnyTouch
    case knob
    case led
    case ledBand
    case buzzer
    case bluetooth
    case power

    public static func getType(type: UInt8, subType: UInt8) -> BlockType? {
        return blockTypes[type]?[subType]
    }
}

extension BlockType {
    public var typeCode: UInt8 {
        switch self {
        case .dcmotor, .servo:
            return NeuronTypeCode.move.rawValue
        case .light, .distance, .gyro, .soilMoisture, .voice, .temperature:
            return NeuronTypeCode.sensor.rawValue
        case .funnyTouch, .knob:
            return NeuronTypeCode.control.rawValue
        case .led, .ledBand:
            return NeuronTypeCode.display.rawValue
        case .buzzer:
            return NeuronTypeCode.sound.rawValue
        case .bluetooth, .power:
            return NeuronTypeCode.unknown.rawValue
        }
    }

    public var subTypeCode: UInt8? {
        switch self {
        case .dcmotor:
            return 0x02
        case .servo:
            return 0x03
        case .light:
            return 0x02
        case .distance:
            return 0x0e
        case .gyro:
            return 0x06
        case .soilMoisture:
            return 0x08
        case .voice:
            return 0x0d
        case .temperature:
            return 0x01
        case .funnyTouch:
            return 0x04
        case .knob:
            return 0x01
        case .led:
            return 0x04
        case .ledBand:
            return 0x03
        case .buzzer:
            return 0x02
        case .bluetooth, .power:
            return nil
        }
    }
}
