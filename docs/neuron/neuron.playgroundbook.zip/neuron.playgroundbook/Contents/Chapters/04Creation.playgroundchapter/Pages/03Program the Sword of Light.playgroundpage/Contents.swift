//#-hidden-code
//
//  Contents.swift
//  Neuron
//
//  Created by CatchZeng on 2017/4/18.
//  Copyright © 2017年 Shenzhen Maker Works Technology Co., Ltd. All rights reserved.
//

import PlaygroundSupport
import Foundation
//#-end-hidden-code
/*:#localized(key: "Chapter04Page03Prose")
 */
//#-hidden-code
playgroundPrologue()
powerOn()
//#-code-completion(everything, hide)
//#-code-completion(literal, show, integer, float)
//#-code-completion(identifier, show, .)
//#-code-completion(identifier, show, dcMotor(power1:power2:), wait(duration:), stop())
//#-code-completion(identifier, show, getKnob(), getLight(), getDistance(), hasObstacle(), playSound(note:beat:), ledColor(color:), ledColor(color:style:), panelShow(expression:), panelClear(), iPadTiltedForward(), iPadTiltedBackward(), iPadTiltedLeft(), iPadTiltedRight())
//#-code-completion(identifier, show, SoundNote, c4, d4, e4, f4, g4, a4, b4, c5)
//#-code-completion(identifier, show, SoundBeat, whole, half, quarter, eighth, sixteenth)
//#-code-completion(identifier, show, Expression, angry, smile, smiley, happy, shock, sun, moon, fire, blank, forward, backward, left, right)
//#-code-completion(identifier, show, LEDColor, black, red, orange, yellow, green, cyan, blue, purple, white)
//#-code-completion(identifier, show, LEDStyle, light, marquee, breathing)
//#-code-completion(keyword, show, for, func, if, var, while)
DispatchQueue.global().async {
var time = 0;
//#-end-hidden-code
while true {
    //#-editable-code Tap to enter code
    let knob = getKnob()
    if knob >= 0 && knob < 30 {
        ledColor(color: .red, style: .marquee)
    } else if knob >= 30 && knob < 60 {
        ledColor(color: .blue, style: .breathing)
    } else if knob >= 60 {
        ledColor(color: .purple, style: .light)
    }
    wait(duration: 2)
    //#-end-editable-code
    //#-hidden-code
    if time < 1 {
        RuleManager.shared.check()
    }
    time += 1
    //#-end-hidden-code
}
//#-hidden-code
}
RuleManager.shared.check()
//#-end-hidden-code
