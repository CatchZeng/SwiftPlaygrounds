//
//  Commands.swift
//  Neuron
//
//  Created by CatchZeng on 2017/4/18.
//  Copyright © 2017年 Shenzhen Maker Works Technology Co., Ltd. All rights reserved.
//

import PlaygroundSupport

public func playSound(note: SoundNote, beat: SoundBeat) {
    ActionTool.playSound(note: note, beat: beat)
}

public func ledColor(color: LEDColor, style: LEDStyle = .light) {
    ActionTool.ledColor(color: color, style: style)
}

public func testText(_ text: String) {
    ActionTool.testText("\(text)")
}

public func powerOn() {
    ActionTool.powerOn()
}

public func wait(duration: Float) {
    ActionTool.wait(duration)
}
