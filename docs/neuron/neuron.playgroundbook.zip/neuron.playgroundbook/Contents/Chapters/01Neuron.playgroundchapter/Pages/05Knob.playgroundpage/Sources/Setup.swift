//
//  Setup.swift
//  Neuron
//
//  Created by CatchZeng on 2017/4/18.
//  Copyright © 2017年 Shenzhen Maker Works Technology Co., Ltd. All rights reserved.
//

import Foundation
import PlaygroundSupport
public let contentListenr = ContentListenr()

public func playgroundPrologue() {
    setProxyDelegate(contentListenr)
    PlaygroundPage.current.needsIndefiniteExecution = true
    
    let checker = KnobChecker()
    RuleManager.shared.needFinishExecution = false
    RuleManager.shared.set(ruleChecker: checker)
}

