//
//  Commands.swift
//  Neuron
//
//  Created by CatchZeng on 2017/4/18.
//  Copyright © 2017年 Shenzhen Maker Works Technology Co., Ltd. All rights reserved.
//

import PlaygroundSupport
import UIKit

public func thermometer(_ temperature: Int) {
    ActionTool.thermometer(temperature)
}

public func getTemperature() -> Int {
    wait(duration: 0.1)
    ActionTool.getTemperature()
    
    
    let t1=CACurrentMediaTime()
    while contentListenr.getTemperature == -99 {
        let t2=CACurrentMediaTime()
        if (t2 - t1) > 0.5 {
            break
        }
    }
    return contentListenr.getTemperature
}

public func testText(_ text: String) {
    ActionTool.testText("\(text)")
}

public func powerOn() {
    ActionTool.powerOn()
}

public func wait(duration: Float) {
    ActionTool.wait(duration)
}
