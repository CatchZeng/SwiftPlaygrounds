//#-hidden-code
//
//  Contents.swift
//  Neuron
//
//  Created by CatchZeng on 2017/4/18.
//  Copyright © 2017年 Shenzhen Maker Works Technology Co., Ltd. All rights reserved.
//

import PlaygroundSupport
import Foundation
//#-end-hidden-code
/*:#localized(key: "Chapter01Page07Prose")
 光线传感器
 */
//#-hidden-code
playgroundPrologue()
powerOn()
//#-end-hidden-code
//#-code-completion(everything, hide)
//#-code-completion(identifier, show, getTemperature())
//#-code-completion(keyword, show, for, func, if, var, while)
//#-hidden-code
DispatchQueue.global().async {
var time = 0;
//#-end-hidden-code
while true {
    let temperature = /*#-editable-code Tap to enter code*//*#-end-editable-code*/
    thermometer(temperature)
    //#-hidden-code
    if time < 1 {
        RuleManager.shared.check()
    }
    time += 1
    //#-end-hidden-code
}
//#-hidden-code
}
//#-end-hidden-code
