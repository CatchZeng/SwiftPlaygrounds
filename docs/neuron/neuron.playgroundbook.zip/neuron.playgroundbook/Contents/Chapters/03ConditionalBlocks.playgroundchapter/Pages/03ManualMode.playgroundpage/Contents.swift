//#-hidden-code
//
//  Contents.swift
//  Neuron
//
//  Created by CatchZeng on 2017/4/18.
//  Copyright © 2017年 Shenzhen Maker Works Technology Co., Ltd. All rights reserved.
//

import PlaygroundSupport
import Foundation
//#-end-hidden-code
/*:#localized(key: "Chapter03Page03Prose")
 */
//#-hidden-code
playgroundPrologue()
powerOn()
//#-code-completion(everything, hide)
//#-code-completion(literal, show, integer, float)
//#-code-completion(identifier, show, .)
//#-code-completion(identifier, show, panelShow(expression:), panelClear(), iPadTiltedForward(), iPadTiltedBackward(), iPadTiltedLeft(), iPadTiltedRight())
//#-code-completion(identifier, show, Expression, angry, smile, smiley, happy, shock, sun, moon, fire, blank, forward, backward, left, right)
//#-code-completion(keyword, show, for, func, if, var, while)
DispatchQueue.global().async {
var time = 0;
//#-end-hidden-code
while true {
    if /*#-editable-code Tap to enter code*//*#-end-editable-code*/ {
        panelShow(expression: .forward)
    }
    else if iPadTiltedBackward() {
        panelShow(expression: /*#-editable-code Tap to enter code*//*#-end-editable-code*/)
    }
    else if /*#-editable-code Tap to enter code*//*#-end-editable-code*/ {
        //#-editable-code Tap to enter code
        
        //#-end-editable-code
    }
    else if /*#-editable-code Tap to enter code*//*#-end-editable-code*/ {
        //#-editable-code Tap to enter code
        
        //#-end-editable-code
    }
    //#-hidden-code
    if time < 1 {
        RuleManager.shared.check()
    }
    time += 1
    //#-end-hidden-code
}
//#-hidden-code
}
//#-end-hidden-code
