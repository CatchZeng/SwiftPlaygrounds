//#-hidden-code
//
//  Contents.swift
//  Neuron
//
//  Created by CatchZeng on 2017/4/18.
//  Copyright © 2017年 Shenzhen Maker Works Technology Co., Ltd. All rights reserved.
//

import PlaygroundSupport
import Foundation
//#-end-hidden-code
/*:#localized(key: "Chapter03Page01Prose")
 */
//#-hidden-code
playgroundPrologue()
powerOn()
//#-code-completion(everything, hide)
//#-code-completion(literal, show, integer, float)
//#-code-completion(identifier, show, hasObstacle())
//#-code-completion(keyword, show, for, func, if, var, while)
DispatchQueue.global().async {
var time = 0;
//#-end-hidden-code
while true {
    dcMotor(power1: 60, power2: -60)
    if /*#-editable-code Tap to enter code*/<#condition#>/*#-end-editable-code*/ {
        dcMotor(power1: /*#-editable-code Tap to enter code*/<#T##value##Int#>/*#-end-editable-code*/, power2: /*#-editable-code Tap to enter code*/<#T##value##Int#>/*#-end-editable-code*/)
        playSound(note: .c5, beat: .half)
        playSound(note: .g4, beat: .half)
        wait(duration: /*#-editable-code Tap to enter code*/<#T##value##Int#>/*#-end-editable-code*/)
    }
    //#-hidden-code
    if time < 1 {
        RuleManager.shared.check()
    }
    time += 1
    //#-end-hidden-code
}
//#-hidden-code
}
//#-end-hidden-code
