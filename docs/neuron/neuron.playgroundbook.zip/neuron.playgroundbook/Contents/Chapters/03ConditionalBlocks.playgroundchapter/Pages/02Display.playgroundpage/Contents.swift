//#-hidden-code
//
//  Contents.swift
//  Neuron
//
//  Created by CatchZeng on 2017/4/18.
//  Copyright © 2017年 Shenzhen Maker Works Technology Co., Ltd. All rights reserved.
//

import PlaygroundSupport
import Foundation
//#-end-hidden-code
/*:#localized(key: "Chapter03Page02Prose")
 */
//#-hidden-code
playgroundPrologue()
powerOn()
//#-code-completion(everything, hide)
//#-code-completion(literal, show, integer, float)
//#-code-completion(identifier, show, .)
//#-code-completion(identifier, show, dcMotor(power1:power2:), wait(duration:), stop())
//#-code-completion(identifier, show, getLight(), getDistance(), hasObstacle(), playSound(note:beat:), panelShow(expression:), panelClear())
//#-code-completion(identifier, show, SoundNote, c4, d4, e4, f4, g4, a4, b4, c5)
//#-code-completion(identifier, show, SoundBeat, whole, half, quarter, eighth, sixteenth)
//#-code-completion(identifier, show, Expression, angry, smile, smiley, happy, shock, sun, moon, fire, blank, forward, backward, left, right)
//#-code-completion(keyword, show, for, func, if, var, while)
var time = 0;
DispatchQueue.global().async {
//#-end-hidden-code
while true {
    dcMotor(power1: 60, power2: -60)
    panelClear()
    if /*#-editable-code Tap to enter code*//*#-end-editable-code*/ {
        stop()
        playSound(note: .c5, beat: .half)
        playSound(note: .g4, beat: .half)
        //#-editable-code Tap to enter code
        
        //#-end-editable-code
        wait(duration: /*#-editable-code Tap to enter code*//*#-end-editable-code*/)
    }
    //#-hidden-code
    if time < 1 {
        RuleManager.shared.check()
    }
    time += 1
    //#-end-hidden-code
}
//#-hidden-code
}
//#-end-hidden-code
