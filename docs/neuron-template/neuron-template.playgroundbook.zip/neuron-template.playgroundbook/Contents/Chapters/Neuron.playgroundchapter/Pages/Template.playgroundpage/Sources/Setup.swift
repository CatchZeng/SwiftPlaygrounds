//
//  Setup.swift
//  Neuron
//
//  Created by CatchZeng on 2017/4/18.
//  Copyright © 2017-2018 Makeblock Co., Ltd. All rights reserved.
//

import Foundation
import PlaygroundSupport
public let contentListenr = ContentListenr()

public func playgroundPrologue() {
    setProxyDelegate(contentListenr)
    PlaygroundPage.current.needsIndefiniteExecution = true
}
