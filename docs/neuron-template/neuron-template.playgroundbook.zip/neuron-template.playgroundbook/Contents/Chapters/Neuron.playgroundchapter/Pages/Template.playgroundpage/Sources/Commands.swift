//
//  Commands.swift
//  Neuron
//
//  Created by CatchZeng on 2017/4/18.
//  Copyright © 2017-2018 Makeblock Co., Ltd. All rights reserved.
//

import PlaygroundSupport
import Foundation
import UIKit

public func dcMotor(slot: DCMotorSlot, power: Int) {
    ActionTool.dcMotor(slot: slot, power: power)
}

public func dcMotor(power1: Int, power2: Int) {
    ActionTool.dcMotor(power1: power1, power2: power2)
}

public func playSound(note: SoundNote, beat: SoundBeat = .whole) {
    ActionTool.playSound(note: note, beat: beat)
}

public func ledColor(color: LEDColor, style: LEDStyle) {
    ActionTool.ledColor(color: color, style: style)
}

public func closeLed() {
    ActionTool.ledColor(color: .black, style: .light)
}

public func panelShow(expression: Expression) {
    ActionTool.panelShow(expression: expression)
}

public func panelShow(color: UIColor) {
    if let rgba = color.rgba() {
        ActionTool.panelColor(r: rgba.r, g: rgba.g, b: rgba.b)
    }
}

public func panelClear() {
    ActionTool.panelColor(r: 0, g: 0, b:0)
}

public func getKnob() -> Int {
    wait(duration: 0.1)
    ActionTool.getKnob()
    
    let now = Date()
    let t1=CACurrentMediaTime()
    while contentListenr.getKnob == -99 {
        let t2=CACurrentMediaTime()
        if (t2 - t1) > 0.5 {
            break
        }
    }
    return contentListenr.getKnob
}

public func getLight() -> Int {
    wait(duration: 0.1)
    ActionTool.getLight()
    
    let now = Date()
    let t1=CACurrentMediaTime()
    while contentListenr.getLight == -99 {
        let t2=CACurrentMediaTime()
        if (t2 - t1) > 0.5 {
            break
        }
    }
    return contentListenr.getLight
}

public func getTemperature() -> Int {
    wait(duration: 0.1)
    ActionTool.getTemperature()
    
    let now = Date()
    let t1=CACurrentMediaTime()
    while contentListenr.getTemperature == -99 {
        let t2=CACurrentMediaTime()
        if (t2 - t1) > 0.5 {
            break
        }
    }
    return contentListenr.getTemperature
}

public func getBlueTouched() -> Bool {
    wait(duration: 0.1)
    ActionTool.getFunnyTouch()
    
    let now = Date()
    let t1=CACurrentMediaTime()
    while !contentListenr.blueTouched {
        let t2=CACurrentMediaTime()
        if (t2 - t1) > 0.1 {
            break
        }
    }
    return contentListenr.blueTouched
}

public func getYellowTouched() -> Bool {
    wait(duration: 0.1)
    ActionTool.getFunnyTouch()
    
    let now = Date()
    let t1=CACurrentMediaTime()
    while !contentListenr.yellowTouched {
        let t2=CACurrentMediaTime()
        if (t2 - t1) > 0.1 {
            break
        }
    }
    return contentListenr.yellowTouched
}

public func getRedTounched() -> Bool {
    wait(duration: 0.1)
    ActionTool.getFunnyTouch()
    
    let now = Date()
    let t1=CACurrentMediaTime()
    while !contentListenr.redTouched {
        let t2=CACurrentMediaTime()
        if (t2 - t1) > 0.1 {
            break
        }
    }
    return contentListenr.redTouched
}

public func getGreenTounched() -> Bool {
    wait(duration: 0.1)
    ActionTool.getFunnyTouch()
    
    let now = Date()
    let t1=CACurrentMediaTime()
    while !contentListenr.greenTouched {
        let t2=CACurrentMediaTime()
        if (t2 - t1) > 0.1 {
            break
        }
    }
    return contentListenr.greenTouched
}

public func getDistance() -> Int {
    wait(duration: 0.1)
    ActionTool.getDistance()
    
    let now = Date()
    let t1=CACurrentMediaTime()
    while contentListenr.getDistance == -99 {
        let t2=CACurrentMediaTime()
        if (t2 - t1) > 0.5 {
            break
        }
    }
    return contentListenr.getDistance
}

public func hasObstacle() -> Bool {
    wait(duration: 0.1)
    ActionTool.getDistance()
    
    let now = Date()
    let t1=CACurrentMediaTime()
    while contentListenr.getDistance == -99 {
        let t2=CACurrentMediaTime()
        if (t2 - t1) > 0.5 {
            break
        }
    }
    return contentListenr.getDistance <= 10
}

public func iPadTiltedForward() -> Bool {
    wait(duration: 0.1)
    return contentListenr.iPadTiltedForward
}

public func iPadTiltedBackward() -> Bool {
    wait(duration: 0.1)
    return contentListenr.iPadTiltedBackward
}

public func iPadTiltedLeft() -> Bool {
    wait(duration: 0.1)
    return contentListenr.iPadTiltedLeft
}

public func iPadTiltedRight() -> Bool {
    wait(duration: 0.1)
    return contentListenr.iPadTiltedRight
}

public func iPadSound(note: PadSoundNote) {
    ActionTool.iPadSound(note: note)
}

public func stopiPadSound() {
    ActionTool.stopiPadSound()
}

public var gyroXangle: Int {
    wait(duration: 0.1)
    return contentListenr.gyroXangle
}

public var gyroYangle: Int {
    wait(duration: 0.1)
    return contentListenr.gyroYangle
}

public var gyroZangle: Int {
    wait(duration: 0.1)
    return contentListenr.gyroZangle
}

public var getSoilmoisture: Int {
    wait(duration: 0.1)
    return contentListenr.getSoilmoisture
}

public func getVoice() -> Int {
    wait(duration: 0.1)
    return contentListenr.getVoice
}

public func testText(_ text: String) {
    ActionTool.testText("\(text)")
}

public func powerOn() {
    ActionTool.powerOn()
}

public func setServo(port: ServoPort, angle: Int) {
    ActionTool.setServo(port: port, angle: angle)
}

public func stopServo(port: ServoPort) {
    ActionTool.setServo(port: port, angle: 0)
}

public func turnLED(x: Int, y: Int, r: Int, g: Int, b: Int) {
    ActionTool.turnLED(x: x, y: y, r: r, g: g, b: b)
}

public func wait(duration: Float) {
    ActionTool.wait(duration)
}
