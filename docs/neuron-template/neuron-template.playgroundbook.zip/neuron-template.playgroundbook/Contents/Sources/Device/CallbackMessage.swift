import PlaygroundSupport

public struct CallbackEncodingKey {
    public static let typeKey = "typeKey"
    public static let valueKey = "valueKey"
    
    public static let callback = "callback"
    public static let isConnected = "isConnected"
    
    public static let gyroXangle = "gyroXangle"
    public static let gyroYangle = "gyroYangle"
    public static let gyroZangle = "gyroZangle"
    
    public static let getSoilmoisture = "getSoilmoisture"
    public static let getVoice = "getVoice"
    public static let getKnob = "getKnob"
    public static let getLight = "getLight"
    public static let getTemperature = "getTemperature"
    public static let getDistance = "getDistance"
    
    public static let blueTouched = "blueTouched"
    public static let yellowTouched = "yellowTouched"
    public static let redTouched = "redTouched"
    public static let greenTouched = "greenTouched"
    
    public static let iPadTiltedForward = "iPadTiltedForward"
    public static let iPadTiltedBackward = "iPadTiltedBackward"
    public static let iPadTiltedLeft = "iPadTiltedLeft"
    public static let iPadTiltedRight = "iPadTiltedRight"
}

public enum SPCallbackCommand {
    case gyroXangle(Int)
    case gyroYangle(Int)
    case gyroZangle(Int)
    
    case getSoilmoisture(Int)
    case getVoice(Int)
    case getKnob(Int)
    case getLight(Int)
    case getTemperature(Int)
    case getDistance(Int)
    
    case blueTouched(Bool)
    case yellowTouched(Bool)
    case redTouched(Bool)
    case greenTouched(Bool)
    case isConnected(Bool)
    
    case iPadTiltedForward(Bool)
    case iPadTiltedBackward(Bool)
    case iPadTiltedLeft(Bool)
    case iPadTiltedRight(Bool)
}

extension SPCallbackCommand: SPMessageConstructible {
    public init?(_ value: PlaygroundValue) {
        guard case let .dictionary(dict) = value, let typeV = dict[CallbackEncodingKey.typeKey], case let .string(type) = typeV else {
            return nil
        }
        switch type {
        case CallbackEncodingKey.gyroXangle:
            if let a = value.intValue(CallbackEncodingKey.valueKey) {
                self = .gyroXangle(a)
            } else {
                return nil
            }
        case CallbackEncodingKey.gyroYangle:
            if let a = value.intValue(CallbackEncodingKey.valueKey) {
                self = .gyroYangle(a)
            } else {
                return nil
            }
        case CallbackEncodingKey.gyroZangle:
            if let a = value.intValue(CallbackEncodingKey.valueKey) {
                self = .gyroZangle(a)
            } else {
                return nil
            }
        
        case CallbackEncodingKey.getSoilmoisture:
            if let a = value.intValue(CallbackEncodingKey.valueKey) {
                self = .getSoilmoisture(a)
            } else {
                return nil
            }
        case CallbackEncodingKey.getVoice:
            if let a = value.intValue(CallbackEncodingKey.valueKey) {
                self = .getVoice(a)
            } else {
                return nil
            }
        case CallbackEncodingKey.getKnob:
            if let a = value.intValue(CallbackEncodingKey.valueKey) {
                self = .getKnob(a)
            } else {
                return nil
            }
        case CallbackEncodingKey.getLight:
            if let a = value.intValue(CallbackEncodingKey.valueKey) {
                self = .getLight(a)
            } else {
                return nil
            }
        case CallbackEncodingKey.getTemperature:
            if let a = value.intValue(CallbackEncodingKey.valueKey) {
                self = .getTemperature(a)
            } else {
                return nil
            }
        case CallbackEncodingKey.getDistance:
            if let a = value.intValue(CallbackEncodingKey.valueKey) {
                self = .getDistance(a)
            } else {
                return nil
            }
        case CallbackEncodingKey.blueTouched:
            if let a = value.boolValue(CallbackEncodingKey.valueKey) {
                self = .blueTouched(a)
            } else {
                return nil
            }
        case CallbackEncodingKey.yellowTouched:
            if let a = value.boolValue(CallbackEncodingKey.valueKey) {
                self = .yellowTouched(a)
            } else {
                return nil
            }
        case CallbackEncodingKey.redTouched:
            if let a = value.boolValue(CallbackEncodingKey.valueKey) {
                self = .redTouched(a)
            } else {
                return nil
            }
        case CallbackEncodingKey.greenTouched:
            if let a = value.boolValue(CallbackEncodingKey.valueKey) {
                self = .greenTouched(a)
            } else {
                return nil
            }
        case CallbackEncodingKey.iPadTiltedForward:
            if let a = value.boolValue(CallbackEncodingKey.valueKey) {
                self = .iPadTiltedForward(a)
            } else {
                return nil
            }
        case CallbackEncodingKey.iPadTiltedBackward:
            if let a = value.boolValue(CallbackEncodingKey.valueKey) {
                self = .iPadTiltedBackward(a)
            } else {
                return nil
            }
        case CallbackEncodingKey.iPadTiltedLeft:
            if let a = value.boolValue(CallbackEncodingKey.valueKey) {
                self = .iPadTiltedLeft(a)
            } else {
                return nil
            }
        case CallbackEncodingKey.iPadTiltedRight:
            if let a = value.boolValue(CallbackEncodingKey.valueKey) {
                self = .iPadTiltedRight(a)
            } else {
                return nil
            }
        default:
            return nil
        }
    }
    
    public var value: PlaygroundValue {
        var dict: [String: PlaygroundValue] = [:]
        switch self {
        case .gyroXangle(let value):
            dict[CallbackEncodingKey.valueKey] = value.value
            dict[CallbackEncodingKey.typeKey] = CallbackEncodingKey.gyroXangle.value
        case .gyroYangle(let value):
            dict[CallbackEncodingKey.valueKey] = value.value
            dict[CallbackEncodingKey.typeKey] = CallbackEncodingKey.gyroYangle.value
        case .gyroZangle(let value):
            dict[CallbackEncodingKey.valueKey] = value.value
            dict[CallbackEncodingKey.typeKey] = CallbackEncodingKey.gyroZangle.value
        case .getSoilmoisture(let value):
            dict[CallbackEncodingKey.valueKey] = value.value
            dict[CallbackEncodingKey.typeKey] = CallbackEncodingKey.getSoilmoisture.value
        case .getVoice(let value):
            dict[CallbackEncodingKey.valueKey] = value.value
            dict[CallbackEncodingKey.typeKey] = CallbackEncodingKey.getVoice.value
        case .getKnob(let value):
            dict[CallbackEncodingKey.valueKey] = value.value
            dict[CallbackEncodingKey.typeKey] = CallbackEncodingKey.getKnob.value
        case .getLight(let value):
            dict[CallbackEncodingKey.valueKey] = value.value
            dict[CallbackEncodingKey.typeKey] = CallbackEncodingKey.getLight.value
        case .getTemperature(let value):
            dict[CallbackEncodingKey.valueKey] = value.value
            dict[CallbackEncodingKey.typeKey] = CallbackEncodingKey.getTemperature.value
        case .getDistance(let value):
            dict[CallbackEncodingKey.valueKey] = value.value
            dict[CallbackEncodingKey.typeKey] = CallbackEncodingKey.getDistance.value
        case .blueTouched(let value):
            dict[CallbackEncodingKey.valueKey] = value.value
            dict[CallbackEncodingKey.typeKey] = CallbackEncodingKey.blueTouched.value
        case .yellowTouched(let value):
            dict[CallbackEncodingKey.valueKey] = value.value
            dict[CallbackEncodingKey.typeKey] = CallbackEncodingKey.yellowTouched.value
        case .redTouched(let value):
            dict[CallbackEncodingKey.valueKey] = value.value
            dict[CallbackEncodingKey.typeKey] = CallbackEncodingKey.redTouched.value
        case .greenTouched(let value):
            dict[CallbackEncodingKey.valueKey] = value.value
            dict[CallbackEncodingKey.typeKey] = CallbackEncodingKey.greenTouched.value
        case .iPadTiltedForward(let value):
            dict[CallbackEncodingKey.valueKey] = value.value
            dict[CallbackEncodingKey.typeKey] = CallbackEncodingKey.iPadTiltedForward.value
        case .iPadTiltedBackward(let value):
            dict[CallbackEncodingKey.valueKey] = value.value
            dict[CallbackEncodingKey.typeKey] = CallbackEncodingKey.iPadTiltedBackward.value
        case .iPadTiltedLeft(let value):
            dict[CallbackEncodingKey.valueKey] = value.value
            dict[CallbackEncodingKey.typeKey] = CallbackEncodingKey.iPadTiltedLeft.value
        case .iPadTiltedRight(let value):
            dict[CallbackEncodingKey.valueKey] = value.value
            dict[CallbackEncodingKey.typeKey] = CallbackEncodingKey.iPadTiltedRight.value
        default: break
        }
        
        return .dictionary(dict)
    }
}
