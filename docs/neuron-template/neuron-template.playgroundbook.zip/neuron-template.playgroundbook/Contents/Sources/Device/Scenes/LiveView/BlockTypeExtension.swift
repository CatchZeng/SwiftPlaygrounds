//
//  BlockType.swift
//  Neuron
//
//  Created by CatchZeng on 2018/5/8.
//  Copyright © 2017-2018 Makeblock Co., Ltd. All rights reserved.
//

import Foundation
import UIKit

extension BlockType {
    var name: String {
        switch self {
        case .dcmotor:
            return "DCMotor"
        case .servo:
            return "Servo"
        case .light:
            return NSLocalizedString("Light Sensor", comment: "Neuron")
        case .distance:
            return NSLocalizedString("Ranging Sensor", comment: "Neuron")
        case .gyro:
            return "Gyro"
        case .soilMoisture:
            return "SoilMoisture"
        case .voice:
            return "Voice Sensor"
        case .temperature:
            return NSLocalizedString("Temp Sensor", comment: "Neuron")
        case .funnyTouch:
            return NSLocalizedString("Funny Touch", comment: "Neuron")
        case .led:
            return "LED"
        case .ledBand:
            return "LED Band"
        case .buzzer:
            return "Buzzer"
        case .bluetooth:
            return "Bluetooth"
        case .power:
            return "Power"
        case .knob:
            return NSLocalizedString("Knob", comment: "Neuron")
        }
    }
    
    var icon: UIImage? {
        switch self {
        case .dcmotor:
            return nil
        case .servo:
            return nil
        case .light:
            return UIImage(named: "neuron-light-sensor")
        case .distance:
            return UIImage(named: "neuron-ranging-sensor")
        case .gyro:
            return nil
        case .soilMoisture:
            return nil
        case .voice:
            return nil
        case .temperature:
            return UIImage(named: "neuron-temp-sensor")
        case .funnyTouch:
            return UIImage(named: "neuron-funny-touch")
        case .led:
            return nil
        case .ledBand:
            return nil
        case .buzzer:
            return nil
        case .bluetooth:
            return nil
        case .power:
            return nil
        case .knob:
            return UIImage(named: "neuron-knob")
        }
    }
    
    var isInput: Bool {
        switch self {
        case .dcmotor:
            return false
        case .servo:
            return false
        case .light:
            return true
        case .distance:
            return true
        case .gyro:
            return false
        case .soilMoisture:
            return false
        case .voice:
            return false
        case .temperature:
            return true
        case .funnyTouch:
            return true
        case .led:
            return false
        case .ledBand:
            return false
        case .buzzer:
            return false
        case .bluetooth:
            return false
        case .power:
            return false
        case .knob:
            return true
        }
    }
}
