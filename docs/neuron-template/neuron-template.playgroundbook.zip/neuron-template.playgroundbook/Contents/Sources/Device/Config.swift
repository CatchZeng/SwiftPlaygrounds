//
//  Loader.swift
//  MBBlueToothCenter
//
//  Created by block Make on 2017/7/21.
//  Copyright © 2017-2018 Makeblock Co., Ltd. All rights reserved.
//

import PlaygroundSupport

public func setCurrentScene(chapter: Int = 0, page: Int = 0) {
    let vc = TemplateViewController.init(nibName: nil, bundle: nil)
    PlaygroundPage.current.liveView = vc
    vc.chapter = chapter
    vc.page = page
}

public var currentTemplateViewController: TemplateViewController? {
    if let vc = PlaygroundPage.current.liveView as? TemplateViewController {
        return vc
    }
    return nil
}

public let currentBot = Neuron(sender: SPBLECenter.shared)
