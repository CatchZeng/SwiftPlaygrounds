//
//  BLETaskResponder.swift
//  Neuron
//
//  Created by block Make on 2017/7/21.
//  Copyright © 2017-2018 Makeblock Co., Ltd. All rights reserved.
//

import UIKit
import PlaygroundSupport
import CoreBluetooth

public class BLETaskResponder: SPTaskResponder {
    
    public override func handle(command: MCommand) {
        switch command.action {
        case .sound(let note, let beat):
            playSound(note, beat)
        case .dcMotor(let slot, let power):
            dcMotor(slot, power)
        case .dcMotorMeanwhile(let power1, let power2):
            dcMotorMeanwhile(power1, power2)
        case .servo(let port, let angle):
            turnServo(port, angle)
        case .led(let x, let y, let r, let g, let b):
            turnLED(x, y, r, g, b)
        case .ledBand(let color, let style):
            ledBand(color, style)
        case .ledPanel(let expression):
            ledPanel(expression)
        case .panelColor(let r, let g, let b):
            panelColor(r, g, b)
        case .getKnob:
            getKnob()
        case .getLight:
            getLight()
        case .getTemperature:
            getTemperature()
        case .getFunnyTouch:
            getFunnyTouch()
        case .getDistance:
            getDistance()
        case .powerOn:
            powerOn()
        case .powerOff:
            powerOff()
        case .wait(let duration):
            wait(duration)
        case .lightSensor(_):
            break
        case .distanceSensor(_):
            break
        case .testText(let text):
            log(text)
        case .iPadSound(let note):
            iPadSound(note: note)
        case .stopiPadSound:
            stopiPadSound()
        default:
            break
        }
    }
    
    private func wait(_ duration: Float) {
    }

    private func startHeartbeat() {
        currentBot.startHeartbeat()
    }
    
    private func stopHeartbeat() {
        currentBot.stopHeartbeat()
    }
    
    private func subscribeForGyroData() {
        currentBot.subscribeGyroData(dataType: .xAngle, way: .cyclicity, timeIntervalInMs: 500)
        currentBot.subscribeGyroData(dataType: .yAngle, way: .cyclicity, timeIntervalInMs: 500)
        currentBot.subscribeGyroData(dataType: .zAngle, way: .cyclicity, timeIntervalInMs: 500)
    }
    
    private func cancelSubscribeForGyroData() {
        currentBot.cancelSubscribeGyroData(dataType: .xAngle)
        currentBot.cancelSubscribeGyroData(dataType: .yAngle)
        currentBot.cancelSubscribeGyroData(dataType: .zAngle)
    }
    
    private func getKnob() {
        currentBot.getKnob()
    }
    
    private func getLight() {
        currentBot.getLight()
    }
    
    private func getTemperature() {
        currentBot.getTemperature()
    }
    
    private func getDistance() {
        currentBot.getDistance()
    }
    
    private func getFunnyTouch() {
        currentBot.getFunnyTouch()
    }

    private func powerOn() {
        startHeartbeat()
    }
    
    private func powerOff() {
    }
    
    private func playSound(_ note: SoundNote, _ beat: SoundBeat) {
        currentBot.setBuzzer(pitch: note, duration: beat)
    }
    
    private func dcMotor(_ slot: DCMotorSlot, _ power: Int) {
        currentBot.setDCMotor(slot: slot, speed: power)
    }
    
    private func dcMotorMeanwhile(_ power1: Int, _ power2: Int) {
        currentBot.setBothDCMotor(speed1: power1, speed2: power2)
    }
    
    private func turnLED(_ x: Int, _ y: Int, _ r: Int, _ g: Int, _ b: Int) {
        currentBot.setRGBLED(x: x,
                                    y: y,
                                    red: r,
                                    green: g,
                                    blue: b)
    }
    
    private func ledBand(_ color: LEDColor, _ style: LEDStyle) {
        if style == .marquee {
            let colors = (0..<8).map {_ in color}
            currentBot.setLEDColors(colors, animateMode: .marquee, animateSpeed: 5)
        } else {
           currentBot.setLEDColor(color, animateMode: style)
        }
    }
    
    private func ledPanel(_ expression: Expression) {
        currentBot.setLEDMatrix(colors: expression.colors)
    }
    
    private func panelColor(_ r: Int, _ g: Int, _ b: Int) {
        currentBot.setRGBLED(x: 0,
                                    y: 0,
                                    red: r,
                                    green: g,
                                    blue: b)
    }
    
    private func turnServo(_ port: ServoPort, _ angle: Int) {
        currentBot.setServo(port: port, angle: angle)
    }
    
    private func iPadSound(note: PadSoundNote) {
        currentTemplateViewController?.iPadSound(note: note)
    }
    
    private func stopiPadSound() {
        currentTemplateViewController?.stopiPadSound()
    }
}
