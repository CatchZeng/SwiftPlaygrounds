//
//  ActionTool
//  Neuron
//
//  Created by CatchZeng on 2018/4/18.
//  Copyright © 2017-2018 Makeblock Co., Ltd. All rights reserved.
//

import UIKit

extension ActionTool {    
    static public func powerOn() {
        sendAction(.powerOn, duration: 0.5)
    }
    
    static public func powerOff() {
        sendDefaultDurationAction(.powerOff)
    }
    
    static public func getKnob() {
        sendDefaultDurationAction(.getKnob)
    }
    
    static public func getLight() {
        sendDefaultDurationAction(.getLight)
    }
    
    static public func getTemperature() {
        sendDefaultDurationAction(.getTemperature)
    }
    
    static public func getDistance() {
        sendDefaultDurationAction(.getDistance)
    }
    
    static public func getFunnyTouch() {
        sendDefaultDurationAction(.getFunnyTouch)
    }
    
    static public func changeLightIntensity(_ light: Float) {
        sendDefaultDurationAction(.lightSensor(lightIntensity: light))
    }

    static public func playSound(note: SoundNote, beat: SoundBeat) {
        sendDefaultDurationAction(.sound(note: note, beat: beat))
    }
    
    static public func dcMotor(slot: DCMotorSlot, power: Int) {
        sendDefaultDurationAction(.dcMotor(slot: slot, power: power))
    }
    
    static public func dcMotor(power1: Int, power2: Int) {
        sendDefaultDurationAction(.dcMotorMeanwhile(power1: power1, power2: power2))
    }
    
    static public func ledColor(color: LEDColor, style: LEDStyle) {
        sendDefaultDurationAction(.ledBand(color: color, style: style))
    }
    
    static public func panelShow(expression: Expression) {
        sendDefaultDurationAction(.ledPanel(expression: expression))
    }
    
    static public func panelColor(r: Int, g: Int, b: Int) {
        sendDefaultDurationAction(.panelColor(r: r, g: g, b: b))
    }
    
    static public func setServo(port: ServoPort, angle: Int) {
        sendAction(.servo(port: port, angle: angle), duration: 1)
    }
    
    static public func turnLED(x: Int, y: Int, r: Int, g: Int, b: Int) {
        sendDefaultDurationAction(.led(x: x, y: y, r: r, g: g, b: b))
    }
    
    static public func distance(_ height: Int) {
        sendDefaultDurationAction(.distanceSensor(distance: height))
    }
    
    static public func iPadSound(note: PadSoundNote) {
        sendDefaultDurationAction(.iPadSound(note: note))
    }
    
    static public func stopiPadSound() {
        sendDefaultDurationAction(.stopiPadSound)
    }
}
